<?php
if (!defined('ABSPATH')) exit;

class QQTS_Admin {
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_init', [__CLASS__, 'handle_manual_actions']);
        add_action('admin_notices', [__CLASS__, 'display_review_notice']);
    }

    public static function display_review_notice() {
        if (!current_user_can('manage_options')) return;
        if (get_option('qqts_review_dismissed')) return;

        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) return;

        $scanned_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'used'");
        if ($scanned_count >= 20) {
            ?>
            <div class="notice notice-success is-dismissible" style="padding: 12px 16px; border-left-color: #46b450;">
                <p style="font-size: 14px; margin: 0 0 8px;">
                    🎉 <strong>Quick QR Ticket Scanner</strong> has successfully validated <strong><?php echo esc_html($scanned_count); ?> tickets</strong> at your events!
                </p>
                <p style="margin: 0;">
                    If you enjoy using the plugin, please take 30 seconds to support us with a ⭐⭐⭐⭐⭐ review on WordPress.org:
                    <a href="https://wordpress.org/support/plugin/quick-qr-ticket-scanner/reviews/#new-post" target="_blank" class="button button-primary" style="margin-left: 8px;">Leave 5-Star Review</a>
                </p>
            </div>
            <?php
        }
    }

    public static function register_menu() {
        add_menu_page(
            __('QR Tickets', 'quick-qr-ticket-scanner'),
            __('QR Tickets', 'quick-qr-ticket-scanner'),
            'manage_options',
            'quick-qr-tickets',
            [__CLASS__, 'render_admin_page'],
            'dashicons-tickets-alt',
            30
        );

        add_submenu_page(
            'quick-qr-tickets',
            __('Tickets & Scanner', 'quick-qr-ticket-scanner'),
            __('Tickets & Scanner', 'quick-qr-ticket-scanner'),
            'manage_options',
            'quick-qr-tickets',
            [__CLASS__, 'render_admin_page']
        );

        add_submenu_page(
            'quick-qr-tickets',
            __('Telegram Settings', 'quick-qr-ticket-scanner'),
            __('💬 Telegram Bot', 'quick-qr-ticket-scanner'),
            'manage_options',
            'quick-qr-telegram',
            [__CLASS__, 'render_telegram_page']
        );
    }

    public static function handle_manual_actions() {
        if (!current_user_can('manage_options')) return;

        if (isset($_POST['qqts_create_ticket']) && check_admin_referer('qqts_create_ticket_action')) {
            global $wpdb;
            $table = $wpdb->prefix . 'qqts_tickets';
            $guest_name = sanitize_text_field($_POST['guest_name']);
            $guest_email = sanitize_email($_POST['guest_email']);
            $ticket_type = sanitize_text_field($_POST['ticket_type']);
            $ticket_price = sanitize_text_field($_POST['ticket_price'] ?? '0 EUR');
            $event_name = sanitize_text_field($_POST['event_name']);
            $code = 'TKT-' . strtoupper(wp_generate_password(10, false, false));

            $wpdb->insert($table, [
                'ticket_code' => $code,
                'guest_name' => $guest_name,
                'guest_email' => $guest_email,
                'ticket_type' => $ticket_type,
                'event_name' => $event_name,
                'status' => 'valid'
            ]);

            // Notify Telegram instantly on manual creation
            if (class_exists('QQTS_Telegram')) {
                QQTS_Telegram::notify_manual_ticket_created($guest_name, $guest_email, $event_name, $ticket_type, $ticket_price, $code);
            }

            // Dispatch HTML E-Ticket Pass to Guest Email
            if (class_exists('QQTS_Mailer') && !empty($guest_email)) {
                QQTS_Mailer::send_ticket_email($guest_email, $guest_name, $event_name, $ticket_type, $ticket_price, $code);
            }

            wp_redirect(admin_url('admin.php?page=quick-qr-tickets&created=1'));
            exit;
        }
    }

    public static function render_telegram_page() {
        $options = QQTS_Telegram::get_options();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('💬 Telegram Order & Ticket Notifications', 'quick-qr-ticket-scanner'); ?></h1>
            <p><?php esc_html_e('Automatically sends instant Telegram notifications when tickets are purchased, issued or scanned at the gate.', 'quick-qr-ticket-scanner'); ?></p>
            
            <form method="post" action="options.php" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-top: 15px;">
                <?php settings_fields('qqts_telegram_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Integration Status', 'quick-qr-ticket-scanner'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="qqts_telegram_settings[enabled]" value="1" <?php checked('1', isset($options['enabled']) ? $options['enabled'] : '0'); ?> />
                                <strong><?php esc_html_e('Enable Telegram notifications', 'quick-qr-ticket-scanner'); ?></strong>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Telegram Bot Token', 'quick-qr-ticket-scanner'); ?></th>
                        <td>
                            <input type="text" name="qqts_telegram_settings[bot_token]" value="<?php echo esc_attr(isset($options['bot_token']) ? $options['bot_token'] : ''); ?>" class="regular-text" placeholder="1234567890:AAH..." />
                            <p class="description"><?php esc_html_e('Create a bot with @BotFather and paste the token here.', 'quick-qr-ticket-scanner'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Telegram Chat ID / Group ID', 'quick-qr-ticket-scanner'); ?></th>
                        <td>
                            <input type="text" name="qqts_telegram_settings[chat_id]" value="<?php echo esc_attr(isset($options['chat_id']) ? $options['chat_id'] : ''); ?>" class="regular-text" placeholder="-100... or 1142060901" />
                            <p class="description"><?php esc_html_e('Group or channel ID (e.g. -1001234567890 or 1142060901).', 'quick-qr-ticket-scanner'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'quick-qr-ticket-scanner')); ?>
            </form>

            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-top: 20px;">
                <h3><?php esc_html_e('🧪 Test Telegram Connection', 'quick-qr-ticket-scanner'); ?></h3>
                <p><?php esc_html_e('Click the button below to send a live test notification:', 'quick-qr-ticket-scanner'); ?></p>
                <button type="button" class="button button-secondary" id="btn-qqts-tg-test"><?php esc_html_e('Send Test Message', 'quick-qr-ticket-scanner'); ?></button>
                <span id="qqts-tg-test-result" style="margin-left: 15px; font-weight: bold;"></span>
            </div>

            <script>
            jQuery(document).ready(function($) {
                $('#btn-qqts-tg-test').on('click', function() {
                    var $btn = $(this);
                    var $res = $('#qqts-tg-test-result');
                    $btn.prop('disabled', true).text('<?php echo esc_js(__('Sending...', 'quick-qr-ticket-scanner')); ?>');
                    $res.text('').css('color', '#000');

                    $.post(ajaxurl, {
                        action: 'qqts_tg_test_message',
                        nonce: '<?php echo wp_create_nonce('qqts_tg_test_nonce'); ?>'
                    }, function(response) {
                        $btn.prop('disabled', false).text('<?php echo esc_js(__('Send Test Message', 'quick-qr-ticket-scanner')); ?>');
                        if (response.success) {
                            $res.text(response.data).css('color', 'green');
                        } else {
                            $res.text('❌ Error: ' + (response.data || 'Check token & chat ID')).css('color', 'red');
                        }
                    }).fail(function() {
                        $btn.prop('disabled', false).text('<?php echo esc_js(__('Send Test Message', 'quick-qr-ticket-scanner')); ?>');
                        $res.text('❌ Server connection error').css('color', 'red');
                    });
                });
            });
            </script>
        </div>
        <?php
    }

    public static function render_admin_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        $tickets = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 100");
        $scanner_url = home_url('/?qqts_scanner=1');
        $heartbeat_nonce = wp_create_nonce('qqts_admin_heartbeat_nonce');
        ?>
        <div class="wrap">
            <h1>🎟️ <?php esc_html_e('Quick QR Ticket Scanner & Management', 'quick-qr-ticket-scanner'); ?> <span style="font-size: 12px; vertical-align: middle; background: #e0f2fe; color: #0369a1; padding: 3px 8px; border-radius: 12px; margin-left: 10px;">⚡ Live Real-Time Polling Active</span></h1>
            <div style="background: #fff; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2>📱 <?php esc_html_e('Live Door Scanner (For Bouncers & Staff)', 'quick-qr-ticket-scanner'); ?></h2>
                <p><?php esc_html_e('Open this URL on any smartphone camera (iPhone / Android) to start scanning instantly without app download:', 'quick-qr-ticket-scanner'); ?></p>
                <p><strong><?php esc_html_e('Scanner URL:', 'quick-qr-ticket-scanner'); ?></strong> <a href="<?php echo esc_url($scanner_url); ?>" target="_blank" class="button button-primary"><?php echo esc_html($scanner_url); ?></a></p>
                <p><em><?php esc_html_e('Or use shortcode: [quick_qr_scanner] on any private page.', 'quick-qr-ticket-scanner'); ?></em></p>
            </div>

            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 300px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                    <h3>➕ <?php esc_html_e('Create Manual Ticket', 'quick-qr-ticket-scanner'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('qqts_create_ticket_action'); ?>
                        <p><label><strong><?php esc_html_e('Guest Name:', 'quick-qr-ticket-scanner'); ?></strong><br><input type="text" name="guest_name" class="widefat" placeholder="e.g. Elon Musk" required></label></p>
                        <p><label><strong><?php esc_html_e('Guest Email:', 'quick-qr-ticket-scanner'); ?></strong><br><input type="email" name="guest_email" class="widefat" placeholder="elon@x.com"></label></p>
                        <p><label><strong><?php esc_html_e('Event Name:', 'quick-qr-ticket-scanner'); ?></strong><br><input type="text" name="event_name" class="widefat" value="Global Tech Summit 2026"></label></p>
                        <p style="display: flex; gap: 10px;">
                            <label style="flex: 1;"><strong><?php esc_html_e('Ticket Type:', 'quick-qr-ticket-scanner'); ?></strong><br>
                                <select name="ticket_type" class="widefat">
                                    <option value="Standard"><?php esc_html_e('Standard Entry', 'quick-qr-ticket-scanner'); ?></option>
                                    <option value="VIP"><?php esc_html_e('VIP Pass', 'quick-qr-ticket-scanner'); ?></option>
                                    <option value="Table"><?php esc_html_e('Table Reservation', 'quick-qr-ticket-scanner'); ?></option>
                                </select>
                            </label>
                            <label style="flex: 1;"><strong><?php esc_html_e('Price / Fee:', 'quick-qr-ticket-scanner'); ?></strong><br>
                                <input type="text" name="ticket_price" class="widefat" value="50 EUR" placeholder="e.g. 50 EUR">
                            </label>
                        </p>
                        <p style="margin-top: 15px;"><input type="submit" name="qqts_create_ticket" class="button button-primary" value="<?php esc_attr_e('Generate Ticket QR', 'quick-qr-ticket-scanner'); ?>"></p>
                    </form>
                </div>

                <div style="flex: 2; min-width: 450px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                    <h3>📋 <?php esc_html_e('Recent Tickets & Status', 'quick-qr-ticket-scanner'); ?></h3>
                    <table class="wp-list-table widefat fixed striped" id="qqts-tickets-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Ticket Pass & QR', 'quick-qr-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Guest', 'quick-qr-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Type', 'quick-qr-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Status', 'quick-qr-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Used At', 'quick-qr-ticket-scanner'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tickets)): ?>
                                <tr><td colspan="5"><?php esc_html_e('No tickets generated yet. Create your first ticket on the left!', 'quick-qr-ticket-scanner'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($tickets as $t): ?>
                                    <tr data-code="<?php echo esc_attr($t->ticket_code); ?>">
                                        <td>
                                            <strong><code><?php echo esc_html($t->ticket_code); ?></code></strong><br>
                                            <button type="button" class="button button-small qqts-view-qr-btn" style="margin-top: 4px; font-size: 11px;" 
                                                data-code="<?php echo esc_attr($t->ticket_code); ?>" 
                                                data-guest="<?php echo esc_attr($t->guest_name); ?>"
                                                data-type="<?php echo esc_attr($t->ticket_type); ?>"
                                                data-event="<?php echo esc_attr($t->event_name ?: 'VIP Event'); ?>">
                                                🎟️ <?php esc_html_e('Show QR Pass', 'quick-qr-ticket-scanner'); ?>
                                            </button>
                                        </td>
                                        <td><?php echo esc_html($t->guest_name); ?><br><small><?php echo esc_html($t->guest_email); ?></small></td>
                                        <td><?php echo esc_html($t->ticket_type); ?></td>
                                        <td class="qqts-status-cell">
                                            <?php if ($t->status === 'valid'): ?>
                                                <span style="color: #46b450; font-weight: bold;">🟢 <?php esc_html_e('Valid', 'quick-qr-ticket-scanner'); ?></span>
                                            <?php else: ?>
                                                <span style="color: #dc3232; font-weight: bold;">🔴 <?php esc_html_e('Used', 'quick-qr-ticket-scanner'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="qqts-used-at-cell"><?php echo esc_html($t->used_at ?: '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Visual QR Pass Modal -->
        <div id="qqts-qr-modal" style="display:none; position:fixed; z-index:99999; left:0; top:0; width:100%; height:100%; background:rgba(15,23,42,0.75); backdrop-filter:blur(4px); align-items:center; justify-content:center;">
            <div style="background:#fff; border-radius:16px; width:360px; padding:24px; text-align:center; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); position:relative;">
                <button type="button" id="qqts-close-modal" style="position:absolute; right:16px; top:16px; border:none; background:#f1f5f9; width:32px; height:32px; border-radius:50%; font-size:16px; cursor:pointer; font-weight:bold;">✕</button>
                <div style="font-size:12px; font-weight:800; color:#3b82f6; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;" id="qqts-modal-event">VIP EVENT</div>
                <h2 style="margin:0 0 6px; font-size:20px; color:#0f172a;" id="qqts-modal-guest">John Doe</h2>
                <div style="display:inline-block; padding:4px 12px; background:#dbeafe; color:#1e40af; border-radius:20px; font-size:12px; font-weight:bold; margin-bottom:16px;" id="qqts-modal-type">VIP Pass</div>
                
                <!-- Live Scannable Graphic QR Code -->
                <div style="background:#f8fafc; padding:16px; border-radius:12px; border:2px dashed #cbd5e1; display:inline-block; margin-bottom:16px;">
                    <img id="qqts-modal-qr-img" src="" alt="Ticket QR" style="width:180px; height:180px; display:block; margin:0 auto; image-rendering:pixelated;" />
                </div>
                
                <div style="font-family:monospace; font-size:16px; font-weight:800; letter-spacing:2px; color:#1e293b; margin-bottom:16px; background:#f1f5f9; padding:8px 12px; border-radius:6px;" id="qqts-modal-code">TKT-XXXXX</div>
                
                <p style="font-size:12px; color:#64748b; margin:0;">Point camera scanner at this QR code to validate entry.</p>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('.qqts-view-qr-btn').on('click', function() {
                var code = $(this).data('code');
                var guest = $(this).data('guest');
                var type = $(this).data('type');
                var event = $(this).data('event');

                $('#qqts-modal-code').text(code);
                $('#qqts-modal-guest').text(guest);
                $('#qqts-modal-type').text(type);
                $('#qqts-modal-event').text(event);
                
                var qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(code);
                $('#qqts-modal-qr-img').attr('src', qrUrl);

                $('#qqts-qr-modal').css('display', 'flex');
            });

            $('#qqts-close-modal, #qqts-qr-modal').on('click', function(e) {
                if (e.target === this) {
                    $('#qqts-qr-modal').hide();
                }
            });

            // Live Auto-Polling Heartbeat (Updates table status dynamically without F5)
            setInterval(function() {
                $.post(ajaxurl, {
                    action: 'qqts_get_live_statuses',
                    nonce: '<?php echo esc_js($heartbeat_nonce); ?>'
                }, function(res) {
                    if (res.success && res.data) {
                        res.data.forEach(function(item) {
                            var $row = $('tr[data-code="' + item.ticket_code + '"]');
                            if ($row.length) {
                                var $statusCell = $row.find('.qqts-status-cell');
                                var $usedAtCell = $row.find('.qqts-used-at-cell');
                                
                                if (item.status === 'used') {
                                    $statusCell.html('<span style="color: #dc3232; font-weight: bold;">🔴 <?php echo esc_js(__('Used', 'quick-qr-ticket-scanner')); ?></span>');
                                    $usedAtCell.text(item.used_at || '-');
                                } else {
                                    $statusCell.html('<span style="color: #46b450; font-weight: bold;">🟢 <?php echo esc_js(__('Valid', 'quick-qr-ticket-scanner')); ?></span>');
                                    $usedAtCell.text('-');
                                }
                            }
                        });
                    }
                });
            }, 3500); // 3.5s silent live heartbeat
        });
        </script>
        <?php
    }
}
