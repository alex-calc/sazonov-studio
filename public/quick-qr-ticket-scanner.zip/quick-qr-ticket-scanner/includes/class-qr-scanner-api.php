<?php
if (!defined('ABSPATH')) exit;

class QQTS_API {
    public static function init() {
        add_action('wp_ajax_qqts_check_in', [__CLASS__, 'ajax_check_in']);
        add_action('wp_ajax_nopriv_qqts_check_in', [__CLASS__, 'ajax_check_in']);
        add_action('wp_ajax_qqts_get_live_statuses', [__CLASS__, 'ajax_get_live_statuses']);
        add_action('template_redirect', [__CLASS__, 'handle_scanner_endpoint']);
        add_shortcode('quick_qr_scanner', [__CLASS__, 'render_scanner_shortcode']);
    }

    public static function ajax_get_live_statuses() {
        check_ajax_referer('qqts_admin_heartbeat_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }

        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        $results = $wpdb->get_results("SELECT ticket_code, status, used_at FROM $table ORDER BY id DESC LIMIT 100", ARRAY_A);

        wp_send_json_success($results);
    }

    public static function handle_scanner_endpoint() {
        if (isset($_GET['qqts_scanner']) && $_GET['qqts_scanner'] == '1') {
            include QQTS_PLUGIN_DIR . 'templates/scanner-hud.php';
            exit;
        }
    }

    public static function render_scanner_shortcode() {
        ob_start();
        include QQTS_PLUGIN_DIR . 'templates/scanner-hud.php';
        return ob_get_clean();
    }

    public static function ajax_check_in() {
        check_ajax_referer('qqts_scanner_nonce', 'nonce');

        // Security: Rate Limiting
        $client_ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
        $transient_key = 'qqts_rate_' . md5($client_ip);
        $attempts = (int) get_transient($transient_key);
        if ($attempts > 20) {
            wp_send_json_error(['message' => __('Rate limit exceeded. Please wait 5 seconds.', 'quick-qr-ticket-scanner')]);
        }
        set_transient($transient_key, $attempts + 1, 5);

        $code = sanitize_text_field($_POST['ticket_code'] ?? '');
        if (empty($code)) {
            wp_send_json_error(['message' => __('Invalid QR code data.', 'quick-qr-ticket-scanner')]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE ticket_code = %s", $code));

        if (!$ticket) {
            wp_send_json_error([
                'is_invalid' => true,
                'message' => __('❌ TICKET NOT FOUND / INVALID QR', 'quick-qr-ticket-scanner')
            ]);
        }

        if ($ticket->status === 'used') {
            // Send Security Alarm to Telegram
            if (class_exists('QQTS_Telegram')) {
                QQTS_Telegram::notify_gate_alarm($ticket);
            }

            wp_send_json_error([
                'is_duplicate' => true,
                'used_at' => $ticket->used_at,
                'guest_name' => $ticket->guest_name,
                'ticket_type' => $ticket->ticket_type,
                'message' => sprintf(__('⚠️ ALARM: TICKET ALREADY USED on %s', 'quick-qr-ticket-scanner'), date('M j, H:i', strtotime($ticket->used_at)))
            ]);
        }

        // Validate and burn the ticket
        $wpdb->update(
            $table,
            ['status' => 'used', 'used_at' => current_time('mysql')],
            ['id' => $ticket->id]
        );

        // Send Live Gate Check-in Notification to Telegram
        if (class_exists('QQTS_Telegram')) {
            QQTS_Telegram::notify_gate_checkin($ticket);
        }

        wp_send_json_success([
            'guest_name' => $ticket->guest_name ?: 'Valued Guest',
            'ticket_type' => $ticket->ticket_type ?: 'Standard Entry',
            'event_name' => $ticket->event_name ?: 'General Admission',
            'message' => __('✅ ENTRY APPROVED (ACCESS GRANTED)', 'quick-qr-ticket-scanner')
        ]);
    }
}
