<?php
if (!defined('ABSPATH')) exit;

class QQTS_DB {
    public static function install() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'qqts_tickets';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ticket_code varchar(64) NOT NULL,
            guest_name varchar(255) DEFAULT '',
            guest_email varchar(255) DEFAULT '',
            ticket_type varchar(100) DEFAULT 'Standard',
            event_name varchar(255) DEFAULT '',
            order_id bigint(20) DEFAULT 0,
            status varchar(20) DEFAULT 'valid',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            used_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ticket_code (ticket_code)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
