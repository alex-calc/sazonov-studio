<?php
if (!defined('ABSPATH')) exit;

class QQTS_Mailer {

    public static function send_ticket_email($to_email, $guest_name, $event_name, $ticket_type, $price, $code) {
        if (empty($to_email) || !is_email($to_email)) return false;

        $subject = "🎟️ Your E-Ticket Pass: {$event_name} [{$code}]";
        $qr_url  = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($code);

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <no-reply@' . wp_parse_url(home_url(), PHP_URL_HOST) . '>'
        ];

        $html = '<!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif; background-color: #0f172a; margin: 0; padding: 20px; color: #334155;">
            <div style="max-width: 480px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1); border: 1px solid #e2e8f0;">
                
                <!-- Header Banner -->
                <div style="background: linear-gradient(135deg, #0284c7, #0369a1); padding: 24px; text-align: center; color: #ffffff;">
                    <div style="font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; opacity: 0.9;">Official Entry Pass</div>
                    <h1 style="margin: 6px 0 0; font-size: 22px; font-weight: 800; color: #ffffff;">' . esc_html($event_name) . '</h1>
                </div>

                <!-- Body -->
                <div style="padding: 24px; text-align: center;">
                    <p style="font-size: 14px; color: #64748b; margin: 0 0 4px;">Ticket Holder</p>
                    <h2 style="font-size: 20px; font-weight: 700; color: #0f172a; margin: 0 0 12px;">' . esc_html($guest_name) . '</h2>

                    <div style="display: inline-block; background: #e0f2fe; color: #0369a1; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 700; margin-bottom: 20px;">
                        ' . esc_html($ticket_type) . ' • ' . esc_html($price ?: 'Paid') . '
                    </div>

                    <!-- Graphic QR Code -->
                    <div style="background: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 12px; padding: 16px; display: inline-block; margin-bottom: 20px;">
                        <img src="' . esc_url($qr_url) . '" alt="QR Code" width="180" height="180" style="display: block; margin: 0 auto;" />
                    </div>

                    <div style="font-family: Courier New, monospace; font-size: 16px; font-weight: 700; letter-spacing: 2px; color: #0f172a; background: #f1f5f9; padding: 8px 16px; border-radius: 6px; display: inline-block; margin-bottom: 20px;">
                        ' . esc_html($code) . '
                    </div>

                    <p style="font-size: 12px; color: #64748b; margin: 0; line-height: 1.5;">
                        Please present this QR code (on your phone screen or printed) at the entrance for fast digital check-in.
                    </p>
                </div>

                <!-- Footer -->
                <div style="background: #f8fafc; padding: 16px; text-align: center; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8;">
                    Powered by Quick QR Ticket Scanner • ' . esc_html(get_bloginfo('name')) . '
                </div>
            </div>
        </body>
        </html>';

        return wp_mail($to_email, $subject, $html, $headers);
    }
}
