<?php
if (!defined('ABSPATH')) exit;

class QQTS_Telegram {

    private static $option_name = 'qqts_telegram_settings';

    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('wp_ajax_qqts_tg_test_message', [__CLASS__, 'ajax_send_test_message']);

        // WooCommerce Order Hooks
        add_action('woocommerce_order_status_processing', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_order_status_completed', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_payment_complete', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_thankyou', [__CLASS__, 'handle_wc_order'], 10, 1);

        // DP Tickets & Custom Tickets Hooks
        add_action('dpt_order_status_completed', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_order_paid', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_order_status_processing', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_after_order_created', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dp_ticket_created', [__CLASS__, 'handle_ticket_created'], 10, 2);

        // Fallback post save hooks
        add_action('save_post_shop_order', [__CLASS__, 'handle_post_save_order'], 20, 2);
        add_action('save_post_dpt_order', [__CLASS__, 'handle_post_save_order'], 20, 2);
    }

    public static function register_settings() {
        register_setting('qqts_telegram_group', self::$option_name);
    }

    public static function get_options() {
        return get_option(self::$option_name, [
            'enabled'   => '1',
            'bot_token' => '',
            'chat_id'   => ''
        ]);
    }

    public static function ajax_send_test_message() {
        check_ajax_referer('qqts_tg_test_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions.', 'quick-qr-ticket-scanner'));
        }

        $options   = self::get_options();
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';

        if (empty($bot_token) || empty($chat_id)) {
            wp_send_json_error(__('Please enter and save Bot Token and Chat ID first!', 'quick-qr-ticket-scanner'));
        }

        $site_name = get_bloginfo('name');
        $text = "✅ *Quick QR Tickets Telegram Integration is Active!*

Test notification from *{$site_name}* delivered successfully.";
        $res = self::send_message($bot_token, $chat_id, $text);

        if ($res['success']) {
            wp_send_json_success(__('Message delivered to Telegram successfully!', 'quick-qr-ticket-scanner'));
        } else {
            wp_send_json_error($res['error']);
        }
    }

    public static function notify_manual_ticket_created($guest_name, $guest_email, $event_name, $ticket_type, $price, $code) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $msg  = "🎫 *New Ticket Issued (Admin Generator)*

";
        $msg .= "🎉 *Event:* " . esc_html($event_name) . "
";
        $msg .= "👤 *Guest:* " . esc_html($guest_name) . "
";
        if (!empty($guest_email)) {
            $msg .= "📧 *Email:* " . esc_html($guest_email) . "
";
        }
        $msg .= "🏷️ *Type:* " . esc_html($ticket_type) . "
";
        $msg .= "💰 *Price / Fee:* " . esc_html($price ?: '0.00 EUR') . "
";
        $msg .= "🔑 *Code:* `" . esc_html($code) . "`
";
        $msg .= "🟢 *Status:* Ready for entry";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function notify_gate_checkin($ticket) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $time = current_time('H:i:s (d.m.Y)');
        $msg  = "🎟️ *Gate Check-in: Access Granted*

";
        $msg .= "👤 *Guest:* " . esc_html($ticket->guest_name ?: 'Guest') . "
";
        $msg .= "🎫 *Type:* " . esc_html($ticket->ticket_type ?: 'Standard') . "
";
        $msg .= "🎉 *Event:* " . esc_html($ticket->event_name ?: 'Main Event') . "
";
        $msg .= "🔑 *Code:* `" . esc_html($ticket->ticket_code) . "`
";
        $msg .= "⏰ *Checked-in:* {$time}";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function notify_gate_alarm($ticket) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $time = current_time('H:i:s');
        $msg  = "🚨 *SECURITY ALARM: Duplicate Ticket Attempt*

";
        $msg .= "👤 *Guest on Ticket:* " . esc_html($ticket->guest_name ?: 'Guest') . "
";
        $msg .= "🔑 *Code:* `" . esc_html($ticket->ticket_code) . "`
";
        $msg .= "⚠️ *Originally Used:* " . esc_html($ticket->used_at) . "
";
        $msg .= "⛔ *Attempt Time:* {$time}
";
        $msg .= "_Staff at the door rejected entry._";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function handle_ticket_created($ticket_id, $order_id = 0) {
        $target_id = $order_id ? $order_id : $ticket_id;
        self::handle_wc_order($target_id);
    }

    public static function handle_dpt_order($order_id) {
        self::handle_wc_order($order_id);
    }

    public static function handle_post_save_order($post_id, $post = null) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        self::handle_wc_order($post_id);
    }

    public static function handle_wc_order($order_id) {
        if (!$order_id) return;

        if (is_object($order_id) && method_exists($order_id, 'get_id')) {
            $order_id = $order_id->get_id();
        }

        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;

        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $already_sent = get_post_meta($order_id, '_qqts_tg_sent', true);
        if ($already_sent === 'yes') return;

        $event_name     = 'Event Ticket Order';
        $customer_name  = 'Customer';
        $customer_email = '';
        $customer_phone = '';
        $tickets_count  = 1;
        $total_amount   = '0.00';
        $currency       = 'EUR';

        // Extract from WooCommerce Order
        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && is_object($order)) {
                $fname = method_exists($order, 'get_billing_first_name') ? $order->get_billing_first_name() : '';
                $lname = method_exists($order, 'get_billing_last_name') ? $order->get_billing_last_name() : '';
                $cname = trim($fname . ' ' . $lname);
                if (!empty($cname)) $customer_name = $cname;

                if (method_exists($order, 'get_billing_email')) $customer_email = $order->get_billing_email();
                if (method_exists($order, 'get_billing_phone')) $customer_phone = $order->get_billing_phone();
                if (method_exists($order, 'get_total')) $total_amount = $order->get_total();
                if (method_exists($order, 'get_currency')) $currency = $order->get_currency() ?: 'EUR';

                if (method_exists($order, 'get_items')) {
                    $items = $order->get_items();
                    $item_names = [];
                    $total_qty = 0;
                    foreach ($items as $item) {
                        if (is_object($item)) {
                            $item_names[] = $item->get_name();
                            $total_qty += method_exists($item, 'get_quantity') ? $item->get_quantity() : 1;
                        }
                    }
                    if (!empty($item_names)) $event_name = implode(', ', $item_names);
                    if ($total_qty > 0) $tickets_count = $total_qty;
                }
            }
        }

        // Meta Fallbacks
        $meta_event = get_post_meta($order_id, 'dpt_event_title', true) 
                   ?: get_post_meta($order_id, '_event_name', true)
                   ?: get_post_meta($order_id, 'event_title', true);
        if ($meta_event) $event_name = $meta_event;

        $meta_client = get_post_meta($order_id, 'dpt_customer_name', true)
                    ?: get_post_meta($order_id, '_billing_first_name', true);
        if ($meta_client) $customer_name = $meta_client;

        $meta_email = get_post_meta($order_id, 'dpt_customer_email', true)
                   ?: get_post_meta($order_id, '_billing_email', true);
        if ($meta_email) $customer_email = $meta_email;

        $meta_phone = get_post_meta($order_id, 'dpt_customer_phone', true)
                   ?: get_post_meta($order_id, '_billing_phone', true);
        if ($meta_phone) $customer_phone = $meta_phone;

        $meta_total = get_post_meta($order_id, '_order_total', true)
                   ?: get_post_meta($order_id, 'dpt_total_price', true);
        if ($meta_total) $total_amount = $meta_total;

        $meta_qty = get_post_meta($order_id, 'dpt_ticket_quantity', true)
                 ?: get_post_meta($order_id, '_ticket_qty', true);
        if ($meta_qty) $tickets_count = intval($meta_qty);

        $admin_order_url = admin_url("post.php?post={$order_id}&action=edit");

        // Format Telegram Message
        $msg  = "🔔 *New Ticket Order!*

";
        $msg .= "🎉 *Event:* " . esc_html($event_name) . "
";
        $msg .= "👤 *Customer:* " . esc_html($customer_name) . "
";
        if (!empty($customer_email)) {
            $msg .= "📧 *Email:* " . esc_html($customer_email) . "
";
        }
        if (!empty($customer_phone)) {
            $msg .= "📱 *Phone:* " . esc_html($customer_phone) . "
";
        }
        $msg .= "🎫 *Quantity:* " . intval($tickets_count) . " ticket(s)
";
        $msg .= "💰 *Total:* " . esc_html($total_amount) . " " . esc_html($currency) . "
";
        $msg .= "🆔 *Order ID:* #{$order_id}

";
        $msg .= "🔗 [View in WP Admin]({$admin_order_url})";

        $res = self::send_message($bot_token, $chat_id, $msg);
        if ($res['success']) {
            update_post_meta($order_id, '_qqts_tg_sent', 'yes');
        }
    }

    public static function send_message($bot_token, $chat_id, $text) {
        $api_url = "https://api.telegram.org/bot{$bot_token}/sendMessage";

        $args = [
            'body' => [
                'chat_id'                  => $chat_id,
                'text'                     => $text,
                'parse_mode'               => 'Markdown',
                'disable_web_page_preview' => true,
            ],
            'timeout'   => 15,
            'sslverify' => true,
        ];

        $response = wp_remote_post($api_url, $args);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && isset($body['ok']) && $body['ok'] === true) {
            return ['success' => true];
        }

        $err = isset($body['description']) ? $body['description'] : "HTTP Error {$code}";
        return ['success' => false, 'error' => $err];
    }
}
