<?php
if (!defined('ABSPATH')) exit;

class QQTS_WooCommerce {
    public static function init() {
        if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
            return;
        }
        add_action('woocommerce_order_status_completed', [__CLASS__, 'generate_order_tickets']);
        add_action('woocommerce_email_after_order_table', [__CLASS__, 'attach_qr_to_email'], 10, 4);
    }

    public static function generate_order_tickets($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';

        foreach ($order->get_items() as $item) {
            $code = 'WC-' . $order_id . '-' . strtoupper(wp_generate_password(6, false, false));
            $wpdb->insert($table, [
                'ticket_code' => $code,
                'guest_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'guest_email' => $order->get_billing_email(),
                'ticket_type' => $item->get_name(),
                'event_name' => get_bloginfo('name'),
                'order_id' => $order_id,
                'status' => 'valid'
            ]);
        }
    }

    public static function attach_qr_to_email($order, $sent_to_admin, $plain_text, $email) {
        if ($sent_to_admin || $plain_text) return;
        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        $tickets = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE order_id = %d", $order->get_id()));

        if (empty($tickets)) return;

        echo '<div style="margin: 20px 0; padding: 15px; border: 2px dashed #10b981; border-radius: 8px; text-align: center; background: #f8fafc;">';
        echo '<h3 style="color: #047857; margin-top: 0;">🎟️ Your Electronic Entry Pass</h3>';
        echo '<p style="color: #475569;">Show this ticket code at the entrance for instant check-in:</p>';
        foreach ($tickets as $t) {
            echo '<div style="display: inline-block; margin: 10px; padding: 15px; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">';
            echo '<div style="font-size: 28px; font-weight: 800; letter-spacing: 2px; color: #0f172a; padding: 10px; background: #f1f5f9; border-radius: 6px; margin-bottom: 8px; font-family: monospace;">' . esc_html($t->ticket_code) . '</div>';
            echo '<strong style="color: #1e293b;">' . esc_html($t->guest_name) . '</strong><br>';
            echo '<small style="color: #64748b;">' . esc_html($t->ticket_type) . '</small>';
            echo '</div>';
        }
        echo '</div>';
    }
}
