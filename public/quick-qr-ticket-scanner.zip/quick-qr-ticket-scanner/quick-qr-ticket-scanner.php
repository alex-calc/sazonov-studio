<?php
/**
 * Plugin Name: Quick QR Ticket Scanner & Telegram Notifier Pro
 * Plugin URI: https://wordpress.org/plugins/quick-qr-ticket-scanner/
 * Description: Lightweight, mobile-friendly QR code ticket generator, laser camera check-in scanner, and instant multi-hook Telegram notifications for events, festivals, nightclubs, and WooCommerce.
 * Version: 2.0.0
 * Author: Alexander Sazonov
 * Author URI: https://freelancehunt.com/freelancer/alex_saz.html
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-qr-ticket-scanner
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('QQTS_VERSION', '2.0.0');
define('QQTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QQTS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Declare WooCommerce HPOS compatibility
add_action('before_woocommerce_init', function() {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});

// Exclude live door scanner from cache engines
add_filter('rocket_cache_reject_uri', function($uris) {
    $uris[] = '/(.*)qqts_scanner=(.*)';
    return $uris;
});

require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-db.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-api.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-admin.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-woocommerce.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-telegram.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-mailer.php';

register_activation_hook(__FILE__, ['QQTS_DB', 'install']);

add_action('plugins_loaded', 'qqts_init');
function qqts_init() {
    load_plugin_textdomain('quick-qr-ticket-scanner', false, dirname(plugin_basename(__FILE__)) . '/languages');
    QQTS_API::init();
    QQTS_Admin::init();
    QQTS_WooCommerce::init();
    QQTS_Telegram::init();
}
