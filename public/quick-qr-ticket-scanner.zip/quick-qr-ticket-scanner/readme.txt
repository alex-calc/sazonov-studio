=== Quick QR Ticket Scanner & Entry Check-in ===
Contributors: alex_saz
Tags: ticket scanner, qr code scanner, event check in, woocommerce tickets, mobile qr scanner
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight, mobile-friendly QR code ticket generator and laser camera check-in scanner for events, nightclubs, festivals, and WooCommerce. Zero mobile apps required.

== Description ==

**Quick QR Ticket Scanner & Entry Check-in** is the fastest and easiest solution to turn any smartphone into a professional door entry ticket scanner for events, concerts, nightclubs, conferences, and parties.

### 🚀 Why choose Quick QR Ticket Scanner?

* **Zero App Download Required:** Bouncers, security, and event staff simply open a secured web link on their smartphone (iPhone / Android) and scan tickets in 1 second using the phone camera.
* **Anti-Fraud & Duplicate Protection:** Instant red alert screen, vibration, and loud buzzer alarm if a ticket was already used, showing the exact time of the previous scan.
* **Audio & Haptic Feedback:** Pleasing green chime and vibration for valid guest admission; alarming buzzer for invalid or duplicate passes.
* **WooCommerce Automated Pass Delivery:** Automatically attaches printable QR code entry tickets to WooCommerce order confirmation emails.
* **Ultra Lightweight:** Sub-50KB codebase. Zero external bloated dependencies. Won't slow down your website.

### 🎯 Perfect for:
* Nightclubs & DJ Parties
* Music Festivals & Concerts
* Business Conferences & Workshops
* Stand-up Comedy Shows
* Private Events & Guest Lists

== Installation ==

1. Upload the `quick-qr-ticket-scanner` folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to **QR Tickets** in your admin menu to create manual tickets or view recent admissions.
4. Share the Live Scanner URL (`yoursite.com/?qqts_scanner=1`) with your door staff!

== Frequently Asked Questions ==

= Do my staff need to download an app from Google Play or the App Store? =
No! The scanner works directly inside any mobile browser (Safari, Chrome, Firefox) on any smartphone with camera support.

= How does the anti-duplicate system work? =
The moment a QR code is scanned and approved, its database status instantly switches to 'used' with a timestamp. If someone tries to enter again with a screenshot or duplicate copy, the scanner flashes a red screen and sounds an alarm.

= Does it work with WooCommerce? =
Yes! If WooCommerce is installed, electronic tickets with QR codes are automatically generated upon order completion and embedded directly into customer emails.

== Changelog ==

= 1.0.0 =
* Initial public release.
* Real-time camera scanner with audio/vibration feedback.
* Duplicate prevention engine.
* WooCommerce order integration.
