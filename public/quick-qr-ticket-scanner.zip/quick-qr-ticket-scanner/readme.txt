=== Quick QR Ticket Scanner & Telegram Notifier Pro ===
Contributors: alex_saz
Tags: ticket scanner, qr code scanner, event check in, telegram bot notifications, woocommerce tickets
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight, mobile-friendly QR code ticket generator, laser camera check-in scanner, and instant multi-hook Telegram notifications for events, nightclubs, festivals, and WooCommerce. Zero mobile apps required.

== Description ==

**Quick QR Ticket Scanner & Telegram Notifier Pro** is the fastest and easiest solution to turn any smartphone into a professional door entry ticket scanner for events, concerts, nightclubs, conferences, and parties with real-time Telegram alerts.

### 🚀 Why choose Quick QR Ticket Scanner?

* **Zero App Download Required:** Bouncers, security, and event staff simply open a secured web link on their smartphone (iPhone / Android) and scan tickets in 1 second using the phone camera.
* **Real-time Telegram Notifications & Security Alarms:** Instant Telegram alerts whenever tickets are generated, checked in, or when unauthorized duplicate entry attempts occur.
* **Anti-Fraud & Duplicate Protection:** Instant red alert screen, vibration, and loud buzzer alarm if a ticket was already used, showing the exact time of the previous scan.
* **Audio & Haptic Feedback:** Pleasing green chime and vibration for valid guest admission; alarming buzzer for invalid or duplicate passes.
* **WooCommerce Automated Pass Delivery:** Automatically attaches printable QR code entry tickets to WooCommerce order confirmation emails.
* **International & Multi-language Ready:** Native English defaults, full WPML/Polylang/Loco Translate compatibility, and bundled translation packs.
* **Ultra Lightweight:** Sub-50KB codebase. Zero external bloated dependencies. Won't slow down your website.

### 🎯 Perfect for:
* Nightclubs & DJ Parties
* Music Festivals & Concerts
* Business Conferences & Workshops
* Stand-up Comedy Shows
* Private Events & Guest Lists

== Installation ==

1. Upload the `quick-qr-ticket-scanner` folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to **QR Tickets** in your admin menu to create manual tickets or view recent admissions.
4. (Optional) Configure your Telegram Bot Token & Chat ID in the Telegram tab for real-time notifications.
5. Share the Live Scanner URL (`yoursite.com/?qqts_scanner=1`) with your door staff!

== Frequently Asked Questions ==

= Do my staff need to download an app from Google Play or the App Store? =
No! The scanner works directly inside any mobile browser (Safari, Chrome, Firefox) on any smartphone with camera support.

= How does the anti-duplicate system work? =
The moment a QR code is scanned and approved, its database status instantly switches to 'used' with a timestamp. If someone tries to enter again with a screenshot or duplicate copy, the scanner flashes a red screen, sounds an alarm, and pushes a security alert to your Telegram.

= Does it work with WooCommerce? =
Yes! If WooCommerce is installed, electronic tickets with QR codes are automatically generated upon order completion and embedded directly into customer emails.

== Changelog ==

= 2.0.0 =
* Full Telegram Bot multi-hook notification system.
* International English default engine + German, Ukrainian, Russian language packages.
* High-performance camera scanner with audio/vibration feedback.
* High-Performance Order Storage (HPOS) WooCommerce compatibility.
* Automated duplicate prevention and security audit logging.
