<?php
if (!defined('ABSPATH')) exit;
$nonce = wp_create_nonce('qqts_scanner_nonce');
$ajax_url = admin_url('admin-ajax.php');
$scanner_js = QQTS_PLUGIN_URL . 'assets/js/html5-qrcode.min.js';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>🎟️ Entry Pass Scanner</title>
    <script src="<?php echo esc_url($scanner_js); ?>"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #090d16; color: #fff; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding: 12px; overflow: hidden; }
        .scanner-header { text-align: center; margin-bottom: 12px; width: 100%; max-width: 420px; }
        .scanner-header h1 { font-size: 18px; font-weight: 800; color: #38bdf8; letter-spacing: 1px; text-transform: uppercase; }
        .scanner-container { width: 100%; max-width: 420px; aspect-ratio: 1/1; background: #1e293b; border-radius: 24px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.8); border: 2px solid #334155; position: relative; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        #reader { width: 100%; height: 100%; }
        #reader video { object-fit: cover !important; width: 100% !important; height: 100% !important; border-radius: 20px; }
        
        /* Laser Beam */
        .laser-line { position: absolute; left: 5%; width: 90%; height: 3px; background: #38bdf8; box-shadow: 0 0 16px #38bdf8, 0 0 32px #0ea5e9; animation: scan 2s infinite linear; pointer-events: none; z-index: 10; display: none; }
        @keyframes scan { 0% { top: 15%; } 50% { top: 85%; } 100% { top: 15%; } }

        /* Full Overlay Alert Card */
        .hud-overlay { position: absolute; inset: 0; z-index: 50; display: none; flex-direction: column; align-items: center; justify-content: center; padding: 24px; text-align: center; backdrop-filter: blur(8px); animation: pop 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .hud-overlay.valid { background: rgba(6, 95, 70, 0.94); border: 3px solid #10b981; display: flex; }
        .hud-overlay.duplicate { background: rgba(136, 19, 55, 0.96); border: 3px solid #f43f5e; display: flex; animation: shake 0.4s ease; }
        .hud-overlay.invalid { background: rgba(120, 53, 15, 0.94); border: 3px solid #f59e0b; display: flex; }
        
        .hud-icon { font-size: 52px; margin-bottom: 8px; }
        .hud-title { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; margin-bottom: 8px; text-transform: uppercase; }
        .hud-desc { font-size: 15px; font-weight: 500; opacity: 0.95; line-height: 1.4; background: rgba(0,0,0,0.3); padding: 8px 14px; border-radius: 10px; max-width: 90%; }
        
        .wake-status { font-size: 11px; color: #10b981; margin-top: 8px; text-align: center; }

        @keyframes pop { 0% { transform: scale(0.85); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
        @keyframes shake { 0%, 100% { transform: translateX(0); } 20%, 60% { transform: translateX(-10px); } 40%, 80% { transform: translateX(10px); } }
    </style>
</head>
<body>
    <div class="scanner-header">
        <h1>🎟️ ENTRY PASS SCANNER</h1>
        <p style="color: #64748b; font-size: 12px; margin-top: 2px;">Aim camera at visitor's QR ticket</p>
    </div>

    <div class="scanner-container" id="scanner-wrap" onclick="restartCameraIfFrozen()">
        <div class="laser-line" id="laser"></div>
        <div id="reader"></div>
        
        <!-- Live HUD Overlay inside camera container -->
        <div class="hud-overlay" id="hud-overlay">
            <div class="hud-icon" id="hud-icon">✅</div>
            <div class="hud-title" id="hud-title">ACCESS GRANTED</div>
            <div class="hud-desc" id="hud-desc"></div>
        </div>
    </div>

    <p class="wake-status" id="wake-status">🟢 Always-On Active (Screen won't sleep)</p>

    <script>
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        function playSuccessChime() {
            try {
                if (audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15);
                gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.3);
            } catch(e) {}
            if (navigator.vibrate) navigator.vibrate(120);
        }

        function playAlarmBuzzer() {
            try {
                if (audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(200, audioCtx.currentTime);
                osc.frequency.linearRampToValueAtTime(100, audioCtx.currentTime + 0.35);
                gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.4);
            } catch(e) {}
            if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 300]);
        }

        // Screen Wake Lock API (Keeps screen ON continuously)
        let wakeLock = null;
        async function requestWakeLock() {
            try {
                if ('wakeLock' in navigator) {
                    wakeLock = await navigator.wakeLock.request('screen');
                    wakeLock.addEventListener('release', () => {});
                }
            } catch (err) {}
        }
        requestWakeLock();

        let isScanning = true;
        let html5QrCode = null;

        function onScanSuccess(decodedText) {
            if (!isScanning) return;
            isScanning = false;
            document.getElementById('laser').style.display = 'none';

            const formData = new FormData();
            formData.append('action', 'qqts_check_in');
            formData.append('nonce', '<?php echo esc_attr($nonce); ?>');
            formData.append('ticket_code', decodedText);

            fetch('<?php echo esc_url($ajax_url); ?>', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const overlay = document.getElementById('hud-overlay');
                const icon = document.getElementById('hud-icon');
                const title = document.getElementById('hud-title');
                const desc = document.getElementById('hud-desc');

                if (data.success) {
                    playSuccessChime();
                    overlay.className = 'hud-overlay valid';
                    icon.innerText = '✅';
                    title.innerText = 'ACCESS GRANTED';
                    desc.innerHTML = '<strong>' + data.data.guest_name + '</strong><br>' + data.data.ticket_type + ' • ' + (data.data.event_name || 'VIP Event');
                } else {
                    playAlarmBuzzer();
                    if (data.data && data.data.is_duplicate) {
                        overlay.className = 'hud-overlay duplicate';
                        icon.innerText = '⛔';
                        title.innerText = 'ALREADY USED!';
                        desc.innerHTML = data.data.message + '<br><strong>' + (data.data.guest_name || '') + ' (' + (data.data.ticket_type || '') + ')</strong>';
                    } else {
                        overlay.className = 'hud-overlay invalid';
                        icon.innerText = '⚠️';
                        title.innerText = 'INVALID QR';
                        desc.innerText = data.data.message || 'Ticket code not found in database';
                    }
                }

                setTimeout(() => {
                    overlay.className = 'hud-overlay';
                    overlay.style.display = 'none';
                    isScanning = true;
                    document.getElementById('laser').style.display = 'block';
                }, 2800);
            })
            .catch(err => {
                isScanning = true;
                document.getElementById('laser').style.display = 'block';
            });
        }

        function initCamera() {
            if (html5QrCode) {
                try { html5QrCode.stop().catch(()=>{}); } catch(e) {}
            }
            html5QrCode = new Html5Qrcode("reader");
            html5QrCode.start(
                { facingMode: "environment" },
                { fps: 20, qrbox: { width: 260, height: 260 } },
                onScanSuccess
            ).then(() => {
                document.getElementById('laser').style.display = 'block';
                isScanning = true;
            }).catch(err => {
                console.error("Camera start error:", err);
            });
        }

        function restartCameraIfFrozen() {
            initCamera();
        }

        // Auto wake camera when phone unlocks or user returns to tab
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                requestWakeLock();
                initCamera();
            }
        });

        window.addEventListener('focus', () => {
            requestWakeLock();
            initCamera();
        });

        // Initial Start
        initCamera();
    </script>
</body>
</html>
