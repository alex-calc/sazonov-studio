/* Quick Order Notifier for Telegram - Admin Scripts */
(function($) {
	'use strict';

	// Safe helper: renders a status prefix as HTML, then appends message as safe text.
	function showResult($el, type, message) {
		var prefix = type === 'success' ? '<strong>✓</strong> ' : '<strong>⚠ Error:</strong> ';
		$el.addClass(type === 'success' ? 'is-success' : 'is-error')
		   .html(prefix)
		   .append($('<span>').text(message))
		   .slideDown();
	}

	$(document).ready(function() {
		// Send Test Message
		$('#qont-send-test-btn').on('click', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $res = $('#qont-test-result');

			$btn.prop('disabled', true).text(qontAdmin.strings.sending);
			$res.hide().removeClass('is-success is-error');

			$.post(qontAdmin.ajaxUrl, {
				action: 'qont_send_test_message',
				nonce: qontAdmin.nonce
			})
			.done(function(resp) {
				showResult($res, resp.success ? 'success' : 'error', resp.data.message);
			})
			.fail(function() {
				showResult($res, 'error', 'Network connection failed.');
			})
			.always(function() {
				$btn.prop('disabled', false).text('Send Test Message');
			});
		});

		// Register Webhook
		$('#qont-register-webhook-btn').on('click', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $res = $('#qont-webhook-result');

			$btn.prop('disabled', true).text(qontAdmin.strings.registering);
			$res.hide().removeClass('is-success is-error');

			$.post(qontAdmin.ajaxUrl, {
				action: 'qont_register_webhook',
				nonce: qontAdmin.nonce
			})
			.done(function(resp) {
				showResult($res, resp.success ? 'success' : 'error', resp.data.message);
			})
			.fail(function() {
				showResult($res, 'error', 'Webhook registration failed.');
			})
			.always(function() {
				$btn.prop('disabled', false).text('Register Webhook');
			});
		});

		// Delete Webhook
		$('#qont-delete-webhook-btn').on('click', function(e) {
			e.preventDefault();
			if (!confirm('Are you sure you want to unregister the Telegram Webhook?')) {
				return;
			}
			var $btn = $(this);
			var $res = $('#qont-webhook-result');

			$btn.prop('disabled', true).text(qontAdmin.strings.deleting);
			$res.hide().removeClass('is-success is-error');

			$.post(qontAdmin.ajaxUrl, {
				action: 'qont_delete_webhook',
				nonce: qontAdmin.nonce
			})
			.done(function(resp) {
				showResult($res, resp.success ? 'success' : 'error', resp.data.message);
			})
			.fail(function() {
				showResult($res, 'error', 'Unregistration failed.');
			})
			.always(function() {
				$btn.prop('disabled', false).text('Unregister');
			});
		});
	});
})(jQuery);
