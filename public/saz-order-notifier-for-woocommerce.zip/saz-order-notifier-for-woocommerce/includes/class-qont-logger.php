<?php
/**
 * Activity logger and database manager.
 */

defined( 'ABSPATH' ) || exit;

class QONT_Logger {

	private static $instance = null;
	const DB_VERSION = '1.0.0';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		// Table creation check on version upgrade.
		if ( get_option( 'qont_db_version' ) !== self::DB_VERSION ) {
			self::create_tables();
		}
	}

	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'qont_log';
	}

	public static function create_tables() {
		global $wpdb;
		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			event varchar(50) NOT NULL DEFAULT '',
			telegram_message_id bigint(20) DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'sent',
			note text DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY order_id (order_id),
			KEY created_at (created_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( 'qont_db_version', self::DB_VERSION );
	}

	public static function log( $order_id, $event, $telegram_message_id = null, $status = 'sent', $note = '' ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$wpdb->prefix . 'qont_log',
			array(
				'order_id'            => absint( $order_id ),
				'event'               => sanitize_text_field( $event ),
				'telegram_message_id' => $telegram_message_id ? intval( $telegram_message_id ) : null,
				'status'              => sanitize_text_field( $status ),
				'note'                => sanitize_text_field( $note ),
				'created_at'          => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%d', '%s', '%s', '%s' )
		);

		// Prune logs to keep only the last 50 entries to preserve DB performance.
		self::prune_logs( 50 );
	}

	private static function prune_logs( $keep = 50 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$count = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$wpdb->prefix}qont_log" );

		if ( $count > $keep ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$min_id_to_keep = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$wpdb->prefix}qont_log ORDER BY id DESC LIMIT 1 OFFSET %d",
					$keep - 1
				)
			);
			if ( $min_id_to_keep ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$wpdb->query(
					$wpdb->prepare(
						"DELETE FROM {$wpdb->prefix}qont_log WHERE id < %d",
						$min_id_to_keep
					)
				);
			}
		}
	}

	public static function get_recent_logs( $limit = 20 ) {
		global $wpdb;
		$limit = absint( $limit );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}qont_log ORDER BY id DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);
	}
}
