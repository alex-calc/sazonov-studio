<?php
/**
 * Order events monitor and Telegram message builder.
 *
 * Fully compliant with WooCommerce HPOS and Classic Storage.
 */

defined( 'ABSPATH' ) || exit;

class QONT_Notifier {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		// Trigger on new order creation.
		add_action( 'woocommerce_new_order', array( $this, 'on_new_order' ), 20, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_checkout_order_processed' ), 20, 1 );

		// Trigger on order status change.
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 20, 4 );
	}

	public function on_new_order( $order_id, $order = null ) {
		$this->process_order_event( $order_id, 'new_order', $order );
	}

	public function on_checkout_order_processed( $order_id ) {
		$this->process_order_event( $order_id, 'new_order' );
	}

	public function on_order_status_changed( $order_id, $old_status, $new_status, $order = null ) {
		$settings = get_option( 'qont_settings', array() );
		if ( empty( $settings['notify_status_change'] ) ) {
			return;
		}

		// Avoid double notification if new order status was just sent.
		if ( 'pending' === $old_status && 'on-hold' === $new_status ) {
			return;
		}

		// Skip if status was changed by our own Telegram webhook action button.
		// The webhook sets this transient before calling update_status() to prevent
		// a second "Status Changed" card appearing right after the "Confirmed/Cancelled" badge.
		if ( false !== get_transient( 'qont_suppress_status_' . $order_id ) ) {
			delete_transient( 'qont_suppress_status_' . $order_id );
			return;
		}

		$this->process_order_event( $order_id, 'status_changed', $order, $old_status, $new_status );
	}

	private function process_order_event( $order_id, $event_type, $order = null, $old_status = '', $new_status = '' ) {
		$order_id = absint( $order_id );
		if ( ! $order_id ) {
			return;
		}

		// FIX #1: Prevent duplicate notifications from both hooks (woocommerce_new_order +
		// woocommerce_checkout_order_processed) firing in the same HTTP request.
		// A single shared dedup key covers both hooks for the same order.
		if ( 'new_order' === $event_type ) {
			$dedup_key = 'qont_sent_new_order_' . $order_id;
			if ( false !== get_transient( $dedup_key ) ) {
				return;
			}
			set_transient( $dedup_key, 1, 60 ); // 60-second dedup window.
		}

		$settings = get_option( 'qont_settings', array() );
		$chat_id  = isset( $settings['chat_id'] ) ? trim( $settings['chat_id'] ) : '';

		if ( empty( $chat_id ) ) {
			return;
		}

		// FIX #3: Correct guard — skip new order ONLY when the option is explicitly 0.
		// When the option is absent (fresh install), default to sending (notify by default).
		if ( 'new_order' === $event_type ) {
			$notify = isset( $settings['notify_new_order'] ) ? (int) $settings['notify_new_order'] : 1;
			if ( 0 === $notify ) {
				return;
			}
		}

		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		if ( ! $order ) {
			return;
		}

		$message_text = $this->build_message( $order, $event_type, $old_status, $new_status, $settings );
		$keyboard     = $this->build_action_keyboard( $order );

		$telegram = new QONT_Telegram();
		$result   = $telegram->send_message( $chat_id, $message_text, $keyboard );

		if ( is_wp_error( $result ) ) {
			QONT_Logger::log( $order_id, $event_type, null, 'error', $result->get_error_message() );
		} else {
			$message_id = isset( $result['message_id'] ) ? $result['message_id'] : null;
			QONT_Logger::log( $order_id, $event_type, $message_id, 'sent', 'Delivered to chat ' . $chat_id );
		}
	}

	public function build_message( $order, $event_type = 'new_order', $old_status = '', $new_status = '', $settings = array() ) {
		if ( empty( $settings ) ) {
			$settings = get_option( 'qont_settings', array() );
		}

		$order_id     = $order->get_id();
		$order_number = $order->get_order_number();
		$status       = wc_get_order_status_name( $order->get_status() );
		$currency     = $order->get_currency();
		$total        = html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $currency ) ) ), ENT_QUOTES, 'UTF-8' );
		$payment_name = $order->get_payment_method_title();

		// Customer info.
		$first_name = $order->get_billing_first_name();
		$last_name  = $order->get_billing_last_name();
		$full_name  = trim( $first_name . ' ' . $last_name );
		if ( empty( $full_name ) ) {
			$full_name = __( 'Guest', 'saz-order-notifier-for-woocommerce' );
		}

		$phone = $order->get_billing_phone();
		$email = $order->get_billing_email();

		// Address info.
		$city       = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
		$address_1  = $order->get_shipping_address_1() ? $order->get_shipping_address_1() : $order->get_billing_address_1();
		$full_addr  = trim( $city . ( $city && $address_1 ? ', ' : '' ) . $address_1 );

		// Header.
		$lines = array();
		if ( 'status_changed' === $event_type ) {
			$old_name = wc_get_order_status_name( $old_status );
			$new_name = wc_get_order_status_name( $new_status );
			$lines[]  = "🔄 <b>Order #{$order_number} Status Updated</b>";
			$lines[]  = "<b>Status:</b> <code>{$old_name}</code> ➔ <b>{$new_name}</b>";
		} else {
			$lines[] = "🛒 <b>New Order #{$order_number}</b>";
			$lines[] = "<b>Status:</b> <b>{$status}</b>";
		}
		$lines[] = "━━━━━━━━━━━━━━━━━━━";

		// Customer details.
		// SECURITY FIX (Claude review): All fields below come from anonymous customer input at checkout.
		// With parse_mode=HTML any unescaped <, >, & will either cause Telegram 400 Bad Request
		// (silently killing the notification) or render attacker-controlled HTML tags in the message.
		// Every customer-controlled value MUST be run through esc_html() before insertion.
		$lines[] = "👤 <b>Customer:</b> " . esc_html( $full_name );
		if ( ! empty( $phone ) && ! empty( $settings['include_phone'] ) ) {
			$lines[] = "📞 <b>Phone:</b> <code>" . esc_html( $phone ) . "</code>";
		}
		if ( ! empty( $email ) && ! empty( $settings['include_email'] ) ) {
			$lines[] = "✉️ <b>Email:</b> " . esc_html( $email );
		}
		if ( ! empty( $full_addr ) && ! empty( $settings['include_address'] ) ) {
			$lines[] = "📍 <b>Destination:</b> " . esc_html( $full_addr );
		}

		// Items list.
		if ( ! empty( $settings['include_items'] ) ) {
			$lines[] = "━━━━━━━━━━━━━━━━━━━";
			$lines[] = "📦 <b>Order Items:</b>";
			foreach ( $order->get_items() as $item ) {
				$item_name  = $item->get_name();
				$item_qty   = $item->get_quantity();
				$item_total = html_entity_decode( wp_strip_all_tags( wc_price( $item->get_total(), array( 'currency' => $currency ) ) ), ENT_QUOTES, 'UTF-8' );
				// Product names are user-defined and can contain HTML special chars.
				$lines[] = "• " . esc_html( $item_name ) . " × <b>{$item_qty}</b> ({$item_total})";
			}
		}

		// Payment & total.
		$lines[] = "━━━━━━━━━━━━━━━━━━━";
		$lines[] = "💰 <b>Total:</b> <b>{$total}</b>";
		if ( ! empty( $payment_name ) ) {
			$lines[] = "💳 <b>Payment:</b> " . esc_html( $payment_name );
		}

		// Customer note — highest-risk field: free-text, anonymous, no moderation.
		$customer_note = $order->get_customer_note();
		if ( ! empty( $customer_note ) ) {
			$lines[] = "━━━━━━━━━━━━━━━━━━━";
			$lines[] = "💬 <b>Note:</b> <i>" . esc_html( $customer_note ) . "</i>";
		}

		return implode( "\n", $lines );
	}

	public function build_action_keyboard( $order ) {
		$order_id     = $order->get_id();
		$current_stat = $order->get_status();

		$keyboard = array();

		// Action buttons only if order is not already completed or cancelled.
		if ( ! in_array( $current_stat, array( 'completed', 'cancelled', 'refunded' ), true ) ) {
			$row1 = array();
			if ( 'processing' !== $current_stat ) {
				$row1[] = array(
					'text'          => '✅ ' . __( 'Confirm', 'saz-order-notifier-for-woocommerce' ),
					'callback_data' => 'qont_confirm_' . $order_id,
				);
			}
			$row1[] = array(
				'text'          => '❌ ' . __( 'Cancel', 'saz-order-notifier-for-woocommerce' ),
				'callback_data' => 'qont_cancel_' . $order_id,
			);
			$keyboard[] = $row1;
		}

		// FIX #6: HPOS-compatible admin URL.
		// wc_get_order_admin_url() returns the correct URL for both HPOS and Classic mode.
		$admin_url  = function_exists( 'wc_get_order_admin_url' )
			? wc_get_order_admin_url( $order_id )
			: admin_url( 'post.php?post=' . $order_id . '&action=edit' );

		$keyboard[] = array(
			array(
				'text' => '🔗 ' . __( 'Open in Admin', 'saz-order-notifier-for-woocommerce' ),
				'url'  => $admin_url,
			),
		);

		return $keyboard;
	}
}
