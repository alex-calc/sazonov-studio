<?php
/**
 * Settings Page and AJAX Handlers.
 */

defined( 'ABSPATH' ) || exit;

class QONT_Settings {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		// AJAX actions.
		add_action( 'wp_ajax_qont_send_test_message', array( $this, 'ajax_send_test_message' ) );
		add_action( 'wp_ajax_qont_register_webhook', array( $this, 'ajax_register_webhook' ) );
		add_action( 'wp_ajax_qont_delete_webhook', array( $this, 'ajax_delete_webhook' ) );
	}

	public function add_admin_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Telegram Notifier', 'saz-order-notifier-for-woocommerce' ),
			__( 'Telegram Notifier', 'saz-order-notifier-for-woocommerce' ),
			'manage_woocommerce',
			'qont-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting( 'qont_settings_group', 'qont_settings', array( $this, 'sanitize_settings' ) );
	}

	public function sanitize_settings( $input ) {
		$output = array();

		// If token contains asterisks, preserve existing token.
		$existing = get_option( 'qont_settings', array() );
		if ( isset( $input['bot_token'] ) ) {
			$raw_token = trim( $input['bot_token'] );
			if ( strpos( $raw_token, '••••' ) !== false && ! empty( $existing['bot_token'] ) ) {
				$output['bot_token'] = $existing['bot_token'];
			} else {
				$output['bot_token'] = sanitize_text_field( $raw_token );
			}
		}

		$output['chat_id']              = isset( $input['chat_id'] ) ? sanitize_text_field( trim( $input['chat_id'] ) ) : '';
		$output['notify_new_order']     = ! empty( $input['notify_new_order'] ) ? 1 : 0;
		$output['notify_status_change'] = ! empty( $input['notify_status_change'] ) ? 1 : 0;
		$output['include_phone']        = ! empty( $input['include_phone'] ) ? 1 : 0;
		$output['include_email']        = ! empty( $input['include_email'] ) ? 1 : 0;
		$output['include_address']      = ! empty( $input['include_address'] ) ? 1 : 0;
		$output['include_items']        = ! empty( $input['include_items'] ) ? 1 : 0;

		return $output;
	}

	public function enqueue_admin_assets( $hook ) {
		if ( 'woocommerce_page_qont-settings' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'qont-admin-css', QONT_PLUGIN_URL . 'assets/admin.css', array(), QONT_VERSION );
		wp_enqueue_script( 'qont-admin-js', QONT_PLUGIN_URL . 'assets/admin.js', array( 'jquery' ), QONT_VERSION, true );

		wp_localize_script(
			'qont-admin-js',
			'qontAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'qont_admin_nonce' ),
				'strings' => array(
					'sending'    => __( 'Sending test message...', 'saz-order-notifier-for-woocommerce' ),
					'registering'=> __( 'Registering webhook with Telegram...', 'saz-order-notifier-for-woocommerce' ),
					'deleting'   => __( 'Removing webhook...', 'saz-order-notifier-for-woocommerce' ),
				),
			)
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$settings   = get_option( 'qont_settings', array() );
		$telegram   = new QONT_Telegram();
		$secret     = get_option( 'qont_webhook_secret' );
		$webhook_url= QONT_Webhook::get_webhook_url();
		$recent_logs= QONT_Logger::get_recent_logs( 10 );

		// Default values for toggles.
		$notify_new_order     = isset( $settings['notify_new_order'] ) ? $settings['notify_new_order'] : 1;
		$notify_status_change = isset( $settings['notify_status_change'] ) ? $settings['notify_status_change'] : 0;
		$include_phone        = isset( $settings['include_phone'] ) ? $settings['include_phone'] : 1;
		$include_email        = isset( $settings['include_email'] ) ? $settings['include_email'] : 1;
		$include_address      = isset( $settings['include_address'] ) ? $settings['include_address'] : 1;
		$include_items        = isset( $settings['include_items'] ) ? $settings['include_items'] : 1;
		$chat_id              = isset( $settings['chat_id'] ) ? $settings['chat_id'] : '';
		$masked_token         = $telegram->get_masked_token();

		?>
		<div class="wrap qont-wrap">
			<div class="qont-header">
				<h1>
					<span class="dashicons dashicons-format-chat"></span>
					<?php esc_html_e( 'Quick Order Notifier for Telegram', 'saz-order-notifier-for-woocommerce' ); ?>
					<span class="qont-badge">v<?php echo esc_html( QONT_VERSION ); ?></span>
				</h1>
				<p class="qont-subtitle">
					<?php esc_html_e( 'Instant WooCommerce order notifications with one-tap Confirm & Cancel inline buttons.', 'saz-order-notifier-for-woocommerce' ); ?>
				</p>
			</div>

			<?php settings_errors(); ?>

			<div class="qont-grid">
				<div class="qont-main-col">
					<form method="post" action="options.php" class="qont-card">
						<?php settings_fields( 'qont_settings_group' ); ?>

						<h2><?php esc_html_e( 'Telegram Bot Credentials', 'saz-order-notifier-for-woocommerce' ); ?></h2>

						<div class="qont-form-row">
							<label for="qont_bot_token"><b><?php esc_html_e( 'Bot Token', 'saz-order-notifier-for-woocommerce' ); ?></b></label>
							<input type="text" id="qont_bot_token" name="qont_settings[bot_token]" value="<?php echo esc_attr( $masked_token ); ?>" placeholder="123456789:ABCdefGhIJKlmNoPQRstuVWXyz" class="regular-text code" />
							<p class="description">
								<?php
								printf(
									/* translators: %s: URL to BotFather */
									esc_html__( 'Obtain a free bot token from %s. Send /newbot to create one.', 'saz-order-notifier-for-woocommerce' ),
									'<a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer">@BotFather</a>'
								);
								?>
							</p>
						</div>

						<div class="qont-form-row">
							<label for="qont_chat_id"><b><?php esc_html_e( 'Recipient Chat ID / Channel ID', 'saz-order-notifier-for-woocommerce' ); ?></b></label>
							<input type="text" id="qont_chat_id" name="qont_settings[chat_id]" value="<?php echo esc_attr( $chat_id ); ?>" placeholder="123456789 or -100123456789" class="regular-text code" />
							<p class="description">
								<?php
								printf(
									/* translators: %s: URL to userinfobot */
									esc_html__( 'Your personal Telegram ID or group/supergroup ID. Tip: use %s to discover your ID.', 'saz-order-notifier-for-woocommerce' ),
									'<a href="https://t.me/userinfobot" target="_blank" rel="noopener noreferrer">@userinfobot</a>'
								);
								?>
							</p>
						</div>

						<hr class="qont-divider" />

						<h2><?php esc_html_e( 'Notification Events & Content', 'saz-order-notifier-for-woocommerce' ); ?></h2>

						<div class="qont-checkbox-list">
							<label>
								<input type="checkbox" name="qont_settings[notify_new_order]" value="1" <?php checked( $notify_new_order, 1 ); ?> />
								<b><?php esc_html_e( 'New Order Created', 'saz-order-notifier-for-woocommerce' ); ?></b>
								<span class="qont-hint"><?php esc_html_e( '(Sends alert immediately when customer places an order)', 'saz-order-notifier-for-woocommerce' ); ?></span>
							</label>

							<label>
								<input type="checkbox" name="qont_settings[notify_status_change]" value="1" <?php checked( $notify_status_change, 1 ); ?> />
								<b><?php esc_html_e( 'Order Status Changed', 'saz-order-notifier-for-woocommerce' ); ?></b>
								<span class="qont-hint"><?php esc_html_e( '(Alerts when status updates e.g. from Processing to Completed)', 'saz-order-notifier-for-woocommerce' ); ?></span>
							</label>
						</div>

						<h3 class="qont-section-sub"><?php esc_html_e( 'Card Fields to Include', 'saz-order-notifier-for-woocommerce' ); ?></h3>

						<div class="qont-checkbox-grid">
							<label>
								<input type="checkbox" name="qont_settings[include_phone]" value="1" <?php checked( $include_phone, 1 ); ?> />
								<?php esc_html_e( 'Customer Phone Number', 'saz-order-notifier-for-woocommerce' ); ?>
							</label>
							<label>
								<input type="checkbox" name="qont_settings[include_email]" value="1" <?php checked( $include_email, 1 ); ?> />
								<?php esc_html_e( 'Customer Email', 'saz-order-notifier-for-woocommerce' ); ?>
							</label>
							<label>
								<input type="checkbox" name="qont_settings[include_address]" value="1" <?php checked( $include_address, 1 ); ?> />
								<?php esc_html_e( 'Shipping / Destination Address', 'saz-order-notifier-for-woocommerce' ); ?>
							</label>
							<label>
								<input type="checkbox" name="qont_settings[include_items]" value="1" <?php checked( $include_items, 1 ); ?> />
								<?php esc_html_e( 'Product Items Breakdown', 'saz-order-notifier-for-woocommerce' ); ?>
							</label>
						</div>

						<?php submit_button( __( 'Save Settings', 'saz-order-notifier-for-woocommerce' ) ); ?>
					</form>

					<div class="qont-card">
						<h2><?php esc_html_e( 'Recent Notification Logs (Last 10)', 'saz-order-notifier-for-woocommerce' ); ?></h2>
						<?php if ( empty( $recent_logs ) ) : ?>
							<p class="description"><?php esc_html_e( 'No notifications logged yet.', 'saz-order-notifier-for-woocommerce' ); ?></p>
						<?php else : ?>
							<table class="widefat striped">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Time', 'saz-order-notifier-for-woocommerce' ); ?></th>
										<th><?php esc_html_e( 'Order', 'saz-order-notifier-for-woocommerce' ); ?></th>
										<th><?php esc_html_e( 'Event', 'saz-order-notifier-for-woocommerce' ); ?></th>
										<th><?php esc_html_e( 'Status', 'saz-order-notifier-for-woocommerce' ); ?></th>
										<th><?php esc_html_e( 'Details', 'saz-order-notifier-for-woocommerce' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $recent_logs as $log ) : ?>
										<tr>
											<td><code><?php echo esc_html( $log['created_at'] ); ?></code></td>
											<td>
												<?php if ( $log['order_id'] ) : ?>
													<a href="<?php echo esc_url( admin_url( 'post.php?post=' . $log['order_id'] . '&action=edit' ) ); ?>" target="_blank">
														#<?php echo esc_html( $log['order_id'] ); ?>
													</a>
												<?php else : ?>
													—
												<?php endif; ?>
											</td>
											<td><code><?php echo esc_html( $log['event'] ); ?></code></td>
											<td>
												<span class="qont-status-tag qont-status-<?php echo esc_attr( $log['status'] ); ?>">
													<?php echo esc_html( $log['status'] ); ?>
												</span>
											</td>
											<td><small><?php echo esc_html( $log['note'] ); ?></small></td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						<?php endif; ?>
					</div>
				</div>

				<div class="qont-side-col">
					<div class="qont-card">
						<h3><?php esc_html_e( '🚀 Test Telegram Connection', 'saz-order-notifier-for-woocommerce' ); ?></h3>
						<p class="description">
							<?php esc_html_e( 'Send an instant test card to your Telegram to confirm credentials are functional.', 'saz-order-notifier-for-woocommerce' ); ?>
						</p>
						<button type="button" id="qont-send-test-btn" class="button button-secondary">
							<?php esc_html_e( 'Send Test Message', 'saz-order-notifier-for-woocommerce' ); ?>
						</button>
						<div id="qont-test-result" class="qont-result-box" style="display:none;"></div>
					</div>

					<div class="qont-card">
						<h3><?php esc_html_e( '⚡ Webhook for Inline Buttons', 'saz-order-notifier-for-woocommerce' ); ?></h3>
						<p class="description">
							<?php esc_html_e( 'Required for one-tap Confirm & Cancel buttons to work directly from Telegram.', 'saz-order-notifier-for-woocommerce' ); ?>
						</p>

						<p><b><?php esc_html_e( 'Endpoint URL:', 'saz-order-notifier-for-woocommerce' ); ?></b><br>
						<code class="qont-code-block"><?php echo esc_html( $webhook_url ); ?></code></p>

						<p><b><?php esc_html_e( 'Secret Token:', 'saz-order-notifier-for-woocommerce' ); ?></b><br>
						<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span> <?php esc_html_e( 'Generated & Hardened', 'saz-order-notifier-for-woocommerce' ); ?></p>

						<div class="qont-btn-row">
							<button type="button" id="qont-register-webhook-btn" class="button button-primary">
								<?php esc_html_e( 'Register Webhook', 'saz-order-notifier-for-woocommerce' ); ?>
							</button>
							<button type="button" id="qont-delete-webhook-btn" class="button button-link-delete">
								<?php esc_html_e( 'Unregister', 'saz-order-notifier-for-woocommerce' ); ?>
							</button>
						</div>
						<div id="qont-webhook-result" class="qont-result-box" style="display:none;"></div>
					</div>

					<div class="qont-card qont-info-card">
						<h3><?php esc_html_e( 'Sazonov Studio Standard', 'saz-order-notifier-for-woocommerce' ); ?></h3>
						<ul class="qont-bullet-list">
							<li><span class="dashicons dashicons-yes"></span> 100% Day-1 HPOS Compatible</li>
							<li><span class="dashicons dashicons-yes"></span> Block & Classic Checkout Ready</li>
							<li><span class="dashicons dashicons-yes"></span> Atomic Race Condition Lock</li>
							<li><span class="dashicons dashicons-yes"></span> Zero external dependencies</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public function ajax_send_test_message() {
		check_ajax_referer( 'qont_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$settings = get_option( 'qont_settings', array() );
		$chat_id  = isset( $settings['chat_id'] ) ? trim( $settings['chat_id'] ) : '';

		if ( empty( $chat_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter and save your Chat ID first.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$telegram = new QONT_Telegram();
		if ( ! $telegram->is_configured() ) {
			wp_send_json_error( array( 'message' => __( 'Please enter and save your Telegram Bot Token first.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$time      = wp_date( 'H:i:s d.m.Y' );

		$text  = "🚀 <b>Connection Successful!</b>
";
		$text .= "━━━━━━━━━━━━━━━━━━━
";
		$text .= "Store: <b>" . esc_html( $site_name ) . "</b>
";
		$text .= "Time: <code>" . esc_html( $time ) . "</code>
";
		$text .= "Plugin: <b>Quick Order Notifier v" . QONT_VERSION . "</b>

";
		$text .= "<i>Your WooCommerce notifications will arrive in this chat.</i>";

		$keyboard = array(
			array(
				array(
					'text' => '✅ ' . __( 'Test Button Works', 'saz-order-notifier-for-woocommerce' ),
					'callback_data' => 'qont_test_click',
				),
			),
		);

		$result = $telegram->send_message( $chat_id, $text, $keyboard );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		QONT_Logger::log( 0, 'test_message', isset( $result['message_id'] ) ? $result['message_id'] : null, 'sent', 'Test message successfully delivered' );

		wp_send_json_success( array( 'message' => __( 'Test notification delivered to Telegram successfully!', 'saz-order-notifier-for-woocommerce' ) ) );
	}

	public function ajax_register_webhook() {
		check_ajax_referer( 'qont_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$telegram = new QONT_Telegram();
		if ( ! $telegram->is_configured() ) {
			wp_send_json_error( array( 'message' => __( 'Please enter and save your Telegram Bot Token first.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$webhook_url  = QONT_Webhook::get_webhook_url();
		$secret_token = get_option( 'qont_webhook_secret' );

		if ( empty( $secret_token ) ) {
			$secret_token = wp_generate_password( 32, false );
			update_option( 'qont_webhook_secret', $secret_token );
		}

		$result = $telegram->set_webhook( $webhook_url, $secret_token );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'Telegram webhook registered successfully! Inline buttons are now active.', 'saz-order-notifier-for-woocommerce' ) ) );
	}

	public function ajax_delete_webhook() {
		check_ajax_referer( 'qont_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'saz-order-notifier-for-woocommerce' ) ) );
		}

		$telegram = new QONT_Telegram();
		$result   = $telegram->delete_webhook();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'Telegram webhook removed.', 'saz-order-notifier-for-woocommerce' ) ) );
	}
}
