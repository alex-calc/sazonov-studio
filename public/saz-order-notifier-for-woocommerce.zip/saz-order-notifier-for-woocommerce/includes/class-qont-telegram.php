<?php
/**
 * Telegram Bot API HTTP Client.
 *
 * Utilizes native wp_remote_post/wp_remote_get. Zero external dependencies.
 */

defined( 'ABSPATH' ) || exit;

class QONT_Telegram {

	private $token;
	private $base_url;

	public function __construct( $token = null ) {
		if ( null === $token ) {
			$settings    = get_option( 'qont_settings', array() );
			$this->token = isset( $settings['bot_token'] ) ? trim( $settings['bot_token'] ) : '';
		} else {
			$this->token = trim( $token );
		}

		$this->base_url = 'https://api.telegram.org/bot' . $this->token . '/';
	}

	public function is_configured() {
		return ! empty( $this->token );
	}

	public function get_masked_token() {
		if ( empty( $this->token ) ) {
			return '';
		}
		$parts = explode( ':', $this->token );
		if ( count( $parts ) === 2 ) {
			return $parts[0] . ':' . substr( $parts[1], 0, 4 ) . '••••••••' . substr( $parts[1], -3 );
		}
		return substr( $this->token, 0, 6 ) . '••••••••' . substr( $this->token, -3 );
	}

	public function send_message( $chat_id, $text, $inline_keyboard = null ) {
		if ( ! $this->is_configured() || empty( $chat_id ) ) {
			return new WP_Error( 'not_configured', __( 'Telegram bot token or Chat ID is missing.', 'saz-order-notifier-for-woocommerce' ) );
		}

		$payload = array(
			'chat_id'                  => $chat_id,
			'text'                     => $text,
			'parse_mode'               => 'HTML',
			'disable_web_page_preview' => true,
		);

		if ( ! empty( $inline_keyboard ) && is_array( $inline_keyboard ) ) {
			$payload['reply_markup'] = wp_json_encode( array( 'inline_keyboard' => $inline_keyboard ) );
		}

		return $this->request( 'sendMessage', $payload );
	}

	public function edit_message_text( $chat_id, $message_id, $text, $inline_keyboard = null ) {
		if ( ! $this->is_configured() ) {
			return new WP_Error( 'not_configured', __( 'Telegram bot token is missing.', 'saz-order-notifier-for-woocommerce' ) );
		}

		$payload = array(
			'chat_id'                  => $chat_id,
			'message_id'               => intval( $message_id ),
			'text'                     => $text,
			'parse_mode'               => 'HTML',
			'disable_web_page_preview' => true,
		);

		if ( ! empty( $inline_keyboard ) && is_array( $inline_keyboard ) ) {
			$payload['reply_markup'] = wp_json_encode( array( 'inline_keyboard' => $inline_keyboard ) );
		}

		return $this->request( 'editMessageText', $payload );
	}

	public function answer_callback_query( $callback_query_id, $text = '', $show_alert = false ) {
		if ( ! $this->is_configured() ) {
			return new WP_Error( 'not_configured', __( 'Telegram bot token is missing.', 'saz-order-notifier-for-woocommerce' ) );
		}

		$payload = array(
			'callback_query_id' => sanitize_text_field( $callback_query_id ),
			'text'              => sanitize_text_field( $text ),
			'show_alert'        => (bool) $show_alert,
		);

		return $this->request( 'answerCallbackQuery', $payload );
	}

	public function set_webhook( $webhook_url, $secret_token ) {
		if ( ! $this->is_configured() ) {
			return new WP_Error( 'not_configured', __( 'Telegram bot token is missing.', 'saz-order-notifier-for-woocommerce' ) );
		}

		// FIX #5: setWebhook must send JSON body (not form-encoded) so that
		// allowed_updates is correctly parsed as an array by Telegram API.
		$body = wp_json_encode(
			array(
				'url'             => esc_url_raw( $webhook_url ),
				'secret_token'    => sanitize_text_field( $secret_token ),
				'allowed_updates' => array( 'callback_query' ),
			)
		);

		$url  = $this->base_url . 'setWebhook';
		$args = array(
			'method'  => 'POST',
			'timeout' => 12,
			'headers' => array(
				'Content-Type' => 'application/json',
				'User-Agent'   => 'SazonovStudio-TelegramNotifier/' . QONT_VERSION . '; ' . home_url(),
			),
			'body'    => $body,
		);

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || empty( $data['ok'] ) ) {
			$description = isset( $data['description'] ) ? $data['description'] : 'HTTP Error ' . $code;
			return new WP_Error( 'telegram_api_error', $description );
		}

		return $data['result'];
	}

	public function delete_webhook() {
		if ( ! $this->is_configured() ) {
			return false;
		}

		return $this->request( 'deleteWebhook', array( 'drop_pending_updates' => false ) );
	}

	public function get_webhook_info() {
		if ( ! $this->is_configured() ) {
			return new WP_Error( 'not_configured', __( 'Telegram bot token is missing.', 'saz-order-notifier-for-woocommerce' ) );
		}

		return $this->request( 'getWebhookInfo', array(), 'GET' );
	}

	private function request( $method, $payload = array(), $http_verb = 'POST' ) {
		$url = $this->base_url . $method;

		$args = array(
			'timeout'     => 12,
			'redirection' => 2,
			'user-agent'  => 'SazonovStudio-TelegramNotifier/' . QONT_VERSION . '; ' . home_url(),
		);

		if ( 'POST' === $http_verb ) {
			$args['method']  = 'POST';
			$args['body']    = $payload;
		} else {
			$args['method'] = 'GET';
			if ( ! empty( $payload ) ) {
				$url = add_query_arg( $payload, $url );
			}
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( 200 !== $code || empty( $data['ok'] ) ) {
			$description = isset( $data['description'] ) ? $data['description'] : 'HTTP Error ' . $code;
			return new WP_Error( 'telegram_api_error', $description, array( 'http_code' => $code, 'response' => $data ) );
		}

		return $data['result'];
	}
}
