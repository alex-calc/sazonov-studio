<?php
/**
 * Telegram Webhook Handler.
 *
 * Processes callback_query actions from Telegram with strict secret verification,
 * atomic transient lock protection, and direct HPOS order mutation.
 */

defined( 'ABSPATH' ) || exit;

class QONT_Webhook {

	private static $instance = null;
	const REST_NAMESPACE = 'qont/v1';
	const REST_ROUTE     = 'webhook';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/' . self::REST_ROUTE,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_webhook' ),
				'permission_callback' => array( $this, 'check_webhook_permission' ),
			)
		);
	}

	public static function get_webhook_url() {
		return rest_url( self::REST_NAMESPACE . '/' . self::REST_ROUTE );
	}

	/**
	 * Security verification callback for Telegram Secret Token header.
	 */
	public function check_webhook_permission( $request ) {
		$expected_secret = get_option( 'qont_webhook_secret' );
		if ( empty( $expected_secret ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Webhook secret token is not configured on the server.', 'saz-order-notifier-for-woocommerce' ), array( 'status' => 403 ) );
		}

		$incoming_secret = $request->get_header( 'x_telegram_bot_api_secret_token' );
		if ( empty( $incoming_secret ) ) {
			// Fallback check for alternate header capitalization.
			$server_headers = $request->get_headers();
			if ( isset( $server_headers['x_telegram_bot_api_secret_token'][0] ) ) {
				$incoming_secret = $server_headers['x_telegram_bot_api_secret_token'][0];
			}
		}

		if ( empty( $incoming_secret ) || ! hash_equals( $expected_secret, $incoming_secret ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid Telegram secret token verification.', 'saz-order-notifier-for-woocommerce' ), array( 'status' => 403 ) );
		}

		return true;
	}

	/**
	 * Handle incoming update payload from Telegram.
	 */
	public function handle_webhook( $request ) {
		$payload = $request->get_json_params();

		if ( empty( $payload ) || ! is_array( $payload ) ) {
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Empty update' ) );
		}

		// We only process callback_query (inline button clicks).
		if ( empty( $payload['callback_query'] ) ) {
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Ignored non-callback update' ) );
		}

		$callback      = $payload['callback_query'];
		$callback_id   = isset( $callback['id'] ) ? sanitize_text_field( $callback['id'] ) : '';
		$callback_data = isset( $callback['data'] ) ? sanitize_text_field( $callback['data'] ) : '';
		$message       = isset( $callback['message'] ) ? $callback['message'] : array();
		$message_id    = isset( $message['message_id'] ) ? intval( $message['message_id'] ) : 0;
		$chat_id       = isset( $message['chat']['id'] ) ? $message['chat']['id'] : null;
		$user_from     = isset( $callback['from'] ) ? $callback['from'] : array();
		$username      = ! empty( $user_from['username'] )
			? '@' . sanitize_text_field( $user_from['username'] )
			: sanitize_text_field( isset( $user_from['first_name'] ) ? $user_from['first_name'] : 'Admin' );

		// SECURITY FIX — Critical #1 (Claude review):
		// secret_token only proves the request came from Telegram's servers.
		// It does NOT prove it came from OUR configured chat.
		// If a message with action buttons is ever forwarded to another chat,
		// anyone in that chat can press Confirm/Cancel and it will pass secret_token check.
		// We must verify that the callback originated from the exact chat_id we configured.
		$settings         = get_option( 'qont_settings', array() );
		$expected_chat_id = isset( $settings['chat_id'] ) ? trim( $settings['chat_id'] ) : '';

		if ( ! empty( $expected_chat_id ) && ! hash_equals( (string) $expected_chat_id, (string) $chat_id ) ) {
			// Unauthorized chat — answer silently and drop the request.
			$telegram = new QONT_Telegram();
			$telegram->answer_callback_query( $callback_id, '', false );
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Unauthorized chat origin' ) );
		}

		// Handle test button click from settings verification.
		if ( 'qont_test_click' === $callback_data ) {
			$telegram = new QONT_Telegram();
			$telegram->answer_callback_query(
				$callback_id,
				__( '🎉 Connection verified! Your Telegram bot is working properly.', 'saz-order-notifier-for-woocommerce' ),
				false
			);
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Test button verified' ) );
		}

		// Parse action and order ID.
		if ( ! preg_match( '/^qont_(confirm|cancel)_([0-9]+)$/', $callback_data, $matches ) ) {
			$telegram = new QONT_Telegram();
			$telegram->answer_callback_query( $callback_id, __( 'Unrecognized action.', 'saz-order-notifier-for-woocommerce' ), true );
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Invalid action format' ) );
		}

		$action   = $matches[1];
		$order_id = absint( $matches[2] );

		// Race Condition / Double Click Atomic Lock.
		// Uses WordPress add_option() which executes an atomic INSERT INTO wp_options.
		// If duplicate key exists, MySQL fails the INSERT and add_option() returns false.
		$lock_key   = 'qont_lock_' . $order_id;
		$lock_time  = time();
		$lock_ttl   = 30; // 30-second TTL.
		$lock_limit = $lock_time + $lock_ttl;

		$locked = add_option( $lock_key, $lock_limit, '', 'no' );
		if ( ! $locked ) {
			$existing_lock = (int) get_option( $lock_key, 0 );
			if ( $existing_lock > $lock_time ) {
				$telegram = new QONT_Telegram();
				$telegram->answer_callback_query( $callback_id, __( 'Order is already being processed. Please wait.', 'saz-order-notifier-for-woocommerce' ), false );
				return rest_ensure_response( array( 'ok' => true, 'note' => 'Locked by concurrent request' ) );
			}

			// Atomic lock reclamation: if expired, perform atomic conditional UPDATE.
			// Only updates if the existing value is still <= $lock_time.
			// If two concurrent requests arrive simultaneously, only one succeeds; the second affects 0 rows.
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$reclaimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value <= %s",
					(string) $lock_limit,
					$lock_key,
					(string) $lock_time
				)
			);

			if ( ! $reclaimed ) {
				$telegram = new QONT_Telegram();
				$telegram->answer_callback_query( $callback_id, __( 'Order is already being processed. Please wait.', 'saz-order-notifier-for-woocommerce' ), false );
				return rest_ensure_response( array( 'ok' => true, 'note' => 'Locked by concurrent request' ) );
			}
		}

		$telegram = new QONT_Telegram();
		$order    = wc_get_order( $order_id );

		if ( ! $order ) {
			delete_option( $lock_key );
			$telegram->answer_callback_query( $callback_id, __( 'Order not found in store.', 'saz-order-notifier-for-woocommerce' ), true );
			return rest_ensure_response( array( 'ok' => true, 'note' => 'Order not found' ) );
		}

		$current_status = $order->get_status();
		$timestamp      = wp_date( 'H:i:s (d.m.Y)' );

		// FIX #2: Initialize variables to safe defaults to prevent undefined variable notices.
		$toast_text   = '';
		$action_badge = '';

		if ( 'confirm' === $action ) {
			if ( 'processing' === $current_status || 'completed' === $current_status ) {
				$toast_text = sprintf(
					/* translators: 1: order ID, 2: current status */
					__( 'Order #%1$d is already %2$s.', 'saz-order-notifier-for-woocommerce' ),
					$order_id,
					$current_status
				);
				$action_badge = "\n\n━━━━━━━━━━━━━━━━━━━\n✅ <b>Confirmed</b> by <b>" . esc_html( $username ) . '</b> at <code>' . esc_html( $timestamp ) . '</code>';
			} else {
				// Suppress the redundant status_changed notification that notifier.php would fire
				// when update_status() triggers woocommerce_order_status_changed hook.
				// Without this, the admin gets two Telegram messages if "Order Status Changed" is enabled.
				set_transient( 'qont_suppress_status_' . $order_id, 1, 60 );

				// HPOS status update.
				$order->update_status(
					'processing',
					sprintf(
						/* translators: 1: Telegram user identifier, 2: current timestamp */
						__( 'Confirmed via Telegram by %1$s at %2$s.', 'saz-order-notifier-for-woocommerce' ),
						$username,
						$timestamp
					)
				);

				$toast_text = sprintf(
					/* translators: %d: order ID */
					__( 'Order #%d confirmed!', 'saz-order-notifier-for-woocommerce' ),
					$order_id
				);
				$action_badge = "\n\n━━━━━━━━━━━━━━━━━━━\n✅ <b>Confirmed</b> by <b>" . esc_html( $username ) . '</b> at <code>' . esc_html( $timestamp ) . '</code>';
			}

		} elseif ( 'cancel' === $action ) {
			if ( 'cancelled' === $current_status ) {
				$toast_text = sprintf(
					/* translators: %d: order ID */
					__( 'Order #%d is already cancelled.', 'saz-order-notifier-for-woocommerce' ),
					$order_id
				);
				$action_badge = "\n\n━━━━━━━━━━━━━━━━━━━\n❌ <b>Cancelled</b> by <b>" . esc_html( $username ) . '</b> at <code>' . esc_html( $timestamp ) . '</code>';
			} else {
				// Suppress redundant status_changed notification (same reason as above).
				set_transient( 'qont_suppress_status_' . $order_id, 1, 60 );

				// HPOS status update.
				$order->update_status(
					'cancelled',
					sprintf(
						/* translators: 1: Telegram user identifier, 2: current timestamp */
						__( 'Cancelled via Telegram by %1$s at %2$s.', 'saz-order-notifier-for-woocommerce' ),
						$username,
						$timestamp
					)
				);

				$toast_text = sprintf(
					/* translators: %d: order ID */
					__( 'Order #%d cancelled.', 'saz-order-notifier-for-woocommerce' ),
					$order_id
				);
				$action_badge = "\n\n━━━━━━━━━━━━━━━━━━━\n❌ <b>Cancelled</b> by <b>" . esc_html( $username ) . '</b> at <code>' . esc_html( $timestamp ) . '</code>';
			}
		}

		// Answer callback popup in Telegram app.
		if ( ! empty( $toast_text ) ) {
			$telegram->answer_callback_query( $callback_id, $toast_text, false );
		}

		// Rebuild the exact original HTML message directly from the order.
		// Telegram's payload message['text'] returns plain text stripped of all <b>, <code> tags,
		// and any special characters could cause entity parse errors if passed to editMessageText as HTML.
		// Generating via build_message() ensures 100% authentic HTML formatting and proper esc_html.
		if ( $chat_id && $message_id && ! empty( $action_badge ) ) {
			$notifier      = QONT_Notifier::instance();
			$original_text = $notifier->build_message( $order, 'new_order', '', '', $settings );
			$updated_text  = $original_text . $action_badge;

			$new_keyboard = array(
				array(
					array(
						'text' => '🔗 ' . __( 'Open in Admin', 'saz-order-notifier-for-woocommerce' ),
						'url'  => function_exists( 'wc_get_order_admin_url' )
							? wc_get_order_admin_url( $order_id )
							: admin_url( 'post.php?post=' . $order_id . '&action=edit' ),
					),
				),
			);
			$telegram->edit_message_text( $chat_id, $message_id, $updated_text, $new_keyboard );
		}

		// Log the action.
		QONT_Logger::log(
			$order_id,
			'action_' . $action,
			$message_id,
			'acted',
			sprintf( 'Action executed by %s at %s', $username, $timestamp )
		);

		delete_option( $lock_key );
		return rest_ensure_response( array( 'ok' => true, 'action' => $action, 'order_id' => $order_id ) );
	}
}