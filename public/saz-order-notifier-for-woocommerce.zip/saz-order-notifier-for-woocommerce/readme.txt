=== Saz Order Notifier with Telegram for WooCommerce ===
Contributors: alexsazonov
Donate link: https://sazonov-studio.netlify.app
Tags: woocommerce, telegram, notifications, orders, telegram bot
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 7.0
WC tested up to: 9.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Get WooCommerce orders in Telegram and confirm or cancel them without opening WordPress.

== Description ==

**Saz Order Notifier with Telegram for WooCommerce** is a lightweight, zero-dependency WooCommerce order dispatcher. Never miss an order, and manage your store right from Telegram without logging into the WordPress admin panel.

When a customer places an order, a beautifully formatted notification card immediately arrives in your private Telegram chat or team group. You can inspect customer contact info, ordered items, shipping destination, and confirm or cancel the order with a single tap.

### 🌟 Key Features

* **Instant Real-Time Alerts:** Fast real-time delivery of new order alerts directly via the official Telegram Bot API.
* **One-Tap Action Buttons:** Confirm (`Processing`) or Cancel (`Cancelled`) orders directly from inline keyboard buttons in Telegram.
* **100% Day-1 HPOS Compatible:** Full native compatibility with High-Performance Order Storage (`custom_order_tables`) and Block-based Checkout.
* **Atomic Race-Condition Protection:** Database-level atomic locks prevent double-clicks or conflicting actions between multiple store managers.
* **Zero External Dependencies:** Built entirely with native WordPress HTTP APIs (`wp_remote_post`). No bulky Composer packages, no external SDKs.
* **Enterprise Security:** Webhook requests verified with cryptographically secure secret tokens (`X-Telegram-Bot-Api-Secret-Token`). No `__return_true` vulnerabilities.
* **Clean Uninstaller:** Full cleanup of options and database tables upon plugin deletion (`uninstall.php`).

== External Services ==

This plugin communicates with the Telegram Bot API (https://api.telegram.org) to deliver instant order notifications to store administrators and process interactive order confirmations and cancellations via webhooks.

* **Service Provider:** Telegram FZ-LLC / Telegram Bot API
* **Purpose:** Transmitting new WooCommerce order alerts to the merchant's Telegram chat, channel, or topic, and updating order statuses via secure webhook callback buttons.
* **Data Transmitted:** Order ID, order number, customer billing name, phone number, shipping method and address, list of purchased products (item names, quantities, line totals), payment method, and order totals. Data is transmitted directly from your server to Telegram over HTTPS.
* **When Data Is Sent:** Real-time on the `woocommerce_new_order` / `woocommerce_checkout_order_processed` event, or when an administrator clicks "Send Test Message" or "Register Webhook" in the plugin settings.
* **Telegram Terms of Service:** https://core.telegram.org/api/terms
* **Telegram Privacy Policy:** https://telegram.org/privacy

== Installation ==

1. Upload the `saz-order-notifier-for-woocommerce` folder to the `/wp-content/plugins/` directory, or install directly via the WordPress Plugins menu.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to **WooCommerce > Telegram Notifier**.
4. Enter your Telegram Bot Token (obtained from [@BotFather](https://t.me/BotFather)) and your Chat ID (obtained from [@userinfobot](https://t.me/userinfobot)).
5. Click **Register Webhook** to activate inline buttons.
6. Click **Send Test Message** to verify your setup.

== Frequently Asked Questions ==

= Does this plugin work with Telegram Groups and Channels? =
Yes! You can enter a personal Telegram user ID (e.g. `123456789`) or a group/supergroup ID (e.g. `-100123456789`). Just ensure your bot is added as an administrator to the group.

= Is High-Performance Order Storage (HPOS) supported? =
Yes, 100%. The plugin declares full Day-1 compatibility with HPOS and utilizes native WooCommerce CRUD order APIs (`wc_get_order`).

= Are external libraries or Node/Composer required? =
No. The plugin is 100% zero-dependency PHP. It communicates directly with the Telegram Bot API over HTTPS.

== Screenshots ==

1. Settings panel in WooCommerce admin.
2. Order card in Telegram with Confirm & Cancel action buttons.
3. Action confirmation badge after tapping Confirm.

== Changelog ==

= 1.0.2 =
* Updated display name and slug to comply with WordPress.org trademark guidelines.
* Added official `Requires Plugins: woocommerce` dependency header.
* Added `== External Services ==` disclosure for Telegram Bot API per Guideline 6.
* Hardened webhook concurrency lock with atomic conditional MySQL update.

= 1.0.0 =
* Initial public release on WordPress.org.
* Real-time order cards with inline Confirm/Cancel buttons.
* Full HPOS & Block checkout support.
* Secure webhook handler with secret token validation.
