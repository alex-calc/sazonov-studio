<?php
/**
 * Plugin Name:       Saz Order Notifier with Telegram for WooCommerce
 * Description:       Get WooCommerce orders in Telegram and confirm or cancel them without opening WordPress.
 * Version:           1.0.2
 * Author:            Sazonov Studio
 * Author URI:        https://sazonov-studio.netlify.app
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       saz-order-notifier-for-woocommerce
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * WC requires at least: 7.0
 * WC tested up to:   9.4
 * Requires Plugins:  woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'QONT_VERSION', '1.0.2' );
define( 'QONT_PLUGIN_FILE', __FILE__ );
define( 'QONT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'QONT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'QONT_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Declare High-Performance Order Storage (HPOS) and Blocks compatibility.
 */
add_action( 'before_woocommerce_init', 'qont_declare_hpos_compatibility' );
function qont_declare_hpos_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
}

/**
 * Initialize the plugin after plugins loaded.
 */
add_action( 'plugins_loaded', 'qont_init_plugin' );
function qont_init_plugin() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'qont_woocommerce_missing_notice' );
		return;
	}

	require_once QONT_PLUGIN_PATH . 'includes/class-qont-logger.php';
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-telegram.php';
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-settings.php';
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-notifier.php';
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-webhook.php';

	QONT_Logger::instance();
	QONT_Settings::instance();
	QONT_Notifier::instance();
	QONT_Webhook::instance();
}

/**
 * Admin notice when WooCommerce is inactive.
 */
function qont_woocommerce_missing_notice() {
	?>
	<div class="notice notice-error is-dismissible">
		<p><?php esc_html_e( 'Quick Order Notifier for Telegram requires WooCommerce to be installed and active.', 'saz-order-notifier-for-woocommerce' ); ?></p>
	</div>
	<?php
}

/**
 * Activation hook: create logging table and generate webhook secret.
 */
register_activation_hook( __FILE__, 'qont_activate_plugin' );
function qont_activate_plugin() {
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-logger.php';
	QONT_Logger::create_tables();

	if ( ! get_option( 'qont_webhook_secret' ) ) {
		update_option( 'qont_webhook_secret', wp_generate_password( 32, false ) );
	}
}

/**
 * Deactivation hook: delete webhook from Telegram to prevent dead callbacks.
 */
register_deactivation_hook( __FILE__, 'qont_deactivate_plugin' );
function qont_deactivate_plugin() {
	require_once QONT_PLUGIN_PATH . 'includes/class-qont-telegram.php';
	$telegram = new QONT_Telegram();
	$telegram->delete_webhook();
}

/**
 * Add settings action link on Plugins admin page.
 */
add_filter( 'plugin_action_links_' . QONT_PLUGIN_BASENAME, 'qont_plugin_action_links' );
function qont_plugin_action_links( $links ) {
	$settings_url  = admin_url( 'admin.php?page=qont-settings' );
	$settings_link = '<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'saz-order-notifier-for-woocommerce' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
