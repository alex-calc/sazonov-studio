<?php
/**
 * Uninstall routine for Quick Order Notifier for Telegram.
 *
 * Triggered only when the plugin is deleted via WordPress admin.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Delete plugin settings and options.
delete_option( 'qont_settings' );
delete_option( 'qont_webhook_secret' );
delete_option( 'qont_db_version' );
