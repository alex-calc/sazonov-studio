<?php
/**
 * SazCancel Admin Interface & Settings
 *
 * Provides merchant configuration, Dry Run HUD Banner with live statistics,
 * and Activity Log audit trail.
 *
 * @package SazCancel
 */

defined( 'ABSPATH' ) || exit;

class SazCancel_Admin {

	/**
	 * Single instance.
	 *
	 * @var SazCancel_Admin|null
	 */
	private static $instance = null;

	/**
	 * Main instance accessor.
	 *
	 * @return SazCancel_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 55 );
		add_action( 'admin_init', array( $this, 'handle_form_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Enqueue admin stylesheets on SazCancel settings screen.
	 *
	 * @param string $hook_suffix The current admin page hook.
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		if ( false === strpos( $hook_suffix, 'sazcancel-settings' ) ) {
			return;
		}

		wp_enqueue_style(
			'sazcancel-admin-css',
			SAZCANCEL_URL . 'assets/css/admin.css',
			array(),
			SAZCANCEL_VERSION
		);
	}

	/**
	 * Add submenu page under WooCommerce.
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'SazCancel – Auto-Cancel Stale Orders', 'sazcancel-auto-cancel-on-hold-orders' ),
			__( 'SazCancel', 'sazcancel-auto-cancel-on-hold-orders' ),
			'manage_woocommerce',
			'sazcancel-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Handle settings save, Dry Run toggle, log clearing, and manual test sweep.
	 */
	public function handle_form_actions() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// Save Settings.
		if ( isset( $_POST['sazcancel_action'] ) && 'save_settings' === $_POST['sazcancel_action'] ) {
			check_admin_referer( 'sazcancel_settings_nonce', 'sazcancel_nonce' );

			$enabled         = isset( $_POST['sazcancel_enabled'] ) ? 'yes' : 'no';
			$prev_enabled    = get_option( 'sazcancel_enabled', 'no' );
			$current_dry_run = get_option( 'sazcancel_dry_run', 'yes' );

			// SAFETY GATE: Regular settings save CANNOT activate Live Mode!
			// 1. If engine is turned OFF ('no'), automatically enforce Simulation Mode (dry_run = 'yes')
			//    so the system is never left in an armed state while paused.
			// 2. If engine was OFF ('no') and is now turned ON ('yes') via this standard settings form,
			//    dry_run MUST be forced to 'yes' (Simulation Mode).
			// 3. If merchant explicitly checked the box to revert to Simulation Mode, dry_run = 'yes'.
			// 4. In all other cases (engine was already active and running in Live Mode, and merchant is only
			//    updating timers, notes, or gateways), preserve current_dry_run.
			if ( 'no' === $enabled || 'no' === $prev_enabled || isset( $_POST['sazcancel_revert_dry_run'] ) ) {
				$dry_run = 'yes';
			} else {
				$dry_run = $current_dry_run;
			}

			$old_delay_value = (int) get_option( 'sazcancel_delay_value', 72 );
			$old_delay_unit  = get_option( 'sazcancel_delay_unit', 'hours' );

			$delay_value = isset( $_POST['sazcancel_delay_value'] ) ? absint( wp_unslash( $_POST['sazcancel_delay_value'] ) ) : 72;
			$posted_unit = isset( $_POST['sazcancel_delay_unit'] ) ? sanitize_text_field( wp_unslash( $_POST['sazcancel_delay_unit'] ) ) : 'hours';
			$delay_unit  = in_array( $posted_unit, array( 'hours', 'days' ), true ) ? $posted_unit : 'hours';

			// Strict Server-Side Range Validation (never accept 0 or unbounded values):
			if ( 'days' === $delay_unit ) {
				$delay_value = min( 30, max( 1, $delay_value ) );
			} else {
				$delay_value = min( 720, max( 1, $delay_value ) );
			}

			// Explicit empty selection preserved without overriding with defaults:
			$gateways = isset( $_POST['sazcancel_eligible_gateways'] ) && is_array( $_POST['sazcancel_eligible_gateways'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['sazcancel_eligible_gateways'] ) ) : array();
			$note     = isset( $_POST['sazcancel_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['sazcancel_note'] ) ) : '';

			update_option( 'sazcancel_enabled', $enabled );
			update_option( 'sazcancel_dry_run', $dry_run );
			update_option( 'sazcancel_delay_value', $delay_value );
			update_option( 'sazcancel_delay_unit', $delay_unit );
			update_option( 'sazcancel_eligible_gateways', $gateways );
			update_option( 'sazcancel_note', $note );

			// Point C: Symmetrically synchronize queue if timer changed (increases OR decreases)
			if ( $old_delay_value !== $delay_value || $old_delay_unit !== $delay_unit ) {
				SazCancel_Engine::instance()->sync_all_scheduled_delays();
			}

			wp_safe_redirect( add_query_arg( array( 'page' => 'sazcancel-settings', 'saved' => '1' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// Quick Switch to Live Mode from HUD banner (Requires explicit confirm).
		if ( isset( $_POST['sazcancel_action'] ) && 'enable_live_mode' === $_POST['sazcancel_action'] ) {
			check_admin_referer( 'sazcancel_hud_nonce', 'sazcancel_nonce' );

			update_option( 'sazcancel_enabled', 'yes' );
			update_option( 'sazcancel_dry_run', 'no' );

			wp_safe_redirect( add_query_arg( array( 'page' => 'sazcancel-settings', 'live_enabled' => '1' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// Revert to Safe Simulation Mode from HUD banner.
		if ( isset( $_POST['sazcancel_action'] ) && 'disable_live_mode' === $_POST['sazcancel_action'] ) {
			check_admin_referer( 'sazcancel_hud_nonce', 'sazcancel_nonce' );

			update_option( 'sazcancel_dry_run', 'yes' );

			wp_safe_redirect( add_query_arg( array( 'page' => 'sazcancel-settings', 'dry_run_enabled' => '1' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// Clear Activity Log.
		if ( isset( $_POST['sazcancel_action'] ) && 'clear_log' === $_POST['sazcancel_action'] ) {
			check_admin_referer( 'sazcancel_clear_log_nonce', 'sazcancel_nonce' );

			delete_option( 'sazcancel_activity_log' );

			wp_safe_redirect( add_query_arg( array( 'page' => 'sazcancel-settings', 'log_cleared' => '1' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// Run Preview Check Now (100% Read-Only, ZERO mutations).
		if ( isset( $_POST['sazcancel_action'] ) && 'run_test_check' === $_POST['sazcancel_action'] ) {
			check_admin_referer( 'sazcancel_test_nonce', 'sazcancel_nonce' );

			$analyzed = SazCancel_Engine::instance()->preview_recovery_sweep();

			wp_safe_redirect(
				add_query_arg(
					array(
						'page'        => 'sazcancel-settings',
						'preview_run' => '1',
						'count'       => absint( $analyzed ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}
	}

	/**
	 * Compute live On-Hold orders statistics for Dry Run HUD.
	 *
	 * @return array
	 */
	private function get_hud_stats() {
		$engine   = SazCancel_Engine::instance();
		$eligible = $engine->get_eligible_gateways();

		if ( empty( $eligible ) ) {
			return array(
				'count'                => 0,
				'oldest_order'         => null,
				'oldest_age'           => '–',
				'locked_stock'         => 0,
				'locked_stock_display' => '0',
				'is_sampled'           => false,
			);
		}

		// Query with paginate => true to retrieve true total count of eligible On-Hold orders.
		$query_result = wc_get_orders(
			array(
				'status'         => 'on-hold',
				'payment_method' => $eligible,
				'limit'          => 100,
				'paginate'       => true,
				'orderby'        => 'date',
				'order'          => 'ASC',
			)
		);

		$total_count  = is_object( $query_result ) && isset( $query_result->total ) ? (int) $query_result->total : 0;
		$orders       = is_object( $query_result ) && isset( $query_result->orders ) ? $query_result->orders : array();
		$oldest_order = ! empty( $orders ) ? $orders[0] : null;
		$oldest_age   = '–';
		$locked_stock = 0;

		if ( $oldest_order instanceof WC_Order ) {
			$on_hold_at = (int) $oldest_order->get_meta( '_sazcancel_on_hold_at' );
			if ( ! empty( $on_hold_at ) ) {
				$elapsed    = max( 0, time() - $on_hold_at );
				$oldest_age = $engine->format_elapsed_time( $elapsed );
			} else {
				$oldest_age = __( 'Pending Baseline (Legacy)', 'sazcancel-auto-cancel-on-hold-orders' );
			}
		}

		foreach ( $orders as $order ) {
			if ( $order instanceof WC_Order ) {
				foreach ( $order->get_items() as $item ) {
					$locked_stock += (int) $item->get_quantity();
				}
			}
		}

		$is_sampled           = $total_count > 100;
		$locked_stock_display = $is_sampled ? $locked_stock . '+' : (string) $locked_stock;

		return array(
			'count'                => $total_count,
			'oldest_order'         => $oldest_order,
			'oldest_age'           => $oldest_age,
			'locked_stock'         => $locked_stock,
			'locked_stock_display' => $locked_stock_display,
			'is_sampled'           => $is_sampled,
		);
	}

	/**
	 * Render settings page.
	 */
	public function render_settings_page() {
		$engine             = SazCancel_Engine::instance();
		$is_enabled         = $engine->is_enabled();
		$is_dry_run         = $engine->is_dry_run();
		$delay_value        = (int) get_option( 'sazcancel_delay_value', 72 );
		$delay_unit         = get_option( 'sazcancel_delay_unit', 'hours' );
		$eligible_gateways  = $engine->get_eligible_gateways();
		$note               = get_option( 'sazcancel_note', __( 'Auto-cancelled by SazCancel due to unpaid On-Hold timeout.', 'sazcancel-auto-cancel-on-hold-orders' ) );
		$activity_log       = get_option( 'sazcancel_activity_log', array() );

		$hud_stats          = $this->get_hud_stats();
		$available_gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();

		?>
		<div class="wrap sazcancel-wrap">
			<h1>
				<?php esc_html_e( 'SazCancel – Auto-Cancel Stale On-Hold Orders & Release Stock', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
				<span class="sazcancel-version-tag">v<?php echo esc_html( SAZCANCEL_VERSION ); ?></span>
			</h1>

			<?php
			// phpcs:disable WordPress.Security.NonceVerification.Recommended
			if ( isset( $_GET['saved'] ) ) :
				?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved successfully.', 'sazcancel-auto-cancel-on-hold-orders' ); ?></p></div>
			<?php endif; ?>

			<?php if ( isset( $_GET['live_enabled'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Live automatic cancellation has been enabled!', 'sazcancel-auto-cancel-on-hold-orders' ); ?></p></div>
			<?php endif; ?>

			<?php if ( isset( $_GET['log_cleared'] ) ) : ?>
				<div class="notice notice-info is-dismissible"><p><?php esc_html_e( 'Activity log cleared.', 'sazcancel-auto-cancel-on-hold-orders' ); ?></p></div>
			<?php endif; ?>

			<?php if ( isset( $_GET['preview_run'] ) ) : ?>
				<div class="notice notice-info is-dismissible">
					<p>
						<strong><?php esc_html_e( 'Preview Check Completed:', 'sazcancel-auto-cancel-on-hold-orders' ); ?></strong>
						<?php
						printf(
							/* translators: %d: number of orders */
							esc_html__( 'Analyzed %d eligible orders. Store orders, stock levels, and Action Scheduler queue were not modified. Diagnostic results have been safely recorded into the Activity Log below.', 'sazcancel-auto-cancel-on-hold-orders' ),
							isset( $_GET['count'] ) ? absint( $_GET['count'] ) : 0
						);
						?>
					</p>
				</div>
			<?php
			endif;
			// phpcs:enable WordPress.Security.NonceVerification.Recommended
			?>

			<!-- HUD Banner Section -->
			<div class="sazcancel-hud-card <?php echo $is_dry_run ? 'is-dry-run' : ( $is_enabled ? 'is-live' : 'is-paused' ); ?>">
				<div class="sazcancel-hud-header">
					<div class="sazcancel-hud-title">
						<?php if ( $is_dry_run ) : ?>
							<span class="dashicons dashicons-shield-alt sazcancel-hud-icon"></span>
							<strong><?php esc_html_e( 'Simulation Mode (Dry Run) Active', 'sazcancel-auto-cancel-on-hold-orders' ); ?></strong>
						<?php elseif ( $is_enabled ) : ?>
							<span class="dashicons dashicons-yes-alt sazcancel-hud-icon"></span>
							<strong><?php esc_html_e( 'Live Mode Active – Orders are automatically cancelled', 'sazcancel-auto-cancel-on-hold-orders' ); ?></strong>
						<?php else : ?>
							<span class="dashicons dashicons-controls-pause sazcancel-hud-icon"></span>
							<strong><?php esc_html_e( 'Auto-Cancellation is Currently Paused', 'sazcancel-auto-cancel-on-hold-orders' ); ?></strong>
						<?php endif; ?>
					</div>
					<div class="sazcancel-hud-actions">
						<form method="post" style="display:inline-block;">
							<?php wp_nonce_field( 'sazcancel_test_nonce', 'sazcancel_nonce' ); ?>
							<input type="hidden" name="sazcancel_action" value="run_test_check" />
							<button type="submit" class="button button-secondary">
								<span class="dashicons dashicons-visibility" style="vertical-align:text-bottom;font-size:16px;"></span>
								<?php esc_html_e( 'Preview Check (Read-Only)', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
							</button>
						</form>

						<?php if ( $is_dry_run ) : ?>
							<form method="post" style="display:inline-block; margin-left:8px;">
								<?php wp_nonce_field( 'sazcancel_hud_nonce', 'sazcancel_nonce' ); ?>
								<input type="hidden" name="sazcancel_action" value="enable_live_mode" />
								<button type="submit" class="button button-primary" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to activate Live Cancellation? Stale orders exceeding your timeout will be cancelled and their stock released.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>');">
									<?php esc_html_e( 'Activate Live Mode', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</button>
							</form>
						<?php else : ?>
							<form method="post" style="display:inline-block; margin-left:8px;">
								<?php wp_nonce_field( 'sazcancel_hud_nonce', 'sazcancel_nonce' ); ?>
								<input type="hidden" name="sazcancel_action" value="disable_live_mode" />
								<button type="submit" class="button button-secondary">
									<span class="dashicons dashicons-shield" style="vertical-align:text-bottom;font-size:16px;"></span>
									<?php esc_html_e( 'Switch to Simulation Mode', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</div>
				</div>

				<div class="sazcancel-hud-grid">
					<div class="sazcancel-hud-stat">
						<span class="sazcancel-hud-label"><?php esc_html_e( 'Eligible On-Hold Orders', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
						<span class="sazcancel-hud-value"><?php echo esc_html( $hud_stats['count'] ); ?></span>
					</div>
					<div class="sazcancel-hud-stat">
						<span class="sazcancel-hud-label"><?php esc_html_e( 'Oldest Eligible Order', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
						<span class="sazcancel-hud-value">
							<?php if ( $hud_stats['oldest_order'] ) : ?>
								#<?php echo esc_html( $hud_stats['oldest_order']->get_id() ); ?> <small>(<?php echo esc_html( $hud_stats['oldest_age'] ); ?>)</small>
							<?php else : ?>
								–
							<?php endif; ?>
						</span>
					</div>
					<div class="sazcancel-hud-stat">
						<span class="sazcancel-hud-label">
							<?php esc_html_e( 'Items in Eligible On-Hold Orders', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
							<?php if ( ! empty( $hud_stats['is_sampled'] ) ) : ?>
								<small style="font-weight:normal; text-transform:none; color:#646970;">(<?php esc_html_e( 'first 100 orders', 'sazcancel-auto-cancel-on-hold-orders' ); ?>)</small>
							<?php endif; ?>
						</span>
						<span class="sazcancel-hud-value"><?php echo esc_html( $hud_stats['locked_stock_display'] ); ?> <?php esc_html_e( 'items', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
					</div>
				</div>

				<?php if ( $is_dry_run ) : ?>
					<p class="sazcancel-hud-notice">
						<?php esc_html_e( '🛡️ Safe Mode: In Dry Run mode, orders and stock levels are NOT modified. Eligible stale orders are simply recorded in the Activity Log for your verification.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
					</p>
				<?php endif; ?>
			</div>

			<!-- Main Settings Form -->
			<div class="sazcancel-card">
				<h2><?php esc_html_e( 'Cancellation Rules & Timing', 'sazcancel-auto-cancel-on-hold-orders' ); ?></h2>
				<form method="post" action="">
					<?php wp_nonce_field( 'sazcancel_settings_nonce', 'sazcancel_nonce' ); ?>
					<input type="hidden" name="sazcancel_action" value="save_settings" />

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable Auto-Cancel', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="sazcancel_enabled" value="yes" <?php checked( $is_enabled ); ?> />
									<?php esc_html_e( 'Enable automated cancellation engine for eligible On-Hold orders.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</label>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Operating Mode', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							<td>
								<?php if ( $is_dry_run ) : ?>
									<span class="sazcancel-badge-simulation" style="display:inline-block; padding:4px 10px; background:#fef3c7; color:#92400e; border:1px solid #f59e0b; border-radius:4px; font-weight:600;">
										🛡️ <?php esc_html_e( 'Simulation Mode (Dry Run) Active', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
									</span>
									<p class="description" style="margin-top:6px;">
										<?php esc_html_e( 'Safe simulation enforced. Live order cancellation can only be activated via the dedicated "Activate Live Mode" button above with explicit confirmation.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
									</p>
								<?php else : ?>
									<span class="sazcancel-badge-live" style="display:inline-block; padding:4px 10px; background:#dcfce7; color:#166534; border:1px solid #16a34a; border-radius:4px; font-weight:600;">
										⚡ <?php esc_html_e( 'Live Cancellation Active (Real stock restoration)', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
									</span>
									<label style="display:block; margin-top:8px;">
										<input type="checkbox" name="sazcancel_revert_dry_run" value="yes" />
										<?php esc_html_e( 'Switch back to Safe Simulation Mode (Dry Run)', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
									</label>
								<?php endif; ?>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Cancel After', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							<td>
								<input type="number" name="sazcancel_delay_value" min="1" step="1" style="width:90px;" value="<?php echo esc_attr( $delay_value ); ?>" />
								<select name="sazcancel_delay_unit">
									<option value="hours" <?php selected( $delay_unit, 'hours' ); ?>><?php esc_html_e( 'Hours', 'sazcancel-auto-cancel-on-hold-orders' ); ?></option>
									<option value="days" <?php selected( $delay_unit, 'days' ); ?>><?php esc_html_e( 'Days', 'sazcancel-auto-cancel-on-hold-orders' ); ?></option>
								</select>
								<p class="description">
									<?php esc_html_e( 'How long an eligible order can remain in On-Hold status before being cancelled. Measured strictly from the moment the order entered On-Hold.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Eligible Payment Methods', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							<td>
								<fieldset>
									<legend class="screen-reader-text"><?php esc_html_e( 'Eligible Payment Methods', 'sazcancel-auto-cancel-on-hold-orders' ); ?></legend>
									<?php if ( ! empty( $available_gateways ) ) : ?>
										<?php foreach ( $available_gateways as $gateway_id => $gateway ) : ?>
											<label style="display:block; margin-bottom:6px;">
												<input type="checkbox" name="sazcancel_eligible_gateways[]" value="<?php echo esc_attr( $gateway_id ); ?>" <?php checked( in_array( $gateway_id, $eligible_gateways, true ) ); ?> />
												<strong><?php echo esc_html( $gateway->get_title() ); ?></strong>
												<code>(<?php echo esc_html( $gateway_id ); ?>)</code>
											</label>
										<?php endforeach; ?>
									<?php else : ?>
										<p><?php esc_html_e( 'No active payment gateways detected.', 'sazcancel-auto-cancel-on-hold-orders' ); ?></p>
									<?php endif; ?>
								</fieldset>
								<p class="description">
									<?php esc_html_e( 'Select which payment gateways should be subject to auto-cancellation (e.g. Direct Bank Transfer BACS, Cheque). Orders from unselected gateways will NEVER be touched.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Cancellation Order Note', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							<td>
								<textarea name="sazcancel_note" rows="2" class="large-text"><?php echo esc_textarea( $note ); ?></textarea>
								<p class="description">
									<?php esc_html_e( 'Note recorded in the order history when cancellation is executed.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
								</p>
							</td>
						</tr>
					</table>

					<?php submit_button( __( 'Save Cancellation Settings', 'sazcancel-auto-cancel-on-hold-orders' ) ); ?>
				</form>
			</div>

			<!-- Activity Log Section -->
			<div class="sazcancel-card">
				<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
					<h2 style="margin:0;"><?php esc_html_e( 'Activity Audit Log (Last 30 Events)', 'sazcancel-auto-cancel-on-hold-orders' ); ?></h2>
					<?php if ( ! empty( $activity_log ) ) : ?>
						<form method="post" onsubmit="return confirm('<?php esc_attr_e( 'Clear the activity log?', 'sazcancel-auto-cancel-on-hold-orders' ); ?>');">
							<?php wp_nonce_field( 'sazcancel_clear_log_nonce', 'sazcancel_nonce' ); ?>
							<input type="hidden" name="sazcancel_action" value="clear_log" />
							<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Clear Log', 'sazcancel-auto-cancel-on-hold-orders' ); ?></button>
						</form>
					<?php endif; ?>
				</div>

				<?php if ( ! empty( $activity_log ) ) : ?>
					<table class="widefat striped">
						<thead>
							<tr>
								<th style="width:140px;"><?php esc_html_e( 'Date & Time', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th style="width:100px;"><?php esc_html_e( 'Order', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th style="width:100px;"><?php esc_html_e( 'Gateway', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th style="width:90px;"><?php esc_html_e( 'Total', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th style="width:100px;"><?php esc_html_e( 'Time On-Hold', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th style="width:130px;"><?php esc_html_e( 'Status', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
								<th><?php esc_html_e( 'Details', 'sazcancel-auto-cancel-on-hold-orders' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $activity_log as $entry ) : ?>
								<tr>
									<td><?php echo esc_html( date_i18n( 'Y-m-d H:i:s', $entry['timestamp'] ) ); ?></td>
									<td>
										<?php if ( ! empty( $entry['order_id'] ) ) : ?>
											<?php
											$log_order = wc_get_order( $entry['order_id'] );
											$order_url = $log_order && method_exists( $log_order, 'get_edit_order_url' )
												? $log_order->get_edit_order_url()
												: admin_url( 'admin.php?page=wc-orders&action=edit&id=' . absint( $entry['order_id'] ) );
											?>
											<a href="<?php echo esc_url( $order_url ); ?>" target="_blank">
												#<?php echo esc_html( $entry['order_id'] ); ?>
											</a>
										<?php else : ?>
											–
										<?php endif; ?>
									</td>
									<td><code><?php echo esc_html( $entry['gateway'] ); ?></code></td>
									<td><?php echo esc_html( $entry['total'] ); ?></td>
									<td><?php echo esc_html( $entry['time_on_hold'] ); ?></td>
									<td>
										<?php if ( 'CANCELLED' === $entry['status'] ) : ?>
											<span class="sazcancel-badge is-cancelled"><?php esc_html_e( 'CANCELLED', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
										<?php elseif ( 'DRY_RUN' === $entry['status'] ) : ?>
											<span class="sazcancel-badge is-dry-run"><?php esc_html_e( 'DRY RUN', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
										<?php elseif ( 'PREVIEW' === $entry['status'] ) : ?>
											<span class="sazcancel-badge is-preview"><?php esc_html_e( 'PREVIEW', 'sazcancel-auto-cancel-on-hold-orders' ); ?></span>
										<?php else : ?>
											<span class="sazcancel-badge is-skipped"><?php echo esc_html( $entry['status'] ); ?></span>
										<?php endif; ?>
									</td>
									<td><?php echo esc_html( $entry['message'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<p class="sazcancel-empty-log">
						<?php esc_html_e( 'Log is currently empty. Automated checks and cancellations will appear here.', 'sazcancel-auto-cancel-on-hold-orders' ); ?>
					</p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
