<?php
/**
 * SazCancel Engine
 *
 * Handles On-Hold order event monitoring, Action Scheduler queueing with strict order_id uniqueness,
 * Last-Moment Status Revalidation, Safe Legacy Recovery Baseline, and native stock restoration via WooCommerce Core.
 *
 * @package SazCancel
 */

defined( 'ABSPATH' ) || exit;

class SazCancel_Engine {

	/**
	 * Single instance.
	 *
	 * @var SazCancel_Engine|null
	 */
	private static $instance = null;

	/**
	 * Main instance accessor.
	 *
	 * @return SazCancel_Engine
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		// Listen for orders transitioning to on-hold.
		add_action( 'woocommerce_order_status_on-hold', array( $this, 'on_order_status_on_hold' ), 10, 2 );

		// Unschedule and clean meta when order leaves on-hold status.
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );

		// Action Scheduler worker hook. Accepts 2 arguments: order_id and generation.
		add_action( 'sazcancel_check_and_cancel_single_order', array( $this, 'process_single_order' ), 10, 2 );

		// Daily recovery sweep hook.
		add_action( 'sazcancel_daily_recovery_sweep', array( $this, 'process_daily_recovery_sweep' ) );

		// Background batch delay synchronization hook for large stores (2 arguments: cursor_id, version).
		add_action( 'sazcancel_sync_delay_batch', array( $this, 'process_sync_delay_batch' ), 10, 2 );

		// Fast reconciliation hook for single orders (1 argument: order_id).
		add_action( 'sazcancel_reconcile_order_schedule', array( $this, 'reconcile_single_order' ), 10, 1 );
	}

	/**
	 * Calculate cancellation delay in seconds.
	 * Enforces strict bounds: minimum 1 hour (3600 seconds), maximum 30 days.
	 *
	 * @return int
	 */
	public function get_delay_seconds() {
		$value = (int) get_option( 'sazcancel_delay_value', 72 );
		$unit  = get_option( 'sazcancel_delay_unit', 'hours' );

		if ( 'days' === $unit ) {
			$value   = min( 30, max( 1, $value ) );
			$seconds = $value * DAY_IN_SECONDS;
		} else {
			$value   = min( 720, max( 1, $value ) );
			$seconds = $value * HOUR_IN_SECONDS;
		}

		// Absolute safety minimum: 1 hour (3600 seconds) to prevent instant cancellation risks.
		return max( 3600, $seconds );
	}

	/**
	 * Get list of eligible payment gateway IDs.
	 *
	 * @return array
	 */
	public function get_eligible_gateways() {
		$gateways = get_option( 'sazcancel_eligible_gateways', null );
		if ( null === $gateways ) {
			// First-time install default only.
			return array( 'bacs', 'cheque' );
		}
		return is_array( $gateways ) ? $gateways : array();
	}

	/**
	 * Synchronize all scheduled On-Hold order cancellation timers when delay setting changes.
	 * Dispatches an asynchronous batch chain via Action Scheduler with cursor pagination
	 * to seamlessly process catalogs of any size without PHP timeouts or memory limits.
	 */
	public function sync_all_scheduled_delays() {
		$eligible = $this->get_eligible_gateways();
		if ( empty( $eligible ) ) {
			return;
		}

		// Bump schedule version to signal running workers and recovery sweep that delay rules updated.
		$schedule_version = (int) get_option( 'sazcancel_schedule_version', 1 ) + 1;
		update_option( 'sazcancel_schedule_version', $schedule_version );

		// Dispatch background batch processor starting from cursor 0:
		$action_id = $this->schedule_single_action_safe(
			time(),
			'sazcancel_sync_delay_batch',
			array(
				'cursor_id' => 0,
				'version'   => $schedule_version,
			)
		);

		if ( $action_id <= 0 ) {
			update_option( 'sazcancel_sync_delay_error', array( 'version' => $schedule_version, 'time' => time() ), false );
			$this->add_activity_log(
				array(
					'timestamp' => time(),
					'status'    => 'ERROR',
					'message'   => __( 'Failed to dispatch background delay synchronization. Recovery Sweep will synchronize pending orders.', 'sazcancel-auto-cancel-on-hold-orders' ),
				)
			);
		} else {
			delete_option( 'sazcancel_sync_delay_error' );
		}
	}

	/**
	 * Asynchronously synchronize On-Hold order schedules to the new delay in batches of 100.
	 * Executes under atomic per-order locks and self-chains via Action Scheduler until all orders are updated.
	 *
	 * @param int $cursor_id Cursor order ID for batch slicing.
	 * @param int $version   Schedule version being synchronized.
	 */
	public function process_sync_delay_batch( $cursor_id = 0, $version = 0 ) {
		$current_version = (int) get_option( 'sazcancel_schedule_version', 1 );
		if ( (int) $version !== $current_version ) {
			// Superseded by a subsequent delay modification. Discard.
			return;
		}

		$eligible = $this->get_eligible_gateways();
		if ( empty( $eligible ) ) {
			return;
		}

		$batch_limit = 100;
		$order_ids   = $this->get_on_hold_order_ids_batch( $eligible, (int) $cursor_id, $batch_limit );

		if ( empty( $order_ids ) ) {
			// All On-Hold orders in the entire database have been synchronized!
			return;
		}

		foreach ( $order_ids as $order_id ) {
			$rf_key        = 'sazcancel_rf_' . $order_id;
			$initial_token = get_option( $rf_key, null );

			$lock_token = '';
			if ( ! $this->acquire_order_lock( $order_id, $lock_token, 30 ) ) {
				// Fast retry in 60s for congested order:
				$retry_id = $this->schedule_single_action_safe(
					time() + 60,
					'sazcancel_reconcile_order_schedule',
					array(
						'order_id' => (int) $order_id,
					)
				);
				if ( $retry_id <= 0 ) {
					$this->record_congested_retry_failure( $order_id );
				}
				continue;
			}

			try {
				// RE-CHECK LIVE SCHEDULE VERSION UNDER LOCK:
				$live_global_version = (int) get_option( 'sazcancel_schedule_version', 1 );
				if ( (int) $version !== $live_global_version ) {
					// Admin updated delay settings while this batch was running!
					// Abort obsolete batch immediately so newer chain handles remaining orders.
					return;
				}

				$healed = $this->heal_order_schedule_under_lock( $order_id, $lock_token );
				if ( $healed && ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
			} finally {
				$this->release_order_lock( $order_id, $lock_token );
			}
		}

		$last_id = end( $order_ids );
		// Self-chain next batch if current batch was full:
		if ( count( $order_ids ) >= $batch_limit ) {
			$chain_id = $this->schedule_single_action_safe(
				time(),
				'sazcancel_sync_delay_batch',
				array(
					'cursor_id' => (int) $last_id,
					'version'   => (int) $version,
				)
			);
			if ( $chain_id <= 0 ) {
				// Retry chain in 60s:
				$retry_chain_id = $this->schedule_single_action_safe(
					time() + 60,
					'sazcancel_sync_delay_batch',
					array(
						'cursor_id' => (int) $last_id,
						'version'   => (int) $version,
					)
				);
				if ( $retry_chain_id <= 0 ) {
					// Both scheduling attempts failed! Record batch sync interruption state:
					update_option(
						'sazcancel_sync_delay_error',
						array(
							'version'   => (int) $version,
							'cursor_id' => (int) $last_id,
							'failed_at' => time(),
						),
						false
					);
					$this->add_activity_log(
						array(
							'timestamp' => time(),
							'status'    => 'ERROR',
							'message'   => sprintf(
								/* translators: %d: cursor order ID */
								__( 'Failed to chain background delay synchronization at order ID #%d. Daily Recovery Sweep will resume synchronization.', 'sazcancel-auto-cancel-on-hold-orders' ),
								(int) $last_id
							),
						)
					);
				} else {
					delete_option( 'sazcancel_sync_delay_error' );
				}
			} else {
				delete_option( 'sazcancel_sync_delay_error' );
			}
		} else {
			// All On-Hold orders in the entire database have been synchronized!
			delete_option( 'sazcancel_sync_delay_error' );
		}
	}

	/**
	 * Reconcile and heal schedule for a single order under atomic lock.
	 * Used for fast retries when lock contention occurs during status transitions,
	 * recovery sweeps, or background batch synchronizations.
	 *
	 * @param int $order_id Order ID.
	 */
	public function reconcile_single_order( $order_id ) {
		$order_id = absint( $order_id );
		if ( empty( $order_id ) ) {
			return;
		}

		$rf_key        = 'sazcancel_rf_' . $order_id;
		$initial_token = get_option( $rf_key, null );

		$lock_token = '';
		if ( ! $this->acquire_order_lock( $order_id, $lock_token, 30 ) ) {
			// Still congested: reschedule fast retry in 60s
			$retry_id = $this->schedule_single_action_safe(
				time() + 60,
				'sazcancel_reconcile_order_schedule',
				array( 'order_id' => $order_id )
			);
			if ( $retry_id <= 0 ) {
				// Record failed retry without violating lock boundaries:
				$this->record_congested_retry_failure( $order_id );
			}
			return;
		}

		try {
			$healed = $this->heal_order_schedule_under_lock( $order_id, $lock_token );
			if ( $healed && ! empty( $initial_token ) ) {
				$this->clear_congested_retry_failure( $order_id, $initial_token );
			}
		} finally {
			$this->release_order_lock( $order_id, $lock_token );
		}
	}

	/**
	 * Heal and reconcile cancellation schedule for an order under an already acquired lock.
	 * Caller MUST hold the exclusive order lock before invoking this method.
	 *
	 * @param int    $order_id   Order ID.
	 * @param string $lock_token Active lock token proving current exclusive lease ownership.
	 * @return bool True if order schedule was successfully reconciled or resolution is confirmed (not on-hold / ineligible), false on scheduling failure or unverified lock.
	 */
	protected function heal_order_schedule_under_lock( $order_id, $lock_token ) {
		if ( empty( $lock_token ) || ! $this->is_lock_held_by( $order_id, $lock_token ) ) {
			return false;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order || 'on-hold' !== $order->get_status() ) {
			// Order no longer exists or left on-hold status. Reconciliation successfully resolved.
			return true;
		}
		if ( ! $this->is_gateway_eligible( $order->get_payment_method() ) ) {
			// Payment method not eligible. Reconciliation successfully resolved.
			return true;
		}

		$now              = time();
		$on_hold_at       = (int) $order->get_meta( '_sazcancel_on_hold_at' );
		$current_gen      = (int) $order->get_meta( '_sazcancel_generation' );
		$order_sched_ver  = (int) $order->get_meta( '_sazcancel_schedule_version' );
		$global_sched_ver = (int) get_option( 'sazcancel_schedule_version', 1 );
		$has_queue_err    = (bool) $order->get_meta( '_sazcancel_queue_error' );
		$delay_seconds    = $this->get_delay_seconds();

		// Safe Baseline: If on-hold timestamp was never recorded or is in the future (> $now), normalize strictly to $now:
		if ( empty( $on_hold_at ) || $on_hold_at <= 0 || $on_hold_at > $now ) {
			$on_hold_at = $now;
			$order->update_meta_data( '_sazcancel_on_hold_at', $on_hold_at );
			$order->save();
		}

		$elapsed          = max( 0, $now - $on_hold_at );
		$remaining        = $delay_seconds - $elapsed;
		$version_outdated = ( $order_sched_ver < $global_sched_ver );

		if ( $remaining <= 0 ) {
			// Delay expired: schedule immediate cancellation:
			$next_gen = max( 1, $current_gen + 1 );
			$order->update_meta_data( '_sazcancel_generation', $next_gen );
			$order->update_meta_data( '_sazcancel_schedule_version', $global_sched_ver );
			$order->save();

			if ( function_exists( 'as_unschedule_action' ) ) {
				if ( $current_gen > 0 ) {
					as_unschedule_action(
						'sazcancel_check_and_cancel_single_order',
						array(
							'order_id'   => (int) $order_id,
							'generation' => $current_gen,
						),
						'sazcancel'
					);
				}
				as_unschedule_action(
					'sazcancel_check_and_cancel_single_order',
					array(
						'order_id' => (int) $order_id,
					),
					'sazcancel'
				);
			}

			$action_id = $this->schedule_single_action_safe(
				$now,
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $next_gen,
				)
			);
			if ( $action_id <= 0 ) {
				$order->update_meta_data( '_sazcancel_queue_error', $now );
				$order->save();
				return false;
			}

			$order->delete_meta_data( '_sazcancel_queue_error' );
			$order->save();
			return true;
		} else {
			// Delay has not expired. Check if active action exists, target time is valid, and version matches:
			$has_valid_job = false;
			if ( $current_gen > 0 && ! $version_outdated && ! $has_queue_err && function_exists( 'as_next_scheduled_action' ) ) {
				$next_run = as_next_scheduled_action(
					'sazcancel_check_and_cancel_single_order',
					array(
						'order_id'   => (int) $order_id,
						'generation' => $current_gen,
					),
					'sazcancel'
				);
				$expected_target = $on_hold_at + $delay_seconds;
				if ( false !== $next_run && abs( (int) $next_run - $expected_target ) <= 60 ) {
					$has_valid_job = true;
				}
			}

			if ( ! $has_valid_job ) {
				// Queue healing: reschedule with bumped generation:
				$next_gen = max( 1, $current_gen + 1 );
				$order->update_meta_data( '_sazcancel_generation', $next_gen );
				$order->update_meta_data( '_sazcancel_schedule_version', $global_sched_ver );
				$order->save();

				if ( function_exists( 'as_unschedule_action' ) ) {
					if ( $current_gen > 0 ) {
						as_unschedule_action(
							'sazcancel_check_and_cancel_single_order',
							array(
								'order_id'   => (int) $order_id,
								'generation' => $current_gen,
							),
							'sazcancel'
						);
					}
					as_unschedule_action(
						'sazcancel_check_and_cancel_single_order',
						array(
							'order_id' => (int) $order_id,
						),
						'sazcancel'
					);
				}

				$action_id = $this->schedule_single_action_safe(
					$now + $remaining,
					'sazcancel_check_and_cancel_single_order',
					array(
						'order_id'   => (int) $order_id,
						'generation' => $next_gen,
					)
				);
				if ( $action_id <= 0 ) {
					$order->update_meta_data( '_sazcancel_queue_error', $now );
					$order->save();
					return false;
				}

				$order->delete_meta_data( '_sazcancel_queue_error' );
				$order->save();
				return true;
			}

			// Active job already exists with matching generation, correct target time, and current version. Schedule is healthy:
			return true;
		}
	}

	/**
	 * Fetch next batch of On-Hold order IDs strictly greater than cursor ID.
	 * Executes a lightweight cursor query at the database level without loading all IDs into memory.
	 * 100% compatible with both WooCommerce HPOS (Custom Order Tables) and legacy CPT.
	 *
	 * @param array $eligible  Eligible payment method slugs.
	 * @param int   $cursor_id Current cursor order ID. Default 0.
	 * @param int   $limit     Batch limit. Default 100.
	 * @return array Array of integer order IDs.
	 */
	protected function get_on_hold_order_ids_batch( array $eligible, $cursor_id = 0, $limit = 100 ) {
		global $wpdb;

		if ( empty( $eligible ) ) {
			return array();
		}

		$limit     = max( 1, min( 200, (int) $limit ) );
		$cursor_id = max( 0, (int) $cursor_id );

		// Check if High-Performance Order Storage (HPOS) is active.
		$hpos_active = false;
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && method_exists( '\Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled' ) ) {
			$hpos_active = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}

		$placeholders = implode( ', ', array_fill( 0, count( $eligible ), '%s' ) );

		if ( $hpos_active ) {
			$orders_table = $wpdb->prefix . 'wc_orders';
			$query_params = array_merge( $eligible, array( $cursor_id, $limit ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			$raw_sql = "SELECT id FROM {$orders_table}
				WHERE type = 'shop_order'
				  AND ( status = 'wc-on-hold' OR status = 'on-hold' )
				  AND payment_method IN ($placeholders)
				  AND id > %d
				ORDER BY id ASC
				LIMIT %d";
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$ids = $wpdb->get_col( $wpdb->prepare( $raw_sql, $query_params ) );
		} else {
			$query_params = array_merge( $eligible, array( $cursor_id, $limit ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			$raw_sql = "SELECT DISTINCT p.ID FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON (p.ID = pm.post_id AND pm.meta_key = '_payment_method')
				WHERE p.post_type = 'shop_order'
				  AND p.post_status = 'wc-on-hold'
				  AND pm.meta_value IN ($placeholders)
				  AND p.ID > %d
				ORDER BY p.ID ASC
				LIMIT %d";
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$ids = $wpdb->get_col( $wpdb->prepare( $raw_sql, $query_params ) );
		}

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Safely schedule single action with result checking.
	 *
	 * @param int    $timestamp Execution timestamp.
	 * @param string $hook      Action hook.
	 * @param array  $args      Action arguments.
	 * @param string $group     Action group. Default 'sazcancel'.
	 * @return int Action ID on success, or 0 on failure.
	 */
	protected function schedule_single_action_safe( $timestamp, $hook, $args = array(), $group = 'sazcancel' ) {
		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return 0;
		}
		$action_id = as_schedule_single_action( (int) $timestamp, $hook, $args, $group, false );
		return (int) $action_id;
	}

	/**
	 * Check if payment gateway is eligible.
	 *
	 * @param string $gateway_id Gateway ID.
	 * @return bool
	 */
	public function is_gateway_eligible( $gateway_id ) {
		if ( empty( $gateway_id ) ) {
			return false;
		}
		return in_array( $gateway_id, $this->get_eligible_gateways(), true );
	}

	/**
	 * Check if master switch is enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return 'yes' === get_option( 'sazcancel_enabled', 'no' );
	}

	/**
	 * Check if Dry Run mode is active.
	 *
	 * @return bool
	 */
	public function is_dry_run() {
		return 'yes' === get_option( 'sazcancel_dry_run', 'yes' );
	}

	/**
	 * Add an entry to the ring-buffer Activity Log (wp_options, autoload = false, max 30).
	 *
	 * @param array $entry Entry details.
	 */
	public function add_activity_log( $entry ) {
		$log = get_option( 'sazcancel_activity_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		$formatted = array(
			'timestamp'    => isset( $entry['timestamp'] ) ? (int) $entry['timestamp'] : time(),
			'order_id'     => isset( $entry['order_id'] ) ? (int) $entry['order_id'] : 0,
			'gateway'      => isset( $entry['gateway'] ) ? sanitize_text_field( $entry['gateway'] ) : '-',
			'total'        => isset( $entry['total'] ) ? wp_strip_all_tags( $entry['total'] ) : '-',
			'time_on_hold' => isset( $entry['time_on_hold'] ) ? sanitize_text_field( $entry['time_on_hold'] ) : '-',
			'status'       => isset( $entry['status'] ) ? sanitize_text_field( $entry['status'] ) : 'INFO',
			'message'      => isset( $entry['message'] ) ? sanitize_text_field( $entry['message'] ) : '',
		);

		array_unshift( $log, $formatted );
		$log = array_slice( $log, 0, 30 );

		update_option( 'sazcancel_activity_log', $log, false );
	}

	/**
	 * Hook: Order transitioned to On-Hold status.
	 * Executes under atomic per-order lock to serialize with Recovery Sweep and delay sync.
	 *
	 * @param int      $order_id Order ID.
	 * @param WC_Order $order    Order object.
	 */
	public function on_order_status_on_hold( $order_id, $order = null ) {
		$order_id = absint( $order_id );
		if ( empty( $order_id ) ) {
			return;
		}

		$rf_key        = 'sazcancel_rf_' . $order_id;
		$initial_token = get_option( $rf_key, null );

		$lock_token = '';
		if ( ! $this->acquire_order_lock( $order_id, $lock_token, 30 ) ) {
			// Lock contention: another worker or sync process is operating on this order.
			// Fast retry in 60s via dedicated reconciliation handler:
			$retry_id = $this->schedule_single_action_safe(
				time() + 60,
				'sazcancel_reconcile_order_schedule',
				array(
					'order_id' => (int) $order_id,
				)
			);
			if ( $retry_id <= 0 ) {
				$this->record_congested_retry_failure( $order_id );
			}
			return;
		}

		try {
			$fresh_order = wc_get_order( $order_id );
			if ( ! $fresh_order instanceof WC_Order || 'on-hold' !== $fresh_order->get_status() ) {
				if ( ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
				return;
			}

			$gateway = $fresh_order->get_payment_method();
			if ( ! $this->is_gateway_eligible( $gateway ) ) {
				if ( ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
				return;
			}

			$now              = time();
			$current_gen      = (int) $fresh_order->get_meta( '_sazcancel_generation' );
			$generation       = $current_gen + 1;
			$delay_seconds    = $this->get_delay_seconds();
			$cancel_at        = $now + $delay_seconds;
			$schedule_version = (int) get_option( 'sazcancel_schedule_version', 1 );

			// 1. Save metadata FIRST under lock before scheduling:
			$fresh_order->update_meta_data( '_sazcancel_on_hold_at', $now );
			$fresh_order->update_meta_data( '_sazcancel_generation', $generation );
			$fresh_order->update_meta_data( '_sazcancel_schedule_version', $schedule_version );
			$fresh_order->save();

			// 2. Unschedule old action if exists (both with generation and legacy argument):
			if ( function_exists( 'as_unschedule_action' ) ) {
				if ( $current_gen > 0 ) {
					as_unschedule_action(
						'sazcancel_check_and_cancel_single_order',
						array(
							'order_id'   => (int) $order_id,
							'generation' => $current_gen,
						),
						'sazcancel'
					);
				}
				as_unschedule_action(
					'sazcancel_check_and_cancel_single_order',
					array(
						'order_id' => (int) $order_id,
					),
					'sazcancel'
				);
			}

			// 3. Schedule single action with unique = false:
			$action_id = $this->schedule_single_action_safe(
				$cancel_at,
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $generation,
				)
			);

			if ( $action_id <= 0 ) {
				$fresh_order->update_meta_data( '_sazcancel_queue_error', $now );
				$fresh_order->save();
				$this->record_congested_retry_failure( $order_id );
				$this->add_activity_log(
					array(
						'timestamp'    => $now,
						'order_id'     => $order_id,
						'gateway'      => $gateway,
						'total'        => $fresh_order->get_formatted_order_total(),
						'time_on_hold' => '-',
						'status'       => 'ERROR',
						'message'      => __( 'Failed to queue cancellation action. Marked for queue healing by Recovery Sweep.', 'sazcancel-auto-cancel-on-hold-orders' ),
					)
				);
			} else {
				$fresh_order->delete_meta_data( '_sazcancel_queue_error' );
				$fresh_order->save();
				if ( ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
			}
		} finally {
			$this->release_order_lock( $order_id, $lock_token );
		}
	}

	/**
	 * Hook: Order status changed.
	 * When an order leaves On-Hold status, immediately unschedule the pending action,
	 * bump generation token to invalidate any running workers, and clean meta under lock.
	 *
	 * @param int      $order_id   Order ID.
	 * @param string   $old_status Previous status.
	 * @param string   $new_status New status.
	 * @param WC_Order $order      Order object.
	 */
	public function on_order_status_changed( $order_id, $old_status, $new_status, $order = null ) {
		if ( 'on-hold' === $old_status && 'on-hold' !== $new_status ) {
			$order_id      = absint( $order_id );
			$rf_key        = 'sazcancel_rf_' . $order_id;
			$initial_token = get_option( $rf_key, null );
			$lock_token    = '';
			$locked        = $this->acquire_order_lock( $order_id, $lock_token, 30 );

			try {
				$target_order = wc_get_order( $order_id );
				if ( ! $target_order instanceof WC_Order ) {
					$target_order = $order;
				}

				$current_gen = 0;
				if ( $target_order instanceof WC_Order ) {
					$current_gen = (int) $target_order->get_meta( '_sazcancel_generation' );
					$target_order->update_meta_data( '_sazcancel_generation', $current_gen + 1 );
					$target_order->delete_meta_data( '_sazcancel_on_hold_at' );
					$target_order->delete_meta_data( '_sazcancel_queue_error' );
					$target_order->save();
				}

				if ( function_exists( 'as_unschedule_action' ) ) {
					as_unschedule_action(
						'sazcancel_check_and_cancel_single_order',
						array(
							'order_id'   => (int) $order_id,
							'generation' => $current_gen,
						),
						'sazcancel'
					);
					as_unschedule_action(
						'sazcancel_check_and_cancel_single_order',
						array(
							'order_id' => (int) $order_id,
						),
						'sazcancel'
					);
				}

				if ( ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
			} finally {
				if ( $locked ) {
					$this->release_order_lock( $order_id, $lock_token );
				}
			}
		}
	}

	/**
	 * Atomically record an order ID whose retry scheduling failed during lock contention.
	 * Stored as an isolated individual option per order with a unique microsecond timestamp
	 * to eliminate all shared array race conditions and enable atomic conditional deletion.
	 *
	 * @param int $order_id Order ID.
	 */
	protected function record_congested_retry_failure( $order_id ) {
		$order_id = absint( $order_id );
		if ( empty( $order_id ) ) {
			return;
		}

		$rf_key  = 'sazcancel_rf_' . $order_id;
		$val_str = wp_generate_password( 32, false ) . '|' . time();
		update_option( $rf_key, $val_str, false );
		$this->clean_lock_cache( $rf_key );
	}

	/**
	 * Atomically remove an order ID from the congested retry failure pool under lock.
	 * Requires an expected token value to execute strict Compare-And-Delete (CAD).
	 * Eliminates all races against parallel workers writing newer failure tokens.
	 *
	 * @param int    $order_id       Order ID.
	 * @param string $expected_token Expected token string to match before deletion.
	 * @return bool True if row was matched and deleted (1 row affected), false otherwise.
	 */
	protected function clear_congested_retry_failure( $order_id, $expected_token ) {
		$order_id = absint( $order_id );
		if ( empty( $order_id ) || empty( $expected_token ) ) {
			return false;
		}

		global $wpdb;
		$rf_key  = 'sazcancel_rf_' . $order_id;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$deleted = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
				$rf_key,
				$expected_token
			)
		);

		if ( 1 === $deleted ) {
			$this->clean_lock_cache( $rf_key );
			return true;
		}

		return false;
	}

	/**
	 * Invalidate both option cache and notoptions cache for an option key.
	 * Guarantees 100% synchronization with WordPress Core object cache.
	 *
	 * @param string $lock_key Option name.
	 */
	protected function clean_lock_cache( $lock_key ) {
		wp_cache_delete( $lock_key, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}

	/**
	 * Acquire an exclusive atomic lock for an order using direct MySQL INSERT (no ON DUPLICATE KEY UPDATE).
	 *
	 * Eliminates check-then-set race conditions:
	 * 1. Initial lock uses direct SQL INSERT INTO wp_options (relying on MySQL UNIQUE KEY constraint on option_name).
	 *    We do NOT use add_option() because modern WordPress Core can issue ON DUPLICATE KEY UPDATE
	 *    under concurrent requests, which could overwrite a competing worker's token. Direct INSERT
	 *    guarantees that only exactly one worker succeeds ($inserted === 1) and any duplicate fails.
	 * 2. Stale/expired lock reclamation uses an atomic CAS SQL UPDATE:
	 *    UPDATE wp_options SET option_value = :new_val WHERE option_name = :key AND option_value = :old_val
	 *    Only exactly one competing worker can succeed in claiming an expired lock.
	 * 3. Invalidates WordPress options cache & notoptions cache.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $token    Generated owner token (passed by reference).
	 * @param int    $ttl      Time to live in seconds (default 120).
	 * @return bool True if exclusively acquired, false otherwise.
	 */
	public function acquire_order_lock( $order_id, &$token, $ttl = 120 ) {
		global $wpdb;

		$lock_key = 'sazcancel_lock_order_' . absint( $order_id );
		$token    = wp_generate_password( 32, false );
		$now      = time();
		$new_val  = $token . '|' . ( $now + $ttl );

		// 1. Primary Atomic Insertion: Direct INSERT without ON DUPLICATE KEY UPDATE.
		$suppress = $wpdb->suppress_errors( true );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$lock_key,
				$new_val
			)
		);
		$wpdb->suppress_errors( $suppress );

		if ( 1 === $inserted ) {
			$this->clean_lock_cache( $lock_key );
			return true;
		}

		// 2. Lock option already exists. Check if stale/expired (worker crash recovery).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
				$lock_key
			)
		);

		if ( ! $row ) {
			// If deleted between INSERT and SELECT, retry direct INSERT once.
			$suppress = $wpdb->suppress_errors( true );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$retry    = $wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
					$lock_key,
					$new_val
				)
			);
			$wpdb->suppress_errors( $suppress );

			if ( 1 === $retry ) {
				$this->clean_lock_cache( $lock_key );
				return true;
			}
			return false;
		}

		$parts            = explode( '|', $row->option_value );
		$existing_expires = isset( $parts[1] ) ? (int) $parts[1] : 0;

		if ( $existing_expires < $now ) {
			// 3. Stale lock detected: Atomic Compare-And-Swap (CAS) UPDATE.
			// Only updates if option_value is STILL the exact stale value inspected above.
			// Guarantees zero race condition between competing recovery workers.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
					$new_val,
					$lock_key,
					$row->option_value
				)
			);

			if ( 1 === $updated ) {
				$this->clean_lock_cache( $lock_key );
				return true;
			}
		}

		return false;
	}

	/**
	 * Release an exclusive order lock with atomic owner token verification and cache invalidation.
	 *
	 * Uses an atomic conditional DELETE:
	 * DELETE FROM wp_options WHERE option_name = :key AND option_value LIKE ':token|%'
	 * Guarantees Worker A will NEVER delete Worker B's lock if Worker A ran longer than TTL.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $token    Owner token obtained during acquisition.
	 */
	public function release_order_lock( $order_id, $token ) {
		if ( empty( $token ) ) {
			return;
		}

		global $wpdb;
		$lock_key = 'sazcancel_lock_order_' . absint( $order_id );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value LIKE %s",
				$lock_key,
				$wpdb->esc_like( $token ) . '|%'
			)
		);
		$this->clean_lock_cache( $lock_key );
	}

	/**
	 * Atomically verify lock ownership and extend TTL lease immediately before irreversible status mutation.
	 * Executes atomic Compare-And-Swap (CAS) UPDATE verifying token ownership and active lease.
	 *
	 * @param int    $order_id   Order ID.
	 * @param string $lock_token Owner token.
	 * @param int    $ttl        Additional lease time in seconds (default 120).
	 * @return bool True if lease was atomically verified and extended.
	 */
	public function touch_order_lock( $order_id, $lock_token, $ttl = 120 ) {
		if ( empty( $lock_token ) ) {
			return false;
		}

		global $wpdb;
		$lock_key    = 'sazcancel_lock_order_' . absint( $order_id );
		$now         = time();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$current_val = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
				$lock_key
			)
		);

		if ( ! $current_val ) {
			return false;
		}

		$parts = explode( '|', $current_val );
		if ( count( $parts ) < 2 ) {
			return false;
		}

		$held_token   = $parts[0];
		$lock_expires = (int) $parts[1];

		// Must match token and must not be expired:
		if ( ! hash_equals( $held_token, $lock_token ) || $lock_expires < $now ) {
			return false;
		}

		// Always guarantee new expiration is strictly greater than current expiration
		// so MySQL UPDATE always mutates the row and returns 1 affected row:
		$new_expires = max( $now + $ttl, $lock_expires + 1 );
		$new_val     = $lock_token . '|' . $new_expires;

		// Atomic Compare-And-Swap (CAS):
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				$new_val,
				$lock_key,
				$current_val
			)
		);

		if ( 1 === $updated ) {
			$this->clean_lock_cache( $lock_key );
			return true;
		}

		return false;
	}

	/**
	 * Verify if the lock is currently held by the specified token and hasn't expired.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $token    Owner token.
	 * @return bool True if lock is valid and held by this worker.
	 */
	public function is_lock_held_by( $order_id, $token ) {
		if ( empty( $token ) ) {
			return false;
		}

		global $wpdb;
		$lock_key = 'sazcancel_lock_order_' . absint( $order_id );
		$now      = time();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$val = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
				$lock_key
			)
		);

		if ( ! $val ) {
			return false;
		}

		$parts = explode( '|', $val );
		if ( count( $parts ) < 2 ) {
			return false;
		}

		$lock_token   = $parts[0];
		$lock_expires = (int) $parts[1];

		return ( hash_equals( $lock_token, $token ) && $lock_expires >= $now );
	}

	/**
	 * Process a single order cancellation with Strict Fencing Token generation check,
	 * Safe Legacy Task Migration, and genuine atomic exclusive locking.
	 *
	 * @param int $order_id   Order ID.
	 * @param int $generation Schedule generation counter (fencing token). Default 0.
	 */
	public function process_single_order( $order_id, $generation = 0 ) {
		$order_id   = absint( $order_id );
		$generation = (int) $generation;
		if ( empty( $order_id ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$current_gen = (int) $order->get_meta( '_sazcancel_generation' );

		// 1. Strict Legacy Migration:
		// If task was scheduled by a legacy plugin version without generation ($generation <= 0)
		// OR order meta has not been initialized with generation ($current_gen <= 0):
		// NEVER allow direct cancellation! Safely migrate order to positive generation under lock.
		if ( $generation <= 0 || $current_gen <= 0 ) {
			$this->migrate_legacy_order_schedule( $order );
			return;
		}

		// 2. Strict Generation Fencing Check:
		// Task generation must strictly match the order's current generation.
		// If superseded by a timer change, status transition, or recovery reschedule, discard immediately.
		if ( $generation !== $current_gen ) {
			return;
		}

		// 3. Genuine Atomic Concurrency Lock: Direct MySQL INSERT + atomic CAS.
		$lock_token = '';
		if ( ! $this->acquire_order_lock( $order_id, $lock_token ) ) {
			// Lock contention: another worker or sync process is currently operating on this order.
			// Reschedule retry in 60 seconds with the SAME generation so this task is NEVER lost!
			$retry_id = $this->schedule_single_action_safe(
				time() + 60,
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $generation,
				)
			);
			if ( $retry_id <= 0 ) {
				$this->record_congested_retry_failure( $order_id );
			}
			return;
		}

		$rf_key        = 'sazcancel_rf_' . $order_id;
		$initial_token = get_option( $rf_key, null );

		try {
			if ( ! empty( $initial_token ) ) {
				$this->clear_congested_retry_failure( $order_id, $initial_token );
			}
			$this->execute_single_order_cancellation( $order_id, $generation, $lock_token );
		} finally {
			$this->release_order_lock( $order_id, $lock_token );
		}
	}

	/**
	 * Migrate legacy order or unversioned action to positive generation under lock.
	 * Guarantees that actions with generation <= 0 CAN NEVER directly cancel an order.
	 * Delegates to heal_order_schedule_under_lock() to ensure 100% unified scheduling.
	 *
	 * @param WC_Order $order Order object.
	 */
	protected function migrate_legacy_order_schedule( $order ) {
		$order_id   = $order->get_id();
		$rf_key     = 'sazcancel_rf_' . $order_id;
		$init_token = get_option( $rf_key, null );
		$lock_token = '';

		// If lock is busy, reschedule retry via reconcile_single_order:
		if ( ! $this->acquire_order_lock( $order_id, $lock_token, 30 ) ) {
			$retry_id = $this->schedule_single_action_safe(
				time() + 60,
				'sazcancel_reconcile_order_schedule',
				array(
					'order_id' => (int) $order_id,
				)
			);
			if ( $retry_id <= 0 ) {
				$this->record_congested_retry_failure( $order_id );
			}
			return;
		}

		try {
			$healed = $this->heal_order_schedule_under_lock( $order_id, $lock_token );
			if ( $healed && ! empty( $init_token ) ) {
				$this->clear_congested_retry_failure( $order_id, $init_token );
			}
		} finally {
			$this->release_order_lock( $order_id, $lock_token );
		}
	}

	/**
	 * Worker execution for single order cancellation with multi-layer revalidations.
	 *
	 * @param int    $order_id   Order ID.
	 * @param int    $generation Generation token.
	 * @param string $lock_token Lock owner token.
	 */
	protected function execute_single_order_cancellation( $order_id, $generation = 0, $lock_token = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		// 1. Last-Moment Status Revalidation.
		if ( 'on-hold' !== $order->get_status() ) {
			$this->add_activity_log(
				array(
					'timestamp'    => time(),
					'order_id'     => $order_id,
					'gateway'      => $order->get_payment_method(),
					'total'        => $order->get_formatted_order_total(),
					'time_on_hold' => '-',
					'status'       => 'SKIPPED',
					'message'      => sprintf(
						/* translators: %s: current order status */
						__( 'Skipped: Order status is "%s" (no longer on-hold)', 'sazcancel-auto-cancel-on-hold-orders' ),
						$order->get_status()
					),
				)
			);
			return;
		}

		// 2. Gateway Eligibility Check.
		$gateway = $order->get_payment_method();
		if ( ! $this->is_gateway_eligible( $gateway ) ) {
			$this->add_activity_log(
				array(
					'timestamp'    => time(),
					'order_id'     => $order_id,
					'gateway'      => $gateway,
					'total'        => $order->get_formatted_order_total(),
					'time_on_hold' => '-',
					'status'       => 'SKIPPED',
					'message'      => __( 'Skipped: Payment method is no longer in eligible list', 'sazcancel-auto-cancel-on-hold-orders' ),
				)
			);
			return;
		}

		// 3. Strict Fencing Token Verification: Must be positive and match order generation.
		$current_gen = (int) $order->get_meta( '_sazcancel_generation' );
		if ( $generation <= 0 || $current_gen <= 0 || $generation !== $current_gen ) {
			return;
		}

		// 4. Strict On-Hold Age Verification & Safe Legacy Baseline.
		$now        = time();
		$on_hold_at = (int) $order->get_meta( '_sazcancel_on_hold_at' );

		// SAFE LEGACY INVARIANT: Never cancel immediately on empty or future meta!
		// If meta is missing or in the future (> $now), establish baseline now, increment generation, and schedule full grace period.
		if ( empty( $on_hold_at ) || $on_hold_at <= 0 || $on_hold_at > $now ) {
			$on_hold_at    = $now;
			$next_gen      = $current_gen + 1;
			$delay_seconds = $this->get_delay_seconds();

			// 1. Save metadata first under lock:
			$order->update_meta_data( '_sazcancel_on_hold_at', $now );
			$order->update_meta_data( '_sazcancel_generation', $next_gen );
			$order->save();

			// 2. Schedule action with unique = false:
			$action_id = $this->schedule_single_action_safe(
				$now + $delay_seconds,
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $next_gen,
				)
			);

			if ( $action_id <= 0 ) {
				$order->update_meta_data( '_sazcancel_queue_error', $now );
				$order->save();
			} else {
				$order->delete_meta_data( '_sazcancel_queue_error' );
				$order->save();
			}
			return;
		}

		$delay_seconds = $this->get_delay_seconds();
		$elapsed       = max( 0, $now - $on_hold_at );

		// 5. Premature Execution Guard / Delay Changed Reschedule:
		// If merchant increased delay, bump generation and schedule the remaining duration.
		// Bumping generation renders any previous redundant actions harmless without falling into as_next_scheduled_action traps.
		if ( $elapsed < $delay_seconds ) {
			$remaining = $delay_seconds - $elapsed;
			$next_gen  = $current_gen + 1;

			// 1. Save metadata first under lock:
			$order->update_meta_data( '_sazcancel_generation', $next_gen );
			$order->save();

			// 2. Schedule action with unique = false:
			$action_id = $this->schedule_single_action_safe(
				time() + max( 1, $remaining ),
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $next_gen,
				)
			);

			if ( $action_id <= 0 ) {
				$order->update_meta_data( '_sazcancel_queue_error', time() );
				$order->save();
			} else {
				$order->delete_meta_data( '_sazcancel_queue_error' );
				$order->save();
			}
			return;
		}

		$elapsed_str = $this->format_elapsed_time( $elapsed );
		$is_dry_run  = $this->is_dry_run();
		$is_enabled  = $this->is_enabled();

		// 6. Dry Run / Disabled Check (Zero-Disaster Guard).
		if ( $is_dry_run || ! $is_enabled ) {
			$mode_label = $is_dry_run ? __( '[DRY RUN]', 'sazcancel-auto-cancel-on-hold-orders' ) : __( '[PAUSED]', 'sazcancel-auto-cancel-on-hold-orders' );
			$this->add_activity_log(
				array(
					'timestamp'    => time(),
					'order_id'     => $order_id,
					'gateway'      => $gateway,
					'total'        => $order->get_formatted_order_total(),
					'time_on_hold' => $elapsed_str,
					'status'       => 'DRY_RUN',
					'message'      => sprintf(
						/* translators: 1: mode label, 2: elapsed time */
						__( '%1$s Would cancel order and restore stock (On-Hold for %2$s)', 'sazcancel-auto-cancel-on-hold-orders' ),
						$mode_label,
						$elapsed_str
					),
				)
			);
			return;
		}

		// 7. LAST-SECOND RECHECK IMMEDIATELY BEFORE CANCELLATION (RACE CONDITION HARDENING):
		// Freshly query database to verify status, gateway, timeout, operating mode, and lock lease.
		$fresh_order = wc_get_order( $order_id );
		if ( ! $fresh_order instanceof WC_Order || 'on-hold' !== $fresh_order->get_status() ) {
			return;
		}
		if ( ! $this->is_gateway_eligible( $fresh_order->get_payment_method() ) ) {
			return;
		}

		$fresh_gen = (int) $fresh_order->get_meta( '_sazcancel_generation' );
		if ( $generation <= 0 || $fresh_gen <= 0 || $fresh_gen !== $generation ) {
			return;
		}

		$fresh_delay_seconds = $this->get_delay_seconds();
		$fresh_on_hold_at    = (int) $fresh_order->get_meta( '_sazcancel_on_hold_at' );
		$now_check           = time();

		// SAFE LEGACY INVARIANT HARDENING: If timestamp is unexpectedly missing or future at final check,
		// NEVER cancel! Establish baseline now, bump generation, and reschedule full grace period.
		if ( empty( $fresh_on_hold_at ) || $fresh_on_hold_at <= 0 || $fresh_on_hold_at > $now_check ) {
			$fresh_on_hold_at = $now_check;
			$next_gen         = $fresh_gen + 1;

			// 1. Save metadata first under lock:
			$fresh_order->update_meta_data( '_sazcancel_on_hold_at', $now_check );
			$fresh_order->update_meta_data( '_sazcancel_generation', $next_gen );
			$fresh_order->save();

			// 2. Schedule action with unique = false:
			$action_id = $this->schedule_single_action_safe(
				$now_check + $fresh_delay_seconds,
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $next_gen,
				)
			);

			if ( $action_id <= 0 ) {
				$fresh_order->update_meta_data( '_sazcancel_queue_error', $now_check );
				$fresh_order->save();
			} else {
				$fresh_order->delete_meta_data( '_sazcancel_queue_error' );
				$fresh_order->save();
			}
			return;
		}

		$fresh_elapsed = max( 0, $now_check - $fresh_on_hold_at );
		if ( $fresh_elapsed < $fresh_delay_seconds ) {
			$fresh_remaining = $fresh_delay_seconds - $fresh_elapsed;
			$next_gen        = $fresh_gen + 1;

			// 1. Save metadata first under lock:
			$fresh_order->update_meta_data( '_sazcancel_generation', $next_gen );
			$fresh_order->save();

			// 2. Schedule action with unique = false:
			$action_id = $this->schedule_single_action_safe(
				$now_check + max( 1, $fresh_remaining ),
				'sazcancel_check_and_cancel_single_order',
				array(
					'order_id'   => (int) $order_id,
					'generation' => $next_gen,
				)
			);

			if ( $action_id <= 0 ) {
				$fresh_order->update_meta_data( '_sazcancel_queue_error', time() );
				$fresh_order->save();
			} else {
				$fresh_order->delete_meta_data( '_sazcancel_queue_error' );
				$fresh_order->save();
			}
			return;
		}

		if ( $this->is_dry_run() || ! $this->is_enabled() ) {
			return;
		}

		// FENCING TOKEN & LEASE RENEWAL: Atomically verify ownership AND extend lease immediately before irreversible mutation.
		if ( ! $this->touch_order_lock( $order_id, $lock_token, 120 ) ) {
			return;
		}

		// Final check: confirm order status has not changed concurrently immediately before mutation:
		if ( 'on-hold' !== $fresh_order->get_status() ) {
			return;
		}

		$note_template = get_option( 'sazcancel_note', '' );
		if ( empty( $note_template ) ) {
			$note_template = __( 'Auto-cancelled by SazCancel due to unpaid On-Hold timeout.', 'sazcancel-auto-cancel-on-hold-orders' );
		}

		// Clean queue error flag and update status in single Core mutation:
		$fresh_order->delete_meta_data( '_sazcancel_queue_error' );
		$fresh_order->update_status( 'cancelled', $note_template );

		$this->add_activity_log(
			array(
				'timestamp'    => time(),
				'order_id'     => $order_id,
				'gateway'      => $gateway,
				'total'        => $fresh_order->get_formatted_order_total(),
				'time_on_hold' => $elapsed_str,
				'status'       => 'CANCELLED',
				'message'      => sprintf(
					/* translators: %s: elapsed time */
					__( 'Order cancelled (WC Core restores stock if managed & previously reduced; On-Hold for %s)', 'sazcancel-auto-cancel-on-hold-orders' ),
					$elapsed_str
				),
			)
		);
	}

	/**
	 * Safe Legacy Recovery Sweep (Scheduled once daily).
	 *
	 * Implements safe baseline grace period for legacy orders and heals missing Action Scheduler jobs.
	 * Executes under atomic per-order locks and uses database-level cursor queries without loading all IDs into memory.
	 */
	public function process_daily_recovery_sweep() {
		$eligible = $this->get_eligible_gateways();
		if ( empty( $eligible ) ) {
			return;
		}

		$current_version = (int) get_option( 'sazcancel_schedule_version', 1 );

		// 1. Check if a background delay synchronization batch chain was previously interrupted:
		$sync_error = get_option( 'sazcancel_sync_delay_error', null );
		if ( is_array( $sync_error ) && ! empty( $sync_error['version'] ) ) {
			if ( (int) $sync_error['version'] === $current_version ) {
				// Resume the interrupted batch chain from the recorded cursor:
				$resumed_chain = $this->schedule_single_action_safe(
					time(),
					'sazcancel_sync_delay_batch',
					array(
						'cursor_id' => isset( $sync_error['cursor_id'] ) ? (int) $sync_error['cursor_id'] : 0,
						'version'   => $current_version,
					)
				);
				if ( $resumed_chain > 0 ) {
					delete_option( 'sazcancel_sync_delay_error' );
				}
			} else {
				// Obsolete version; discard error:
				delete_option( 'sazcancel_sync_delay_error' );
			}
		}

		// 2. Heal any orders that failed retry scheduling during previous lock contention:
		global $wpdb;
		$sazcancel_like_pattern = $wpdb->esc_like( 'sazcancel_rf_' ) . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$failed_rows            = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 100",
				$sazcancel_like_pattern
			)
		);
		if ( ! empty( $failed_rows ) ) {
			foreach ( $failed_rows as $row ) {
				$rf_key    = $row->option_name;
				$rf_val    = $row->option_value;
				$failed_id = (int) str_replace( 'sazcancel_rf_', '', $rf_key );
				if ( $failed_id <= 0 ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->query(
						$wpdb->prepare(
							"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
							$rf_key,
							$rf_val
						)
					);
					$this->clean_lock_cache( $rf_key );
					continue;
				}

				$c_token = '';
				if ( $this->acquire_order_lock( $failed_id, $c_token, 30 ) ) {
					try {
						$healed = $this->heal_order_schedule_under_lock( $failed_id, $c_token );
						if ( $healed ) {
							$this->clear_congested_retry_failure( $failed_id, $rf_val );
						}
					} finally {
						$this->release_order_lock( $failed_id, $c_token );
					}
				} else {
					// Lock is congested by another worker. Reschedule retry without deleting failure marker.
					// Marker will be cleaned under lock once reconciliation completes.
					$this->schedule_single_action_safe(
						time() + 60,
						'sazcancel_reconcile_order_schedule',
						array( 'order_id' => $failed_id )
					);
				}
			}
		}

		// 3. Database cursor-based daily sweep:
		$cursor_id   = (int) get_option( 'sazcancel_sweep_cursor_id', 0 );
		$batch_limit = 100;
		$batch_ids   = $this->get_on_hold_order_ids_batch( $eligible, $cursor_id, $batch_limit );

		if ( empty( $batch_ids ) && $cursor_id > 0 ) {
			// End of database reached: wrap around to ID 0
			$cursor_id = 0;
			$batch_ids = $this->get_on_hold_order_ids_batch( $eligible, 0, $batch_limit );
		}

		if ( empty( $batch_ids ) ) {
			update_option( 'sazcancel_sweep_cursor_id', 0 );
			return;
		}

		// 4. Process each order in batch under per-order atomic lock:
		foreach ( $batch_ids as $order_id ) {
			$rf_key        = 'sazcancel_rf_' . $order_id;
			$initial_token = get_option( $rf_key, null );

			$lock_token = '';
			if ( ! $this->acquire_order_lock( $order_id, $lock_token, 30 ) ) {
				// Fast retry in 60s for congested order:
				$retry_id = $this->schedule_single_action_safe(
					time() + 60,
					'sazcancel_reconcile_order_schedule',
					array(
						'order_id' => (int) $order_id,
					)
				);
				if ( $retry_id <= 0 ) {
					$this->record_congested_retry_failure( $order_id );
				}
				continue;
			}

			try {
				$healed = $this->heal_order_schedule_under_lock( $order_id, $lock_token );
				if ( $healed && ! empty( $initial_token ) ) {
					$this->clear_congested_retry_failure( $order_id, $initial_token );
				}
			} finally {
				$this->release_order_lock( $order_id, $lock_token );
			}
		}

		$last_id = end( $batch_ids );
		update_option( 'sazcancel_sweep_cursor_id', (int) $last_id );
	}

	/**
	 * Run a read-only preview sweep of eligible On-Hold orders for merchant auditing.
	 * ZERO mutations to store data: Never changes order statuses, never alters stock, never modifies or schedules AS jobs.
	 * Diagnostic preview entries are recorded into the Activity Log.
	 * Uses an atomic ID snapshot (up to 150 orders) to eliminate offset drift.
	 *
	 * @param int $limit Maximum number of orders to analyze. Default 150.
	 * @return int Number of eligible orders analyzed.
	 */
	public function preview_recovery_sweep( $limit = 150 ) {
		$eligible = $this->get_eligible_gateways();
		if ( empty( $eligible ) ) {
			return 0;
		}

		$delay_seconds = $this->get_delay_seconds();

		// Snapshot candidate IDs:
		$order_ids = wc_get_orders(
			array(
				'status'         => 'on-hold',
				'payment_method' => $eligible,
				'limit'          => $limit,
				'return'         => 'ids',
				'orderby'        => 'date',
				'order'          => 'ASC',
			)
		);

		if ( empty( $order_ids ) ) {
			return 0;
		}

		$count = 0;

		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$now        = time();
			$on_hold_at = (int) $order->get_meta( '_sazcancel_on_hold_at' );

			if ( empty( $on_hold_at ) || $on_hold_at <= 0 || $on_hold_at > $now ) {
				$this->add_activity_log(
					array(
						'timestamp'    => $now,
						'order_id'     => $order_id,
						'gateway'      => $order->get_payment_method(),
						'total'        => $order->get_formatted_order_total(),
						'time_on_hold' => __( 'First detected', 'sazcancel-auto-cancel-on-hold-orders' ),
						'status'       => 'PREVIEW',
						'message'      => sprintf(
							/* translators: %s: delay period */
							__( '[PREVIEW] Legacy order without timer. Would receive safe baseline now (+%s grace period). Store data unmodified.', 'sazcancel-auto-cancel-on-hold-orders' ),
							$this->format_elapsed_time( $delay_seconds )
						),
					)
				);
				$count++;
			} else {
				$elapsed     = max( 0, $now - $on_hold_at );
				$elapsed_str = $this->format_elapsed_time( $elapsed );

				if ( $elapsed >= $delay_seconds ) {
					$this->add_activity_log(
						array(
							'timestamp'    => time(),
							'order_id'     => $order_id,
							'gateway'      => $order->get_payment_method(),
							'total'        => $order->get_formatted_order_total(),
							'time_on_hold' => $elapsed_str,
							'status'       => 'PREVIEW',
							'message'      => sprintf(
								/* translators: %s: elapsed time */
								__( '[PREVIEW] Order exceeds timeout (%s). In Live Mode this order would be cancelled & stock restored. Store data unmodified.', 'sazcancel-auto-cancel-on-hold-orders' ),
								$elapsed_str
							),
						)
					);
					$count++;
				}
			}
		}

		return $count;
	}

	/**
	 * Format elapsed seconds into human readable string.
	 *
	 * @param int $seconds Seconds.
	 * @return string
	 */
	public function format_elapsed_time( $seconds ) {
		if ( $seconds < 3600 ) {
			$minutes = max( 1, round( $seconds / 60 ) );
			return $minutes . 'm';
		}

		$days  = floor( $seconds / DAY_IN_SECONDS );
		$hours = floor( ( $seconds % DAY_IN_SECONDS ) / HOUR_IN_SECONDS );

		if ( $days > 0 ) {
			return sprintf( '%dd %dh', $days, $hours );
		}

		return sprintf( '%dh', $hours );
	}
}
