=== SazCancel – Auto-Cancel On-Hold Orders ===
Contributors: alexsazonov
Tags: cancel-orders, on-hold-orders, auto-cancel, stock-management, woocommerce
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 11.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically cancel abandoned On-Hold orders (BACS, check, offline invoices) under merchant-defined rules to release stuck inventory.

== Description ==

Tired of abandoned **On-Hold** orders indefinitely blocking your product inventory?

In WooCommerce Core, the built-in *Hold stock (minutes)* setting **only applies to "Pending payment" orders**. When customers order via **Direct Bank Transfer (BACS)**, **Cheque**, or offline invoices, the order is placed in **On-Hold** status and stock is deducted from your shelves. If the customer never pays, the order sits in your store forever — keeping products in a false "Out of Stock" state and costing you sales.

**SazCancel** solves this exact gap. It safely and automatically cancels stale On-Hold orders after your chosen delay (e.g., 48 hours or 3 days), allowing WooCommerce Core to **natively restock your products**.

### 🛡️ Built for Merchant Safety (Zero-Disaster Guard)
SazCancel is built on strict safeguards to protect merchant orders and store inventory:

* **Simulation Mode (Dry Run) Enabled by Default:** Upon installation, Dry Run is ON. SazCancel simulates the process, calculating how many orders and stock units would be released, recording events into an Activity Log without modifying real orders.
* **Eligible Gateways Whitelist:** You decide which payment methods are subject to auto-cancellation (e.g. BACS and Cheque). Orders from PayPal, Stripe, COD, or other gateways are **never touched**.
* **Precise On-Hold Age Tracking:** SazCancel measures order age strictly from the exact moment the order entered `On-Hold` status (not from creation date). If a manager temporarily toggled an order to On-Hold 10 minutes ago, it won't be prematurely cancelled!
* **Last-Moment Status Revalidation:** Before executing cancellation, SazCancel revalidates the order in real time. If the order was paid or moved to `Processing` or `Completed`, the job immediately exits.
* **Safe Legacy Recovery Baseline:** Old On-Hold orders placed prior to plugin installation receive a fresh, full grace period from the moment they are first detected. No sudden cancellations!
* **Native WooCommerce Restock:** SazCancel lets WooCommerce Core handle stock restoration via `$order->update_status('cancelled')`. The core `wc_maybe_increase_stock_levels()` function safely returns the exact items back to stock.
* **Action Scheduler Event Queue:** Powered by WooCommerce's native Action Scheduler with duplicate job prevention (`unique = true`). No heavy cron database scans.
* **Activity Audit Log:** See the last 30 automated events, cancellations, and simulations right on your settings screen.
* **100% HPOS Native:** Fully compatible with High-Performance Order Storage (`custom_order_tables`) and Cart/Checkout Blocks.
* **100% On-Premise PHP:** Self-contained code with zero external tracking, no third-party APIs, and no subscriptions.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/sazcancel-auto-cancel-on-hold-orders` directory, or install through the WordPress plugins screen directly.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Go to **WooCommerce > SazCancel** to review your settings.
4. Select your eligible payment gateways (e.g., BACS), set your cancellation delay (e.g., 72 hours), and test via Simulation (Dry Run) mode.
5. When ready, click **Activate Live Mode**.

== Frequently Asked Questions ==

= Does SazCancel cancel orders immediately after installation? =
No. SazCancel activates in **Dry Run (Simulation Mode)** by default. It analyzes your store and shows you a live preview of which orders would be affected, without changing any order statuses or inventory. You can switch to Live Mode whenever you are ready.

= Does WooCommerce automatically restore product stock when an order is cancelled? =
Yes! When SazCancel transitions an eligible order to `Cancelled`, WooCommerce Core natively triggers `wc_maybe_increase_stock_levels()`. Any inventory previously deducted for that order is automatically added back to your active stock.

= What if a customer pays by bank transfer right before the timeout? =
If an admin or payment webhook marks the order as `Processing` or `Completed`, SazCancel's **Last-Moment Status Revalidation** will see that the order is no longer `On-Hold` and will instantly exit without making any changes.

= Can I exclude Cash on Delivery (COD) or specific gateways? =
Yes. SazCancel includes a payment gateway whitelist. Only the payment gateways you check (e.g., Direct Bank Transfer BACS) will be monitored. All unselected gateways are completely ignored.

= Does SazCancel support High-Performance Order Storage (HPOS)? =
Yes. SazCancel is 100% compatible with HPOS (`custom_order_tables`) and WooCommerce Blocks.

== Screenshots ==

1. SazCancel Live HUD Dashboard in Simulation Mode showing eligible On-Hold orders and locked stock.
2. Activity Audit Log showing safe Read-Only Preview Check with safe legacy baseline detection.
3. Native WooCommerce stock restoration verification showing stock automatically restored upon cancellation.

== Changelog ==

= 1.0.0 =
* Initial public release.
* Event-Driven Action Scheduler queue with duplicate prevention (`unique = true`).
* Last-Moment Status Revalidation.
* Safe Legacy Recovery Baseline for existing orders.
* Simulation Mode (Dry Run) by default.
* Activity Audit Log in admin settings.
* Native WooCommerce stock restoration support.
* Full WooCommerce HPOS compatibility.
