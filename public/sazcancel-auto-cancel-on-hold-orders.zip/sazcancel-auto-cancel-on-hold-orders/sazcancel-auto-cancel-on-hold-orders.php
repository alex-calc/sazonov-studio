<?php
/**
 * Plugin Name:       SazCancel – Auto-Cancel On-Hold Orders
 * Description:       Automatically cancel abandoned On-Hold orders (BACS, check, offline invoices) under merchant-defined rules to release stuck inventory.
 * Version:           1.0.0
 * Author:            Sazonov Studio
 * Author URI:        https://sazonov-studio.netlify.app/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sazcancel-auto-cancel-on-hold-orders
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * WC requires at least: 8.0
 * WC tested up to:   11.2
 * Requires Plugins:  woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'SAZCANCEL_VERSION', '1.0.0' );
define( 'SAZCANCEL_FILE', __FILE__ );
define( 'SAZCANCEL_DIR', plugin_dir_path( __FILE__ ) );
define( 'SAZCANCEL_URL', plugin_dir_url( __FILE__ ) );
define( 'SAZCANCEL_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Declare HPOS and Checkout Blocks compatibility.
 */
add_action( 'before_woocommerce_init', 'sazcancel_declare_hpos_compatibility' );
function sazcancel_declare_hpos_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
}

/**
 * Ensure daily recovery sweep recurring action is scheduled via action_scheduler_init.
 * Guarantees Action Scheduler procedural APIs are fully loaded before calling.
 */
add_action( 'action_scheduler_init', 'sazcancel_ensure_scheduled_actions' );
function sazcancel_ensure_scheduled_actions() {
	if ( function_exists( 'as_has_scheduled_action' ) ) {
		if ( ! as_has_scheduled_action( 'sazcancel_daily_recovery_sweep', array(), 'sazcancel' ) ) {
			as_schedule_recurring_action(
				time() + DAY_IN_SECONDS,
				DAY_IN_SECONDS,
				'sazcancel_daily_recovery_sweep',
				array(),
				'sazcancel',
				true
			);
		}
	} elseif ( function_exists( 'as_schedule_recurring_action' ) ) {
		if ( function_exists( 'as_next_scheduled_action' ) && false === as_next_scheduled_action( 'sazcancel_daily_recovery_sweep', array(), 'sazcancel' ) ) {
			as_schedule_recurring_action(
				time() + DAY_IN_SECONDS,
				DAY_IN_SECONDS,
				'sazcancel_daily_recovery_sweep',
				array(),
				'sazcancel',
				true
			);
		}
	}
}

/**
 * Plugin deactivation hook: clear ALL actions in the 'sazcancel' group.
 * Ensures zero pending actions remain when plugin is inactive.
 */
register_deactivation_hook( __FILE__, 'sazcancel_deactivate_plugin' );
function sazcancel_deactivate_plugin() {
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( '', array(), 'sazcancel' );
	}
}

/**
 * Check WooCommerce dependency and initialize plugin.
 */
add_action( 'plugins_loaded', 'sazcancel_init_plugin' );
function sazcancel_init_plugin() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'sazcancel_missing_woocommerce_notice' );
		return;
	}

	require_once SAZCANCEL_DIR . 'includes/class-sazcancel-engine.php';
	require_once SAZCANCEL_DIR . 'includes/class-sazcancel-admin.php';

	SazCancel_Engine::instance();
	SazCancel_Admin::instance();
}

/**
 * Admin notice if WooCommerce is not active.
 */
function sazcancel_missing_woocommerce_notice() {
	?>
	<div class="notice notice-error">
		<p><?php esc_html_e( 'SazCancel requires WooCommerce to be installed and active.', 'sazcancel-auto-cancel-on-hold-orders' ); ?></p>
	</div>
	<?php
}

/**
 * Add settings shortcut link to Plugins list.
 */
add_filter( 'plugin_action_links_' . SAZCANCEL_BASENAME, 'sazcancel_add_settings_link' );
function sazcancel_add_settings_link( $links ) {
	$settings_url = admin_url( 'admin.php?page=sazcancel-settings' );
	$settings_link = '<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'sazcancel-auto-cancel-on-hold-orders' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
