<?php
/**
 * SazCancel Uninstall
 *
 * Cleans up options and Action Scheduler jobs upon plugin deletion.
 *
 * @package SazCancel
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Clean up stored settings and activity log.
delete_option( 'sazcancel_enabled' );
delete_option( 'sazcancel_dry_run' );
delete_option( 'sazcancel_delay_value' );
delete_option( 'sazcancel_delay_unit' );
delete_option( 'sazcancel_eligible_gateways' );
delete_option( 'sazcancel_note' );
delete_option( 'sazcancel_activity_log' );
delete_option( 'sazcancel_sweep_cursor_id' );
delete_option( 'sazcancel_schedule_version' );
delete_option( 'sazcancel_sync_delay_error' );
delete_option( 'sazcancel_failed_congested_retries' );

global $wpdb;
$sazcancel_like_pattern = $wpdb->esc_like( 'sazcancel_rf_' ) . '%';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$sazcancel_like_pattern
	)
);

// Unschedule ALL pending Action Scheduler jobs in the 'sazcancel' group.
// Empty hook string '' with group 'sazcancel' purges all jobs in the group.
if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( '', array(), 'sazcancel' );
}
