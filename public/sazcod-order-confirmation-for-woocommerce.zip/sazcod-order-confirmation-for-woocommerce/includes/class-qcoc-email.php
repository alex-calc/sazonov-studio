<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QCOC_Email {

	private static $rendered_orders = [];

	public static function init() {
		// Scoped email action: customer order details block
		add_action( 'woocommerce_email_order_details', [ __CLASS__, 'add_confirmation_link' ], 15, 4 );

		// Plain text email hook with 4 arguments (order, sent_to_admin, plain_text, email)
		add_action( 'woocommerce_email_order_meta', [ __CLASS__, 'add_plain_text_confirmation_link' ], 15, 4 );

		// Classic Checkout Thank You page hook
		add_action( 'woocommerce_thankyou_cod', [ __CLASS__, 'render_thankyou_card' ], 10, 1 );

		// Status transition notification hook
		add_action( 'woocommerce_order_status_pending_to_awaiting-confirm_notification', [ __CLASS__, 'trigger_customer_notification' ], 10, 2 );
	}

	public static function trigger_customer_notification( $order_id, $order = false ) {
		if ( ! $order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order || ! QCOC_Status::is_eligible( $order ) ) {
			return;
		}
		if ( function_exists( 'WC' ) && WC()->mailer() ) {
			$emails = WC()->mailer()->get_emails();
			if ( isset( $emails['WC_Email_Customer_On_Hold_Order'] ) ) {
				$emails['WC_Email_Customer_On_Hold_Order']->trigger( $order_id, $order );
			}
		}
	}

	public static function add_confirmation_link( $order, $sent_to_admin, $plain_text, $email ) {
		if ( $sent_to_admin || $plain_text ) {
			return;
		}

		if ( ! is_object( $email ) || ! isset( $email->id ) ) {
			return;
		}

		// Whitelist customer order emails to prevent confirmation leaks into unrelated notifications
		$allowed_emails = apply_filters( 'qcoc_allowed_email_notifications', [
			'customer_on_hold_order',
			'customer_processing_order',
			'customer_invoice',
		] );

		if ( ! in_array( $email->id, $allowed_emails, true ) ) {
			return;
		}

		if ( ! $order instanceof WC_Order || 'awaiting-confirm' !== $order->get_status() ) {
			return;
		}

		// Prevent double-rendering within the same request
		$order_id = $order->get_id();
		if ( isset( self::$rendered_orders[ $order_id ] ) ) {
			return;
		}

		$confirm_url = QCOC_Token::get_confirmation_url( $order_id );
		if ( empty( $confirm_url ) ) {
			return;
		}

		self::$rendered_orders[ $order_id ] = true;

		?>
		<div style="margin: 24px 0; padding: 20px; background-color: #fdf8e2; border: 2px dashed #e0a800; border-radius: 6px; text-align: center;">
			<h3 style="margin-top: 0; color: #856404; font-size: 17px; font-weight: 600;">
				<?php esc_html_e( 'Action Required: Please Confirm Your Order', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</h3>
			<p style="color: #664d03; font-size: 14px; line-height: 1.5; margin: 10px 0 16px;">
				<?php esc_html_e( 'You selected Cash on Delivery. To begin packaging and reserve your items, please click the button below to confirm your order.', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</p>
			<a href="<?php echo esc_url( $confirm_url ); ?>"
			   target="_blank"
			   rel="noopener noreferrer"
			   style="display: inline-block; padding: 12px 28px; background-color: #28a745; color: #ffffff; text-decoration: none; font-weight: bold; border-radius: 4px; font-size: 15px;">
				<?php esc_html_e( 'Confirm Cash on Delivery Order', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</a>
			<p style="color: #856404; font-size: 12px; margin: 12px 0 0;">
				<?php esc_html_e( 'If you did not place this order, please ignore this email.', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</p>
		</div>
		<?php
	}

	public static function add_plain_text_confirmation_link( $order, $sent_to_admin, $plain_text, $email = null ) {
		if ( $sent_to_admin || ! $plain_text ) {
			return;
		}

		// Scope plain-text emails using the exact same allowed email ID whitelist
		if ( is_object( $email ) && isset( $email->id ) ) {
			$allowed_emails = apply_filters( 'qcoc_allowed_email_notifications', [
				'customer_on_hold_order',
				'customer_processing_order',
				'customer_invoice',
			] );

			if ( ! in_array( $email->id, $allowed_emails, true ) ) {
				return;
			}
		}

		if ( ! $order instanceof WC_Order || 'awaiting-confirm' !== $order->get_status() ) {
			return;
		}

		$order_id = $order->get_id();
		if ( isset( self::$rendered_orders[ 'pt_' . $order_id ] ) ) {
			return;
		}

		$confirm_url = QCOC_Token::get_confirmation_url( $order_id );
		if ( empty( $confirm_url ) ) {
			return;
		}

		self::$rendered_orders[ 'pt_' . $order_id ] = true;

		echo "\n" . esc_html__( '--- ACTION REQUIRED: CONFIRM YOUR ORDER ---', 'sazcod-order-confirmation-for-woocommerce' ) . "\n";
		echo esc_html__( 'Please confirm your cash-on-delivery order using the secure link below:', 'sazcod-order-confirmation-for-woocommerce' ) . "\n";
		echo esc_url_raw( $confirm_url ) . "\n\n";
	}

	public static function render_thankyou_card( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || 'awaiting-confirm' !== $order->get_status() ) {
			return;
		}

		$confirm_url = QCOC_Token::get_confirmation_url( $order_id );
		if ( empty( $confirm_url ) ) {
			return;
		}

		?>
		<div class="woocommerce-notice woocommerce-notice--info woocommerce-info" style="background-color: #fdf8e2; border-color: #e0a800; color: #856404; padding: 20px; border-radius: 6px; margin: 20px 0; text-align: center;">
			<h3 style="margin-top: 0; color: #856404;">
				<?php esc_html_e( 'Action Required: Cash on Delivery Confirmation', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</h3>
			<p style="margin: 10px 0 16px; font-size: 15px;">
				<?php esc_html_e( 'Your order is currently awaiting confirmation. To begin fulfillment, please verify your order by clicking below.', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</p>
			<a href="<?php echo esc_url( $confirm_url ); ?>"
			   style="display: inline-block; background: #28a745; color: #ffffff; padding: 12px 28px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 15px;">
				<?php esc_html_e( 'Confirm Order Now', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</a>
		</div>
		<?php
	}
}
