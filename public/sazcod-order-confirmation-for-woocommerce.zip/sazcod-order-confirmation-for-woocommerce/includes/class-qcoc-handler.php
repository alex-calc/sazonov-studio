<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QCOC_Handler {

	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'handle_request' ] );
	}

	public static function handle_request() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action = isset( $_REQUEST['qcoc_action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['qcoc_action'] ) ) : '';
		if ( empty( $action ) ) {
			return;
		}

		// Enforce anti-cache and strict security headers
		self::send_security_headers();

		// Apply IP rate limiting
		if ( ! self::check_rate_limit() ) {
			wp_die(
				esc_html__( 'Too many confirmation attempts. Please try again in a few minutes.', 'sazcod-order-confirmation-for-woocommerce' ),
				esc_html__( 'Rate Limit Exceeded', 'sazcod-order-confirmation-for-woocommerce' ),
				[ 'response' => 429 ]
			);
		}

		switch ( $action ) {
			case 'confirm':
				self::handle_preview_screen();
				break;

			case 'process_confirm':
				self::handle_process_confirmation();
				break;

			case 'confirmed':
				self::handle_result_screen();
				break;
		}
	}

	private static function send_security_headers() {
		nocache_headers();
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( "Content-Security-Policy: default-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'self'; form-action 'self';" );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: no-referrer' );
	}

	private static function check_rate_limit() {
		$ip          = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1' ) );
		$transient   = 'qcoc_rl_' . md5( $ip );
		$attempts    = (int) get_transient( $transient );

		if ( $attempts >= 60 ) {
			return false;
		}

		set_transient( $transient, $attempts + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}

	private static function handle_preview_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token    = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';

		if ( empty( $order_id ) || empty( $token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			self::render_notice_screen( __( 'Invalid or expired confirmation link.', 'sazcod-order-confirmation-for-woocommerce' ) );
			exit;
		}

		$result = QCOC_Token::verify_token( $order_id, $token );
		if ( ! $result['valid'] ) {
			if ( 'already_used' === $result['code'] ) {
				self::render_notice_screen( __( 'This order has already been confirmed earlier. Thank you!', 'sazcod-order-confirmation-for-woocommerce' ) );
			} else {
				self::render_notice_screen( __( 'Invalid or expired confirmation link.', 'sazcod-order-confirmation-for-woocommerce' ) );
			}
			exit;
		}

		$order = $result['order'];
		require QCOC_PLUGIN_PATH . 'templates/confirmation-screen.php';
		exit;
	}

	private static function handle_process_confirmation() {
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
		if ( 'POST' !== $method ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';

		if ( empty( $order_id ) || empty( $token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			self::render_notice_screen( __( 'Invalid or expired confirmation link.', 'sazcod-order-confirmation-for-woocommerce' ) );
			exit;
		}

		$nonce = isset( $_POST['qcoc_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['qcoc_nonce'] ) ) : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'qcoc_confirm_' . $order_id ) ) {
			self::render_notice_screen( __( 'Your confirmation session has expired. Please refresh the page and try again.', 'sazcod-order-confirmation-for-woocommerce' ) );
			exit;
		}

		$result = QCOC_Token::verify_token( $order_id, $token );
		if ( ! $result['valid'] ) {
			if ( 'already_used' === $result['code'] ) {
				self::render_notice_screen( __( 'This order has already been confirmed earlier. Thank you!', 'sazcod-order-confirmation-for-woocommerce' ) );
			} else {
				self::render_notice_screen( __( 'Invalid or expired confirmation link.', 'sazcod-order-confirmation-for-woocommerce' ) );
			}
			exit;
		}

		$commit = QCOC_Token::confirm_order( $order_id, $token );
		if ( ! $commit['success'] ) {
			if ( 'already_used' === ( $commit['code'] ?? '' ) ) {
				self::render_notice_screen( __( 'This order has already been confirmed earlier. Thank you!', 'sazcod-order-confirmation-for-woocommerce' ) );
			} else {
				self::render_notice_screen( __( 'Unable to confirm order at this time. Please contact store support.', 'sazcod-order-confirmation-for-woocommerce' ) );
			}
			exit;
		}

		// Anti-Oracle PRG: Generate single-use opaque result token (no order_id in URL)
		try {
			$result_token = bin2hex( random_bytes( 16 ) );
		} catch ( Throwable $e ) {
			$result_token = wp_generate_password( 32, false, false );
		}

		set_transient( 'qcoc_res_' . $result_token, [
			'status'   => 'confirmed',
			'order_id' => $order_id,
			'time'     => time(),
		], 120 ); // 2-minute transient lifetime

		wp_safe_redirect( add_query_arg( [
			'qcoc_action'  => 'confirmed',
			'result_token' => $result_token,
		], home_url( '/' ) ) );
		exit;
	}

	private static function handle_result_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$result_token = isset( $_GET['result_token'] ) ? sanitize_text_field( wp_unslash( $_GET['result_token'] ) ) : '';
		if ( empty( $result_token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $result_token ) ) {
			self::render_notice_screen( __( 'Invalid or expired confirmation link.', 'sazcod-order-confirmation-for-woocommerce' ) );
			exit;
		}

		$result_data = get_transient( 'qcoc_res_' . $result_token );
		if ( false === $result_data || ! is_array( $result_data ) ) {
			// Single-use token already consumed or expired
			self::render_notice_screen( __( 'Your order confirmation has already been recorded. Thank you!', 'sazcod-order-confirmation-for-woocommerce' ) );
			exit;
		}

		// Consume token immediately (prevents reuse or enumeration)
		delete_transient( 'qcoc_res_' . $result_token );

		$order_id = absint( $result_data['order_id'] ?? 0 );
		$order    = wc_get_order( $order_id );

		$order_number = $order ? $order->get_order_number() : '#' . $order_id;
		self::render_notice_screen(
			sprintf(
				/* translators: %s: order number */
				__( 'Order %s has been successfully confirmed! Our team is preparing your package for shipment.', 'sazcod-order-confirmation-for-woocommerce' ),
				'<strong>' . esc_html( $order_number ) . '</strong>'
			),
			__( 'Order Confirmed!', 'sazcod-order-confirmation-for-woocommerce' ),
			true
		);
		exit;
	}

	public static function render_notice_screen( $message, $title = '', $is_success = false ) {
		if ( empty( $title ) ) {
			$title = $is_success ? __( 'Confirmation Successful', 'sazcod-order-confirmation-for-woocommerce' ) : __( 'Order Confirmation', 'sazcod-order-confirmation-for-woocommerce' );
		}
		$card_class = $is_success ? 'qcoc-card success' : 'qcoc-card error';
		wp_enqueue_style( 'sazcod-confirmation', QCOC_PLUGIN_URL . 'assets/css/confirmation.css', [], QCOC_VERSION );
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title><?php echo esc_html( $title ); ?></title>
			<?php wp_print_styles( [ 'sazcod-confirmation' ] ); ?>
		</head>
		<body>
			<div class="<?php echo esc_attr( $card_class ); ?>">
				<h1><?php echo esc_html( $title ); ?></h1>
				<p><?php echo wp_kses_post( $message ); ?></p>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-home">
					<?php esc_html_e( 'Return to Shop', 'sazcod-order-confirmation-for-woocommerce' ); ?>
				</a>
			</div>
		</body>
		</html>
		<?php
	}
}
