<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QCOC_Status {

	const STATUS_SLUG = 'wc-awaiting-confirm';

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_order_status' ] );
		add_filter( 'wc_order_statuses', [ __CLASS__, 'add_order_statuses' ] );
		add_filter( 'woocommerce_reports_order_statuses', [ __CLASS__, 'exclude_from_reports' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'admin_badge_styles' ] );

		// Classic Checkout hook
		add_action( 'woocommerce_checkout_order_processed', [ __CLASS__, 'intercept_cod_order' ], 20, 3 );

		// WooCommerce Store API / Checkout Block hook
		add_action( 'woocommerce_store_api_checkout_order_processed', [ __CLASS__, 'intercept_store_api_cod_order' ], 20, 1 );
	}

	public static function register_order_status() {
		register_post_status( self::STATUS_SLUG, [
			'label'                     => _x( 'Awaiting Confirmation', 'Order status', 'sazcod-order-confirmation-for-woocommerce' ),
			'public'                    => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: number of orders */
			'label_count'               => _n_noop( 'Awaiting Confirmation <span class="count">(%s)</span>', 'Awaiting Confirmation <span class="count">(%s)</span>', 'sazcod-order-confirmation-for-woocommerce' ),
		] );
	}

	public static function add_order_statuses( $statuses ) {
		$new_statuses = [];
		foreach ( $statuses as $key => $label ) {
			$new_statuses[ $key ] = $label;
			if ( 'wc-pending' === $key ) {
				$new_statuses[ self::STATUS_SLUG ] = _x( 'Awaiting Confirmation', 'Order status', 'sazcod-order-confirmation-for-woocommerce' );
			}
		}
		if ( ! isset( $new_statuses[ self::STATUS_SLUG ] ) ) {
			$new_statuses[ self::STATUS_SLUG ] = _x( 'Awaiting Confirmation', 'Order status', 'sazcod-order-confirmation-for-woocommerce' );
		}
		return $new_statuses;
	}

	public static function exclude_from_reports( $statuses ) {
		return array_diff( $statuses, [ 'awaiting-confirm' ] );
	}

	public static function admin_badge_styles() {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, [ 'shop_order', 'woocommerce_page_wc-orders' ], true ) ) {
			return;
		}
		wp_enqueue_style( 'sazcod-admin', QCOC_PLUGIN_URL . 'assets/css/admin.css', [], QCOC_VERSION );
	}

	public static function intercept_cod_order( $order_id, $posted_data, $order ) {
		self::process_interception( $order );
	}

	public static function intercept_store_api_cod_order( $order ) {
		self::process_interception( $order );
	}

	private static function process_interception( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! self::is_eligible( $order ) ) {
			return;
		}

		$order->update_status(
			'awaiting-confirm',
			__( 'COD order placed in Awaiting Confirmation. Customer must verify via confirmation link.', 'sazcod-order-confirmation-for-woocommerce' )
		);

		// Pre-generate secure token and store encrypted payload
		$token = QCOC_Token::get_or_create_token( $order->get_id() );
		if ( empty( $token ) ) {
			$order->add_order_note( __( 'Quick COD Warning: Failed to generate secure confirmation token. Please verify this order manually.', 'sazcod-order-confirmation-for-woocommerce' ) );
			$order->save();
		}
	}

	public static function is_eligible( $order ) {
		if ( 'cod' !== $order->get_payment_method() ) {
			return false;
		}

		// Only intercept orders that require physical shipping
		$has_physical = false;
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( $product && $product->needs_shipping() ) {
				$has_physical = true;
				break;
			}
		}

		return $has_physical;
	}
}
