<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security Architecture & Threat Model Notes:
 *
 * This plugin employs a dual-layer security model:
 * 1. Fast, non-reversible authentication via SHA-256 hash (_qcoc_token_hash).
 *    Incoming tokens from customer clicks are hashed and compared with constant-time hash_equals().
 * 2. Reversible encryption at rest via AEAD AES-256-GCM (_qcoc_token_enc) bound to AAD v1:{order_id}.
 *    This allows the Thank You page and background email queues (Action Scheduler) to reconstruct
 *    the customer confirmation link without requiring the raw token to be stored in plaintext.
 *    The encryption key is derived from wp_salt('auth'). If the database is compromised, tokens
 *    cannot be decrypted without the server-side salt.
 */
class QCOC_Token {

	const TOKEN_TTL = 172800; // 48 hours in seconds

	public static function init() {
	}

	public static function get_or_create_token( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return '';
		}

		// Check if active hash and encrypted payload already exist
		$existing_hash = $order->get_meta( '_qcoc_token_hash' );
		$created_at    = (int) $order->get_meta( '_qcoc_token_created_at' );

		if ( 'revoked' === $existing_hash ) {
			return '';
		}

		$age = time() - $created_at;
		if ( ! empty( $existing_hash ) && $created_at > 0 && $age >= 0 && $age <= self::TOKEN_TTL ) {
			$encrypted_payload = $order->get_meta( '_qcoc_token_enc' );
			if ( ! empty( $encrypted_payload ) ) {
				$decrypted = self::decrypt_token( $encrypted_payload, $order_id );
				if ( false !== $decrypted && hash_equals( $existing_hash, hash( 'sha256', $decrypted ) ) ) {
					return $decrypted;
				}
			}
			// Encrypted payload unreadable or corrupted; fail-closed
			return '';
		}

		// Fail-closed: if an expired or revoked hash exists, do not silently regenerate
		if ( ! empty( $existing_hash ) ) {
			return '';
		}

		// Generate new high-entropy bearer token (16 bytes = 32 hex chars)
		try {
			$token = bin2hex( random_bytes( 16 ) );
		} catch ( Throwable $e ) {
			return '';
		}

		$hash      = hash( 'sha256', $token );
		$encrypted = self::encrypt_token( $token, $order_id );

		if ( false === $encrypted ) {
			return '';
		}

		$order->update_meta_data( '_qcoc_token_hash', $hash );
		$order->update_meta_data( '_qcoc_token_enc', $encrypted );
		$order->update_meta_data( '_qcoc_token_created_at', time() );
		$order->save();

		return $token;
	}

	private static function get_encryption_key() {
		$salt = wp_salt( 'auth' );
		return hash_hkdf( 'sha256', $salt, 32, 'qcoc_token_encryption_key' );
	}

	private static function encrypt_token( $plaintext, $order_id ) {
		$key = self::get_encryption_key();

		if ( in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true ) ) {
			try {
				$iv = random_bytes( 12 );
			} catch ( Throwable $e ) {
				return false;
			}
			$tag = '';
			$aad = 'v1:' . (int) $order_id;

			$ciphertext = openssl_encrypt(
				$plaintext,
				'aes-256-gcm',
				$key,
				OPENSSL_RAW_DATA,
				$iv,
				$tag,
				$aad,
				16
			);

			if ( false === $ciphertext ) {
				return false;
			}

			return json_encode( [
				'v'  => 1,
				'c'  => 'aes-256-gcm',
				'iv' => base64_encode( $iv ),
				'tg' => base64_encode( $tag ),
				'ct' => base64_encode( $ciphertext ),
			] );
		}

		// Fallback: AES-256-CBC with Encrypt-then-MAC (HMAC-SHA256)
		try {
			$iv = random_bytes( 16 );
		} catch ( Throwable $e ) {
			return false;
		}
		$enc_key = hash_hkdf( 'sha256', $key, 32, 'qcoc_cbc_enc' );
		$mac_key = hash_hkdf( 'sha256', $key, 32, 'qcoc_cbc_mac' );

		$ciphertext = openssl_encrypt(
			$plaintext,
			'aes-256-cbc',
			$enc_key,
			OPENSSL_RAW_DATA,
			$iv
		);

		if ( false === $ciphertext ) {
			return false;
		}

		$aad = 'v1:' . (int) $order_id;
		$mac = hash_hmac( 'sha256', $aad . $iv . $ciphertext, $mac_key, true );

		return json_encode( [
			'v'  => 1,
			'c'  => 'aes-256-cbc-hmac',
			'iv' => base64_encode( $iv ),
			'mc' => base64_encode( $mac ),
			'ct' => base64_encode( $ciphertext ),
		] );
	}

	private static function decrypt_token( $json_payload, $order_id ) {
		$data = json_decode( $json_payload, true );
		if ( ! is_array( $data ) || empty( $data['v'] ) || 1 !== (int) $data['v'] || empty( $data['c'] ) || empty( $data['iv'] ) || empty( $data['ct'] ) ) {
			return false;
		}

		$key = self::get_encryption_key();
		$iv  = base64_decode( $data['iv'], true );
		$ct  = base64_decode( $data['ct'], true );

		if ( false === $iv || false === $ct ) {
			return false;
		}

		$aad = 'v1:' . (int) $order_id;

		if ( 'aes-256-gcm' === $data['c'] ) {
			if ( empty( $data['tg'] ) ) {
				return false;
			}
			$tag = base64_decode( $data['tg'], true );
			if ( false === $tag || strlen( $tag ) !== 16 || strlen( $iv ) !== 12 ) {
				return false;
			}

			$decrypted = openssl_decrypt(
				$ct,
				'aes-256-gcm',
				$key,
				OPENSSL_RAW_DATA,
				$iv,
				$tag,
				$aad
			);

			return false !== $decrypted ? $decrypted : false;
		}

		if ( 'aes-256-cbc-hmac' === $data['c'] ) {
			if ( empty( $data['mc'] ) || strlen( $iv ) !== 16 ) {
				return false;
			}
			$mac     = base64_decode( $data['mc'], true );
			$enc_key = hash_hkdf( 'sha256', $key, 32, 'qcoc_cbc_enc' );
			$mac_key = hash_hkdf( 'sha256', $key, 32, 'qcoc_cbc_mac' );

			$expected_mac = hash_hmac( 'sha256', $aad . $iv . $ct, $mac_key, true );
			if ( false === $mac || ! hash_equals( $expected_mac, $mac ) ) {
				return false;
			}

			$decrypted = openssl_decrypt(
				$ct,
				'aes-256-cbc',
				$enc_key,
				OPENSSL_RAW_DATA,
				$iv
			);

			return false !== $decrypted ? $decrypted : false;
		}

		return false;
	}

	public static function verify_token( $order_id, $candidate_token ) {
		if ( ! is_numeric( $order_id ) || empty( $candidate_token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $candidate_token ) ) {
			return [ 'valid' => false, 'code' => 'malformed' ];
		}

		$order = wc_get_order( (int) $order_id );
		if ( ! $order ) {
			return [ 'valid' => false, 'code' => 'not_found' ];
		}

		$stored_hash = $order->get_meta( '_qcoc_token_hash' );
		$created_at  = (int) $order->get_meta( '_qcoc_token_created_at' );

		if ( 'revoked' === $stored_hash ) {
			return [ 'valid' => false, 'code' => 'already_used', 'order' => $order ];
		}

		if ( empty( $stored_hash ) || empty( $created_at ) ) {
			return [ 'valid' => false, 'code' => 'no_token' ];
		}

		$age = time() - $created_at;
		if ( $created_at <= 0 || $age < 0 || $age > self::TOKEN_TTL ) {
			return [ 'valid' => false, 'code' => 'expired' ];
		}

		$candidate_hash = hash( 'sha256', $candidate_token );
		if ( ! hash_equals( $stored_hash, $candidate_hash ) ) {
			return [ 'valid' => false, 'code' => 'mismatch' ];
		}

		if ( 'cod' !== $order->get_payment_method() ) {
			return [ 'valid' => false, 'code' => 'not_cod' ];
		}

		if ( 'awaiting-confirm' !== $order->get_status() ) {
			return [ 'valid' => false, 'code' => 'invalid_status' ];
		}

		return [ 'valid' => true, 'order' => $order ];
	}

	public static function confirm_order( $order_id, $token = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return [ 'success' => false, 'code' => 'invalid_order' ];
		}

		// Guard 1: Verify payment method is still COD
		if ( 'cod' !== $order->get_payment_method() ) {
			return [ 'success' => false, 'code' => 'invalid_payment_method' ];
		}

		// Guard 2: Verify order status is still awaiting-confirm
		if ( 'awaiting-confirm' !== $order->get_status() ) {
			return [ 'success' => false, 'code' => 'invalid_status' ];
		}

		// Guard 3: Verify token hash matches active meta and has not been revoked
		$stored_hash = $order->get_meta( '_qcoc_token_hash' );
		if ( empty( $stored_hash ) || 'revoked' === $stored_hash ) {
			return [ 'success' => false, 'code' => 'already_used' ];
		}

		if ( ! empty( $token ) ) {
			$candidate_hash = hash( 'sha256', $token );
			if ( ! hash_equals( $stored_hash, $candidate_hash ) ) {
				return [ 'success' => false, 'code' => 'invalid_token' ];
			}
		}

		// Guard 4: Verify TTL has not expired
		$created_at = (int) $order->get_meta( '_qcoc_token_created_at' );
		$age        = time() - $created_at;
		if ( $created_at <= 0 || $age < 0 || $age > self::TOKEN_TTL ) {
			return [ 'success' => false, 'code' => 'expired' ];
		}

		// Invalidate token immediately to prevent reuse
		$order->update_meta_data( '_qcoc_token_hash', 'revoked' );
		$order->delete_meta_data( '_qcoc_token_enc' );
		$order->update_meta_data( '_qcoc_confirmed_at', current_time( 'mysql' ) );

		$order->update_status(
			'processing',
			__( 'COD order confirmed by customer via secure confirmation link.', 'sazcod-order-confirmation-for-woocommerce' )
		);
		$order->save();

		return [ 'success' => true ];
	}

	public static function get_confirmation_url( $order_id ) {
		$token = self::get_or_create_token( $order_id );
		if ( empty( $token ) ) {
			return '';
		}

		return add_query_arg( [
			'qcoc_action' => 'confirm',
			'order_id'    => (int) $order_id,
			'token'       => $token,
		], home_url( '/' ) );
	}
}
