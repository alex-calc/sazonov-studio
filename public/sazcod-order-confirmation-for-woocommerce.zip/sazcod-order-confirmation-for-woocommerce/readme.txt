=== SazCOD – COD Order Confirmation for WooCommerce ===
Contributors: alexsazonov
Tags: woocommerce, cash on delivery, cod, order confirmation, fake order protection
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 11.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Reduce fake Cash on Delivery orders. Holds COD orders in Awaiting Confirmation until the buyer verifies via a secure 1-click confirmation link.

== Description ==

Cash on Delivery (COD) is essential for e-commerce growth in many regions, but fraudulent orders, impulsive checkouts, and wrong delivery addresses cost merchants substantial fulfillment and return shipping fees.

**SazCOD – COD Order Confirmation for WooCommerce** is a lightweight, 100% self-hosted plugin that automatically intercepts COD orders containing physical goods and places them into a custom status: **Awaiting Confirmation**.

The buyer receives an actionable confirmation block in their order email. Clicking the link takes the customer to a secure verification screen where they explicitly confirm their order. Once confirmed, the order instantly transitions to **Processing** so your warehouse can safely begin packing.

### Key Features

* **Zero External Dependencies**: 100% self-hosted. No external APIs, SMS gateways, or recurring subscriptions.
* **WooCommerce HPOS Compatible**: Fully compatible with High-Performance Order Storage (`custom_order_tables`).
* **Block Checkout & Classic Checkout Support**: Intercepts COD orders across both WooCommerce Checkout Block (Store API) and classic shortcode checkouts.
* **Smart Physical Goods Detection**: Only intercepts orders requiring physical shipping; virtual and digital orders pass through normally.
* **Hardened Token Security Architecture**:
  * Cryptographically random, SHA-256 hashed tokens bound to the unique order.
  * Encrypted at rest using AEAD AES-256-GCM with order-bound additional authenticated data (`v1:{order_id}`).
  * Strict anti-cache headers (`Cache-Control: no-store, no-cache`) to prevent intermediate caching of confirmation screens.
  * Synchronized 48-hour WordPress nonce lifetime matching the token TTL.
  * Pre-commit business guards verifying COD payment method, awaiting-confirm status, and token hash.
  * Sequential token revocation and native WooCommerce order state machine transitions to eliminate double-confirmation races.
  * Post/Redirect/Get (PRG) flow with single-use opaque result tokens to eliminate order status enumeration.
  * Strict Content Security Policy (`default-src 'none'`), Referrer-Policy, and anti-tampering checks.
* **Responsive, Clean UI**: Mobile-friendly confirmation screen rendered using native styles without heavy frontend libraries.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/sazcod-order-confirmation-for-woocommerce` directory, or install the plugin directly through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Ensure Cash on Delivery (COD) is enabled in **WooCommerce > Settings > Payments**.
4. Test with a physical product checkout using Cash on Delivery.

== Frequently Asked Questions ==

= Does this plugin require an external service or API key? =
No. The plugin is 100% self-hosted on your WordPress server. No third-party accounts, APIs, or ongoing fees are required.

= What happens to virtual or downloadable orders? =
Orders containing only virtual or downloadable items bypass the confirmation flow automatically and proceed to standard processing.

= How long is a confirmation link valid? =
By default, confirmation tokens remain valid for 48 hours.

= Does it support WooCommerce High-Performance Order Storage (HPOS)? =
Yes, HPOS compatibility is declared and fully supported.

= What happens if I rotate the WordPress security keys (AUTH_KEY / AUTH_SALT)? =
Since unconfirmed order tokens are encrypted at rest using keys derived from your WordPress secret salts, rotating AUTH_KEY or AUTH_SALT in wp-config.php will invalidate existing pending confirmation links. Newly placed orders after key rotation will work normally.

== Changelog ==

= 1.0.2 =
* Added strict anti-cache headers (`Cache-Control: no-store, no-cache, must-revalidate`) on confirmation preview and result screens.
* Registered custom order status as non-public (`public => false`, `exclude_from_search => true`).
* Implemented immediate pre-commit business guards verifying COD payment method, status, and active token hash.
* Synchronized WordPress nonce lifetime to 48 hours for confirmation actions to prevent premature session expiry.
* Scoped plain-text email confirmation links with the customer email ID whitelist.
* Added explicit operator order note when token generation fails.
* Bundled official WordPress.org screenshot assets into release archive.
* Documented dual-layer cryptographic threat model in source code.

= 1.0.1 =
* Hardened token encryption using AEAD AES-256-GCM with order-bound additional authenticated data.
* Implemented database-backed lock with owner tokens and pre-commit fencing.
* Added single-use opaque result tokens to PRG flow to prevent result status enumeration.
* Added Store API checkout interception hook for WooCommerce Checkout Block compatibility.
* Corrected physical product shipping check for mixed carts.
* Scoped customer email notifications with dedicated ID whitelist and rel="noopener noreferrer".
* Standardized clean POT localization template without fuzzy flags.

= 1.0.0 =
* Initial release.

== Screenshots ==

1. Cash on Delivery confirmation banner on the Order Received page.
2. Dedicated secure customer confirmation screen.
3. Confirmation success screen with single-use opaque result token.
4. Real-time order status transition to Processing in WooCommerce admin.
5. Chronological order audit trail in WooCommerce order notes.

== Privacy Policy ==

The plugin does not transmit customer order data to external services or third-party servers. It stores only confirmation-related metadata (`_qcoc_confirmed_at`) in the local WooCommerce order. Customer information displayed on the self-hosted confirmation screen is retrieved directly from the merchant's local WordPress database.
