<?php
/**
 * Plugin Name: SazCOD – COD Order Confirmation for WooCommerce
 * Description: Intercepts Cash on Delivery orders, places them in "Awaiting Confirmation", and lets customers confirm via a secure bearer link before warehouse dispatch.
 * Version: 1.0.2
 * Author: Sazonov Studio
 * Text Domain: sazcod-order-confirmation-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 * WC tested up to: 11.1
 * Requires Plugins: woocommerce
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QCOC_VERSION', '1.0.2' );
define( 'QCOC_PLUGIN_FILE', __FILE__ );
define( 'QCOC_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'QCOC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Declare WooCommerce High-Performance Order Storage (HPOS) compatibility
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

// Check for active WooCommerce before initialization
add_action( 'plugins_loaded', function() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function() {
			echo '<div class="error"><p>' .
				esc_html__( 'SazCOD – COD Order Confirmation for WooCommerce requires WooCommerce to be installed and active.', 'sazcod-order-confirmation-for-woocommerce' ) .
				'</p></div>';
		} );
		return;
	}

	// Synchronize WordPress Nonce lifetime with the 48-hour token TTL
	add_filter( 'nonce_life', function( $life, $action = '' ) {
		if ( is_string( $action ) && 0 === strpos( $action, 'qcoc_confirm_' ) ) {
			return 48 * HOUR_IN_SECONDS;
		}
		return $life;
	}, 10, 2 );

	// Initialize core components
	require_once QCOC_PLUGIN_PATH . 'includes/class-qcoc-status.php';
	require_once QCOC_PLUGIN_PATH . 'includes/class-qcoc-token.php';
	require_once QCOC_PLUGIN_PATH . 'includes/class-qcoc-handler.php';
	require_once QCOC_PLUGIN_PATH . 'includes/class-qcoc-email.php';

	QCOC_Status::init();
	QCOC_Token::init();
	QCOC_Handler::init();
	QCOC_Email::init();
} );
