<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
wp_enqueue_style( 'sazcod-confirmation', QCOC_PLUGIN_URL . 'assets/css/confirmation.css', [], QCOC_VERSION );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php esc_html_e( 'Confirm Cash on Delivery Order', 'sazcod-order-confirmation-for-woocommerce' ); ?></title>
	<?php wp_print_styles( [ "sazcod-confirmation" ] ); ?>
</head>
<body>
	<div class="qcoc-container">
		<h1><?php esc_html_e( 'Confirm Your Order', 'sazcod-order-confirmation-for-woocommerce' ); ?></h1>
		<p><?php esc_html_e( 'Please review your order details below and confirm that you wish to receive this delivery.', 'sazcod-order-confirmation-for-woocommerce' ); ?></p>

		<div class="order-meta">
			<div class="meta-row">
				<span class="meta-label"><?php esc_html_e( 'Order Number:', 'sazcod-order-confirmation-for-woocommerce' ); ?></span>
				<span>#<?php echo esc_html( $order->get_order_number() ); ?></span>
			</div>
			<div class="meta-row">
				<span class="meta-label"><?php esc_html_e( 'Payment Method:', 'sazcod-order-confirmation-for-woocommerce' ); ?></span>
				<span><?php echo esc_html( $order->get_payment_method_title() ); ?></span>
			</div>
			<div class="meta-row">
				<span class="meta-label"><?php esc_html_e( 'Shipping Address:', 'sazcod-order-confirmation-for-woocommerce' ); ?></span>
				<span><?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ); ?></span>
			</div>
			<div class="meta-row">
				<span class="meta-label"><?php esc_html_e( 'Total Amount:', 'sazcod-order-confirmation-for-woocommerce' ); ?></span>
				<span><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></span>
			</div>
		</div>

		<div class="items-list">
			<strong><?php esc_html_e( 'Order Items:', 'sazcod-order-confirmation-for-woocommerce' ); ?></strong>
			<?php foreach ( $order->get_items() as $qcoc_item ) : ?>
				<div class="item-line">
					<span><?php echo esc_html( $qcoc_item->get_name() ); ?> &times; <?php echo esc_html( $qcoc_item->get_quantity() ); ?></span>
					<span><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $qcoc_item ) ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="qcoc-confirmation-form" onsubmit="var b=this.querySelector('.btn-confirm');if(b)b.disabled=true;">
			<input type="hidden" name="qcoc_action" value="process_confirm">
			<input type="hidden" name="order_id" value="<?php echo esc_attr( $order->get_id() ); ?>">
			<input type="hidden" name="token" value="<?php echo esc_attr( $token ); ?>">
			<?php wp_nonce_field( 'qcoc_confirm_' . $order->get_id(), 'qcoc_nonce' ); ?>

			<button type="submit" class="btn-confirm">
				<?php esc_html_e( 'Confirm My Cash on Delivery Order', 'sazcod-order-confirmation-for-woocommerce' ); ?>
			</button>
		</form>

		<p class="notice-note">
			<?php esc_html_e( 'By clicking confirm, you verify that you placed this order and agree to pay upon receipt of delivery.', 'sazcod-order-confirmation-for-woocommerce' ); ?>
		</p>
	</div>
</body>
</html>
