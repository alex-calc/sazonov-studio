(function($) {
	'use strict';

	$(document).ready(function() {
		// Toggle password visibility
		$('.sazstock-toggle-pwd').on('click', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			var $input = $('#' + targetId);
			if ($input.attr('type') === 'password') {
				$input.attr('type', 'text');
				$(this).text('🔒');
			} else {
				$input.attr('type', 'password');
				$(this).text('👁️');
			}
		});

		// Send Test Alert
		$('#sazstock-btn-test').on('click', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $box = $('#sazstock-test-status');

			$btn.prop('disabled', true);
			$box.removeClass('sazstock-status-success sazstock-status-error')
				.addClass('sazstock-status-loading')
				.text(sazstockAdmin.strings.sending);

			$.post(sazstockAdmin.ajaxUrl, {
				action: 'sazstock_send_test',
				nonce: sazstockAdmin.nonce
			}).done(function(res) {
				$box.removeClass('sazstock-status-loading');
				if (res.success) {
					$box.addClass('sazstock-status-success').text(res.data.message || sazstockAdmin.strings.success);
				} else {
					$box.addClass('sazstock-status-error').text(res.data.message || sazstockAdmin.strings.error);
				}
			}).fail(function() {
				$box.removeClass('sazstock-status-loading')
					.addClass('sazstock-status-error')
					.text(sazstockAdmin.strings.error + ' Network Error');
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});

		// Setup Webhook
		$('#sazstock-btn-webhook').on('click', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $box = $('#sazstock-webhook-status');

			$btn.prop('disabled', true);
			$box.removeClass('sazstock-status-success sazstock-status-error')
				.addClass('sazstock-status-loading')
				.text(sazstockAdmin.strings.settingUp);

			$.post(sazstockAdmin.ajaxUrl, {
				action: 'sazstock_setup_webhook',
				nonce: sazstockAdmin.nonce
			}).done(function(res) {
				$box.removeClass('sazstock-status-loading');
				if (res.success) {
					$box.addClass('sazstock-status-success').text(res.data.message || sazstockAdmin.strings.hookOk);
					setTimeout(function() {
						window.location.reload();
					}, 1500);
				} else {
					$box.addClass('sazstock-status-error').text(res.data.message || sazstockAdmin.strings.error);
				}
			}).fail(function() {
				$box.removeClass('sazstock-status-loading')
					.addClass('sazstock-status-error')
					.text(sazstockAdmin.strings.error + ' Network Error');
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});
	});
})(jQuery);
