<?php
/**
 * Admin settings UI and AJAX management for SazStock.
 */

defined( 'ABSPATH' ) || exit;

class SazStock_Admin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// AJAX actions
		add_action( 'wp_ajax_sazstock_send_test', array( $this, 'ajax_send_test' ) );
		add_action( 'wp_ajax_sazstock_setup_webhook', array( $this, 'ajax_setup_webhook' ) );
	}

	public function add_menu_page() {
		add_submenu_page(
			'woocommerce',
			__( 'SazStock Settings', 'sazstock-stock-alerts-for-woocommerce' ),
			__( 'SazStock', 'sazstock-stock-alerts-for-woocommerce' ),
			'manage_woocommerce',
			'sazstock-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting( 'sazstock_settings_group', 'sazstock_bot_token', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );

		register_setting( 'sazstock_settings_group', 'sazstock_chat_id', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		) );

		register_setting( 'sazstock_settings_group', 'sazstock_global_threshold', array(
			'type'              => 'number',
			'sanitize_callback' => 'absint',
			'default'           => 2,
		) );
	}

	public function enqueue_assets( $hook ) {
		if ( 'woocommerce_page_sazstock-settings' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sazstock-admin-css',
			SAZSTOCK_URL . 'assets/admin.css',
			array(),
			SAZSTOCK_VERSION
		);

		wp_enqueue_script(
			'sazstock-admin-js',
			SAZSTOCK_URL . 'assets/admin.js',
			array( 'jquery' ),
			SAZSTOCK_VERSION,
			true
		);

		wp_localize_script( 'sazstock-admin-js', 'sazstockAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'sazstock_admin_nonce' ),
			'strings' => array(
				'sending'   => __( 'Sending test alert...', 'sazstock-stock-alerts-for-woocommerce' ),
				'success'   => __( 'Test alert sent! Check your Telegram.', 'sazstock-stock-alerts-for-woocommerce' ),
				'error'     => __( 'Error sending alert:', 'sazstock-stock-alerts-for-woocommerce' ),
				'settingUp' => __( 'Connecting Telegram Webhook...', 'sazstock-stock-alerts-for-woocommerce' ),
				'hookOk'    => __( 'Webhook connected successfully!', 'sazstock-stock-alerts-for-woocommerce' ),
			),
		) );
	}

	public function ajax_send_test() {
		check_ajax_referer( 'sazstock_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'sazstock-stock-alerts-for-woocommerce' ) ) );
		}

		$chat_id = SazStock_Telegram::instance()->get_chat_id();
		if ( empty( $chat_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Please save your Telegram Chat ID first.', 'sazstock-stock-alerts-for-woocommerce' ) ) );
		}

		$result = SazStock_Telegram::instance()->send_test_message( $chat_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'Test notification delivered to Telegram!', 'sazstock-stock-alerts-for-woocommerce' ) ) );
	}

	public function ajax_setup_webhook() {
		check_ajax_referer( 'sazstock_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'sazstock-stock-alerts-for-woocommerce' ) ) );
		}

		$webhook_url  = SazStock_Webhook::instance()->get_webhook_url();
		$secret_token = SazStock_Webhook::instance()->get_or_generate_secret_token();

		$result = SazStock_Telegram::instance()->set_webhook( $webhook_url, $secret_token );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		update_option( 'sazstock_webhook_connected', 1 );
		wp_send_json_success( array(
			'message' => __( 'Telegram Webhook registered successfully! Inline Snooze is now active.', 'sazstock-stock-alerts-for-woocommerce' ),
			'url'     => $webhook_url,
		) );
	}

	public function render_settings_page() {
		$bot_token        = SazStock_Telegram::instance()->get_bot_token();
		$chat_id          = SazStock_Telegram::instance()->get_chat_id();
		$threshold        = get_option( 'sazstock_global_threshold', 2 );
		$webhook_url      = SazStock_Webhook::instance()->get_webhook_url();
		$is_hook_active   = (bool) get_option( 'sazstock_webhook_connected', 0 );
		?>
		<div class="wrap sazstock-settings-wrap">
			<div class="sazstock-header">
				<h1>
					<span class="sazstock-badge">SazStock</span>
					<?php esc_html_e( 'WooCommerce Stock Alerts & Control via Telegram', 'sazstock-stock-alerts-for-woocommerce' ); ?>
				</h1>
				<p class="sazstock-subtitle"><?php esc_html_e( 'Know your stock. Act from Telegram.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
			</div>

			<div class="sazstock-grid">
				<!-- Main Settings Column -->
				<div class="sazstock-card">
					<h2>⚙️ <?php esc_html_e( 'Telegram & Stock Configuration', 'sazstock-stock-alerts-for-woocommerce' ); ?></h2>
					
					<form method="post" action="options.php">
						<?php settings_fields( 'sazstock_settings_group' ); ?>

						<table class="form-table">
							<tr>
								<th scope="row">
									<label for="sazstock_bot_token"><?php esc_html_e( 'Telegram Bot Token', 'sazstock-stock-alerts-for-woocommerce' ); ?></label>
								</th>
								<td>
									<input type="password" id="sazstock_bot_token" name="sazstock_bot_token" value="<?php echo esc_attr( $bot_token ); ?>" class="regular-text" placeholder="123456789:AAH..." />
									<button type="button" class="button button-secondary sazstock-toggle-pwd" data-target="sazstock_bot_token">👁️</button>
									<p class="description"><?php esc_html_e( 'Obtain from @BotFather in Telegram.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="sazstock_chat_id"><?php esc_html_e( 'Telegram Chat ID', 'sazstock-stock-alerts-for-woocommerce' ); ?></label>
								</th>
								<td>
									<input type="text" id="sazstock_chat_id" name="sazstock_chat_id" value="<?php echo esc_attr( $chat_id ); ?>" class="regular-text" placeholder="e.g. 123456789 or -100..." />
									<p class="description"><?php esc_html_e( 'Your personal Chat ID or Group ID where stock alerts will be delivered.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="sazstock_global_threshold"><?php esc_html_e( 'Low Stock Threshold', 'sazstock-stock-alerts-for-woocommerce' ); ?></label>
								</th>
								<td>
									<input type="number" id="sazstock_global_threshold" name="sazstock_global_threshold" value="<?php echo esc_attr( $threshold ); ?>" class="small-text" min="1" step="1" />
									<p class="description"><?php esc_html_e( 'Alert is triggered when product stock reaches or drops below this quantity.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
								</td>
							</tr>
						</table>

						<?php submit_button( __( 'Save Settings', 'sazstock-stock-alerts-for-woocommerce' ), 'primary', 'submit', true ); ?>
					</form>
				</div>

				<!-- Control & Webhook Actions Column -->
				<div class="sazstock-sidebar">
					<!-- Test Alert Card -->
					<div class="sazstock-card sazstock-card-action">
						<h3>📡 <?php esc_html_e( 'Connection Test', 'sazstock-stock-alerts-for-woocommerce' ); ?></h3>
						<p><?php esc_html_e( 'Send a verification message to your Telegram chat to confirm credentials.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
						<button type="button" id="sazstock-btn-test" class="button button-primary">
							🔔 <?php esc_html_e( 'Send Test Alert', 'sazstock-stock-alerts-for-woocommerce' ); ?>
						</button>
						<div id="sazstock-test-status" class="sazstock-status-box"></div>
					</div>

					<!-- Inbound Webhook for Snooze Card -->
					<div class="sazstock-card">
						<h3>🔕 <?php esc_html_e( '1-Click Snooze Setup', 'sazstock-stock-alerts-for-woocommerce' ); ?></h3>
						<p><?php esc_html_e( 'Allows you to tap [🔕 Snooze 24h] directly in Telegram to mute recurring alerts.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
						<p>
							<strong><?php esc_html_e( 'Webhook Status:', 'sazstock-stock-alerts-for-woocommerce' ); ?></strong>
							<?php if ( $is_hook_active ) : ?>
								<span class="sazstock-pill sazstock-pill-success">✅ <?php esc_html_e( 'Connected', 'sazstock-stock-alerts-for-woocommerce' ); ?></span>
							<?php else : ?>
								<span class="sazstock-pill sazstock-pill-warn">⚠️ <?php esc_html_e( 'Not Connected', 'sazstock-stock-alerts-for-woocommerce' ); ?></span>
							<?php endif; ?>
						</p>
						<button type="button" id="sazstock-btn-webhook" class="button button-secondary">
							🔗 <?php esc_html_e( 'Register Webhook with Telegram', 'sazstock-stock-alerts-for-woocommerce' ); ?>
						</button>
						<div id="sazstock-webhook-status" class="sazstock-status-box"></div>
					</div>

					<!-- Studio Information Card -->
					<div class="sazstock-card sazstock-card-info">
						<h4>Sazonov Studio</h4>
						<p><?php esc_html_e( 'Clean code, HPOS compatibility, zero external bloat.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
						<p><a href="https://sazonov-studio.netlify.app" target="_blank" class="button button-link">🌐 sazonov-studio.netlify.app</a></p>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
