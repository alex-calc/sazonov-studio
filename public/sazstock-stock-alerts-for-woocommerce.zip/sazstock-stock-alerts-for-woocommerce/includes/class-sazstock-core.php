<?php
/**
 * Core inventory observation engine and state transition machine for SazStock.
 */

defined( 'ABSPATH' ) || exit;

class SazStock_Core {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'woocommerce_product_set_stock', array( $this, 'on_stock_change' ), 10, 1 );
		add_action( 'woocommerce_variation_set_stock', array( $this, 'on_stock_change' ), 10, 1 );
	}

	/**
	 * Main stock change observer.
	 */
	public function on_stock_change( $product ) {
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return;
		}

		if ( ! $product->managing_stock() ) {
			return;
		}

		$raw_stock = $product->get_stock_quantity();
		if ( null === $raw_stock ) {
			return;
		}

		$id        = $product->get_id();
		$new_stock = function_exists( 'wc_stock_amount' ) ? wc_stock_amount( $raw_stock ) : (float) $raw_stock;

		// Threshold resolution
		$raw_thresh = get_post_meta( $id, 'sazstock_threshold', true );
		if ( '' !== $raw_thresh && false !== $raw_thresh ) {
			$threshold = function_exists( 'wc_stock_amount' ) ? wc_stock_amount( $raw_thresh ) : (float) $raw_thresh;
		} else {
			$global_thresh = get_option( 'sazstock_global_threshold', '' );
			if ( '' === $global_thresh ) {
				$global_thresh = get_option( 'woocommerce_notify_low_stock_amount', 2 );
			}
			$threshold = function_exists( 'wc_stock_amount' ) ? wc_stock_amount( $global_thresh ) : (float) $global_thresh;
		}

		// Retrieve serialized state record
		$state = get_post_meta( $id, '_sazstock_state', true );

		// Baseline Initialization (no false alarm on fresh install)
		if ( empty( $state ) || ! is_array( $state ) ) {
			$init_state = array(
				'stock'      => $new_stock,
				'state'      => $new_stock <= 0 ? 'out' : ( $new_stock <= $threshold ? 'low' : 'ok' ),
				'updated_at' => time(),
				'alerted_at' => 0,
			);
			update_post_meta( $id, '_sazstock_state', $init_state );
			SazStock_Logger::info( 'Baseline initialized for product', array(
				'id'        => $id,
				'name'      => $product->get_name(),
				'stock'     => $new_stock,
				'threshold' => $threshold,
				'state'     => $init_state['state'],
			) );
			return;
		}

		$prev_stock = function_exists( 'wc_stock_amount' ) ? wc_stock_amount( $state['stock'] ) : (float) $state['stock'];
		$prev_state = isset( $state['state'] ) ? $state['state'] : 'ok';
		$new_state  = $prev_state;

		$snoozed_until = (int) get_post_meta( $id, 'sazstock_snoozed_until', true );
		$is_snoozed    = $snoozed_until > time();

		// SCENARIO 1: OUT OF STOCK (any stock -> <= 0)
		// Always alerts immediately, bypassing low-stock snooze!
		if ( $prev_stock > 0 && $new_stock <= 0 ) {
			$new_state = 'out';
			$this->dispatch_stock_alert( 'OUT_OF_STOCK', $product, $new_stock, $threshold );
		}
		// SCENARIO 2: LOW STOCK TRANSITION (ok -> low)
		elseif ( $prev_stock > $threshold && $new_stock <= $threshold && $new_stock > 0 ) {
			$new_state = 'low';
			if ( ! $is_snoozed ) {
				$this->dispatch_stock_alert( 'LOW_STOCK', $product, $new_stock, $threshold );
			} else {
				SazStock_Logger::info( 'Low stock alert muted by active snooze', array(
					'id'            => $id,
					'snoozed_until' => gmdate( 'Y-m-d H:i:s', $snoozed_until ),
				) );
			}
		}
		// SCENARIO 3: RESTOCK TRANSITION (0 -> N)
		elseif ( $prev_stock <= 0 && $new_stock > 0 ) {
			$new_state = $new_stock <= $threshold ? 'low' : 'ok';
			SazStock_Logger::info( 'Product restocked', array(
				'id'         => $id,
				'prev_stock' => $prev_stock,
				'new_stock'  => $new_stock,
				'new_state'  => $new_state,
			) );
		}
		// SCENARIO 4: Intra-state change (e.g. 2 -> 1 while already low)
		else {
			$new_state = $new_stock <= 0 ? 'out' : ( $new_stock <= $threshold ? 'low' : 'ok' );
		}

		update_post_meta( $id, '_sazstock_state', array(
			'stock'      => $new_stock,
			'state'      => $new_state,
			'updated_at' => time(),
			'alerted_at' => ( $new_state !== $prev_state ) ? time() : ( isset( $state['alerted_at'] ) ? $state['alerted_at'] : 0 ),
		) );
	}

	/**
	 * Generate compact HMAC callback payload (<= 64 bytes total).
	 * Format: ss|s|{id}|{16-char-sig} (approx 24-25 bytes)
	 */
	public static function generate_snooze_payload( $product_id ) {
		$salt      = wp_salt( 'auth' );
		$raw_hash  = hash_hmac( 'sha256', "s|{$product_id}", $salt, true );
		$short_sig = substr( bin2hex( $raw_hash ), 0, 16 );
		return "ss|s|{$product_id}|{$short_sig}";
	}

	/**
	 * Verify compact HMAC callback payload.
	 */
	public static function verify_snooze_payload( $product_id, $received_sig ) {
		$salt         = wp_salt( 'auth' );
		$raw_hash     = hash_hmac( 'sha256', "s|{$product_id}", $salt, true );
		$expected_sig = substr( bin2hex( $raw_hash ), 0, 16 );
		return hash_equals( $expected_sig, (string) $received_sig );
	}

	/**
	 * Format and dispatch rich Telegram notification.
	 */
	public function dispatch_stock_alert( $type, $product, $stock, $threshold ) {
		$telegram = SazStock_Telegram::instance();
		$chat_id  = $telegram->get_chat_id();

		if ( empty( $chat_id ) ) {
			SazStock_Logger::notice( 'Stock alert suppressed: Telegram chat_id not configured', array( 'type' => $type, 'id' => $product->get_id() ) );
			return;
		}

		$id          = $product->get_id();
		$name        = $product->get_name();
		$sku         = $product->get_sku() ? $product->get_sku() : __( 'N/A', 'sazstock-stock-alerts-for-woocommerce' );
		$price       = $product->get_price_html() ? wp_strip_all_tags( $product->get_price_html() ) : '';
		$edit_url    = admin_url( 'post.php?post=' . $id . '&action=edit' );
		$is_out      = ( 'OUT_OF_STOCK' === $type );

		if ( $is_out ) {
			$title = "🚨 <b>OUT OF STOCK</b>";
			$badge = "❌ <b>Current Stock:</b> 0";
		} else {
			$title = "⚠️ <b>LOW STOCK ALERT</b>";
			$badge = "📦 <b>Stock Remaining:</b> {$stock} / Threshold: {$threshold}";
		}

		$message = "{$title}\n\n";
		$message .= "🛒 <b>Product:</b> " . esc_html( $name ) . "\n";
		$message .= "🏷️ <b>SKU:</b> <code>" . esc_html( $sku ) . "</code>\n";
		if ( ! empty( $price ) ) {
			$message .= "💰 <b>Price:</b> " . esc_html( $price ) . "\n";
		}
		$message .= "{$badge}\n";
		$message .= "🕒 " . current_time( 'Y-m-d H:i:s' );

		// Inline Action Buttons (Control Loop)
		$keyboard = array();
		if ( ! $is_out ) {
			$snooze_payload = self::generate_snooze_payload( $id );
			$keyboard[] = array(
				array(
					'text' => '📦 Open Product',
					'url'  => $edit_url,
				),
				array(
					'text'          => '🔕 Snooze 24h',
					'callback_data' => $snooze_payload,
				),
			);
		} else {
			$keyboard[] = array(
				array(
					'text' => '✏️ Restock Product',
					'url'  => $edit_url,
				),
			);
		}

		$result = $telegram->send_message( $chat_id, $message, $keyboard );

		if ( ! is_wp_error( $result ) ) {
			SazStock_Logger::info( "Stock alert sent to Telegram [{$type}]", array(
				'id'        => $id,
				'name'      => $name,
				'stock'     => $stock,
				'threshold' => $threshold,
			) );
		}
	}
}
