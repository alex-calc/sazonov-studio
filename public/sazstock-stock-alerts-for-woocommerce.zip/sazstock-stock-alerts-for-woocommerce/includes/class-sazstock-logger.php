<?php
/**
 * Safe WooCommerce-integrated logger for SazStock.
 */

defined( 'ABSPATH' ) || exit;

class SazStock_Logger {

	private static $instance = null;
	private $wc_logger = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( function_exists( 'wc_get_logger' ) ) {
			$this->wc_logger = wc_get_logger();
		}
	}

	public static function log( $level, $message, $context = array() ) {
		$self = self::instance();
		if ( ! $self->wc_logger ) {
			return;
		}

		$formatted = $message;
		if ( ! empty( $context ) ) {
			$formatted .= ' | Context: ' . wp_json_encode( $context, JSON_UNESCAPED_UNICODE );
		}

		$self->wc_logger->log( $level, $formatted, array( 'source' => 'sazstock' ) );
	}

	public static function info( $message, $context = array() ) {
		self::log( 'info', $message, $context );
	}

	public static function notice( $message, $context = array() ) {
		self::log( 'notice', $message, $context );
	}

	public static function error( $message, $context = array() ) {
		self::log( 'error', $message, $context );
	}
}
