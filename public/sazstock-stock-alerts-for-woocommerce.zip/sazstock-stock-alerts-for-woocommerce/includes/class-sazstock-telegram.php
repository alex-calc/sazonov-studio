<?php
/**
 * Telegram Bot API client for SazStock.
 */

defined( 'ABSPATH' ) || exit;

class SazStock_Telegram {

	private static $instance = null;
	const API_BASE = 'https://api.telegram.org/bot';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function get_bot_token() {
		return trim( (string) get_option( 'sazstock_bot_token', '' ) );
	}

	public function get_chat_id() {
		return trim( (string) get_option( 'sazstock_chat_id', '' ) );
	}

	public function request( $method, $params = array() ) {
		$token = $this->get_bot_token();
		if ( empty( $token ) ) {
			return new WP_Error( 'missing_token', __( 'Telegram Bot Token is not configured.', 'sazstock-stock-alerts-for-woocommerce' ) );
		}

		$url = self::API_BASE . rawurlencode( $token ) . '/' . $method;

		$response = wp_remote_post( $url, array(
			'timeout' => 10,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $params ),
		) );

		if ( is_wp_error( $response ) ) {
			SazStock_Logger::error( 'Telegram request network failure', array( 'method' => $method, 'error' => $response->get_error_message() ) );
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || empty( $body['ok'] ) ) {
			$desc = isset( $body['description'] ) ? $body['description'] : 'HTTP Error ' . $code;
			SazStock_Logger::error( 'Telegram API rejected request', array( 'method' => $method, 'error' => $desc ) );
			return new WP_Error( 'telegram_api_error', $desc );
		}

		return $body;
	}

	public function send_message( $chat_id, $text, $keyboard = null ) {
		$params = array(
			'chat_id'                  => $chat_id,
			'text'                     => $text,
			'parse_mode'               => 'HTML',
			'disable_web_page_preview' => false,
		);

		if ( ! empty( $keyboard ) ) {
			$params['reply_markup'] = array(
				'inline_keyboard' => $keyboard,
			);
		}

		return $this->request( 'sendMessage', $params );
	}

	public function answer_callback_query( $callback_id, $text, $show_alert = false ) {
		return $this->request( 'answerCallbackQuery', array(
			'callback_query_id' => $callback_id,
			'text'              => $text,
			'show_alert'        => (bool) $show_alert,
		) );
	}

	public function set_webhook( $webhook_url, $secret_token ) {
		return $this->request( 'setWebhook', array(
			'url'          => $webhook_url,
			'secret_token' => $secret_token,
			'allowed_updates' => array( 'callback_query' ),
		) );
	}

	public function delete_webhook() {
		return $this->request( 'deleteWebhook', array() );
	}

	public function get_webhook_info() {
		return $this->request( 'getWebhookInfo', array() );
	}

	public function send_test_message( $chat_id ) {
		$store_name = get_bloginfo( 'name' );
		$text = "🔔 <b>SazStock Test Alert</b>\n\n";
		$text .= "✅ Telegram connection verified successfully!\n";
		$text .= "🏪 Store: <b>" . esc_html( $store_name ) . "</b>\n";
		$text .= "⚡ Stock alerts and 1-click Snooze are active and ready.";

		$keyboard = array(
			array(
				array(
					'text' => '🌐 Open Admin',
					'url'  => admin_url( 'admin.php?page=sazstock-settings' ),
				),
			),
		);

		return $this->send_message( $chat_id, $text, $keyboard );
	}
}
