<?php
/**
 * Inbound Telegram Webhook Handler for SazStock.
 */

defined( 'ABSPATH' ) || exit;

class SazStock_Webhook {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( 'sazstock/v1', '/webhook', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'handle_webhook' ),
			'permission_callback' => '__return_true', // Security verification performed inside
		) );
	}

	public function get_webhook_url() {
		return rest_url( 'sazstock/v1/webhook' );
	}

	public function get_or_generate_secret_token() {
		$secret = get_option( 'sazstock_webhook_secret', '' );
		if ( empty( $secret ) ) {
			$secret = wp_generate_password( 32, false, false );
			update_option( 'sazstock_webhook_secret', $secret );
		}
		return $secret;
	}

	public function handle_webhook( WP_REST_Request $request ) {
		// LAYER 1: Verify Secret Token Header
		$secret_header   = $request->get_header( 'x-telegram-bot-api-secret-token' );
		$expected_secret = get_option( 'sazstock_webhook_secret', '' );

		if ( empty( $expected_secret ) || empty( $secret_header ) || ! hash_equals( $expected_secret, (string) $secret_header ) ) {
			SazStock_Logger::error( 'Webhook unauthorized secret token header mismatch', array( 'header' => $secret_header ) );
			return new WP_REST_Response( array( 'error' => 'Unauthorized token' ), 403 );
		}

		$body = $request->get_json_params();
		if ( empty( $body['callback_query'] ) ) {
			return new WP_REST_Response( array( 'ok' => true, 'note' => 'no_callback_query' ), 200 );
		}

		$cb          = $body['callback_query'];
		$callback_id = isset( $cb['id'] ) ? $cb['id'] : '';
		$data        = isset( $cb['data'] ) ? $cb['data'] : '';
		$from_chat   = isset( $cb['message']['chat']['id'] ) ? (string) $cb['message']['chat']['id'] : '';

		// LAYER 2: Verify Authorized Chat ID
		$authorized_chat = (string) get_option( 'sazstock_chat_id', '' );
		if ( empty( $authorized_chat ) || $from_chat !== $authorized_chat ) {
			SazStock_Logger::error( 'Webhook unauthorized chat id', array( 'received' => $from_chat, 'expected' => $authorized_chat ) );
			return new WP_REST_Response( array( 'error' => 'Unauthorized chat' ), 403 );
		}

		// LAYER 3: Parse and Validate Compact Payload: "ss|s|{id}|{sig}"
		$parts = explode( '|', $data );
		if ( count( $parts ) !== 4 || 'ss' !== $parts[0] || 's' !== $parts[1] ) {
			SazStock_Logger::error( 'Webhook invalid callback data format', array( 'data' => $data ) );
			return new WP_REST_Response( array( 'error' => 'Invalid action' ), 400 );
		}

		$product_id   = (int) $parts[2];
		$received_sig = $parts[3];

		// LAYER 4: Verify HMAC Signature
		if ( ! SazStock_Core::verify_snooze_payload( $product_id, $received_sig ) ) {
			SazStock_Logger::error( 'Webhook HMAC signature verification failed', array( 'product_id' => $product_id ) );
			return new WP_REST_Response( array( 'error' => 'Invalid signature' ), 403 );
		}

		// LAYER 5: Verify Product Exists
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new WP_REST_Response( array( 'error' => 'Product not found' ), 404 );
		}

		// 6. Apply Snooze for 24h
		$snooze_duration = DAY_IN_SECONDS;
		$snooze_until    = time() + $snooze_duration;
		update_post_meta( $product_id, 'sazstock_snoozed_until', $snooze_until );

		SazStock_Logger::info( 'Product successfully snoozed for 24h via Telegram', array(
			'product_id'    => $product_id,
			'name'          => $product->get_name(),
			'snoozed_until' => gmdate( 'Y-m-d H:i:s', $snooze_until ),
		) );

		// 7. Answer Callback Query in Telegram client
		if ( ! empty( $callback_id ) ) {
			$telegram = SazStock_Telegram::instance();
			$telegram->answer_callback_query(
				$callback_id,
				__( '🔕 Snoozed for 24 hours. Alerts muted for this product.', 'sazstock-stock-alerts-for-woocommerce' ),
				false
			);
		}

		return new WP_REST_Response( array(
			'ok'            => true,
			'snoozed'       => true,
			'product_id'    => $product_id,
			'snoozed_until' => $snooze_until,
		), 200 );
	}
}
