=== SazStock – Stock Alerts and Control with Telegram for WooCommerce ===
Contributors: alexsazonov
Donate link: https://sazonov-studio.netlify.app/
Tags: woocommerce, inventory, stock alert, telegram, low stock
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Know your stock. Act from Telegram. Real-time WooCommerce low stock and out-of-stock notifications with 1-click Snooze and product actions.

== Description ==

**SazStock** connects your WooCommerce store inventory directly with your Telegram bot. Instead of passively receiving email notifications, SazStock delivers actionable inventory control loops right into your messenger.

Whenever any product drops to or below your configured low-stock threshold, or sells out completely, you receive an instant alert card with product details, SKU, price, and inline action buttons.

### ⚡ Key Features

* **Real-time Stock Observation:** Automatically detects inventory state transitions when orders are placed, stock is edited, or quantities change.
* **Smart Noise Reduction & Zero Spam:** Baseline initialization on activation prevents false alerts on existing inventory. Repeated sales of items already in low stock do not trigger duplicate notifications.
* **1-Click Telegram Control Loop:** Each alert includes an interactive `[📦 Open Product]` link and a `[🔕 Snooze 24h]` button to mute alerts for that specific item for 24 hours.
* **Out-of-Stock Priority:** Full stockouts (`0 stock`) always trigger immediate critical alerts, even if a previous low-stock warning was muted.
* **High-Performance Order Storage (HPOS) Ready:** 100% compatible with modern WooCommerce database tables and Checkout Blocks.
* **Zero External SaaS:** Self-hosted and serverless architecture. Connects directly to the official Telegram Bot API without third-party subscriptions or monthly fees.

== External Services ==

This plugin communicates with the Telegram Bot API (https://api.telegram.org) over HTTPS to deliver inventory stock notifications and process interactive inline button actions (such as the 24-hour Snooze feature).

* Service Provider: Telegram Messenger Inc.
* Service URL: https://api.telegram.org
* What data is sent: Store name, product titles, stock quantities, SKUs, and administrative notification payloads when stock thresholds are reached or when a test alert is dispatched.
* Terms of Service: https://telegram.org/tos
* Privacy Policy: https://telegram.org/privacy

== Installation ==

1. Upload the `sazstock-stock-alerts-for-woocommerce` folder to the `/wp-content/plugins/` directory, or install the ZIP file via **Plugins → Add New**.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Navigate to **WooCommerce → SazStock Settings**.
4. Enter your Telegram **Bot Token** (from `@BotFather`) and your personal/group **Chat ID**.
5. Set your desired low-stock quantity threshold.
6. Click **Send Test Alert** to verify the connection, then click **Register Webhook** to activate inline 1-click Snooze buttons.

== Frequently Asked Questions ==

= Does this plugin work with variable products? =
Yes, SazStock tracks inventory changes across simple and variable products managing stock.

= Will this plugin flood my Telegram when I first install it? =
No. SazStock implements a baseline initialization mechanism: it records the current state of existing products without dispatching alerts. Alerts are only fired when a product actively transitions across the threshold.

= Is WooCommerce HPOS supported? =
Yes, SazStock is fully declared compatible with WooCommerce High-Performance Order Storage (HPOS) and WooCommerce Cart & Checkout Blocks.

== Screenshots ==

1. SazStock configuration settings in WordPress Admin.
2. Low Stock alert card delivered to Telegram with inline Snooze button.
3. Out of stock critical alert in Telegram.

== Changelog ==

= 1.0.0 =
* Initial public release.
* Automated real-time low stock and out-of-stock Telegram alert engine.
* 1-click inline 24-hour Snooze action via secure Telegram webhook.
* Full WooCommerce HPOS compatibility.
