<?php
/**
 * Plugin Name:       SazStock – Stock Alerts and Control with Telegram for WooCommerce
 * Description:       Real-time WooCommerce low stock and out-of-stock alerts delivered to Telegram with inline 1-click Snooze and Product control.
 * Version:           1.0.0
 * Author:            Sazonov Studio
 * Author URI:        https://sazonov-studio.netlify.app/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sazstock-stock-alerts-for-woocommerce
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * WC requires at least: 7.0
 * WC tested up to:   11.1
 * Requires Plugins:  woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'SAZSTOCK_VERSION', '1.0.0' );
define( 'SAZSTOCK_FILE', __FILE__ );
define( 'SAZSTOCK_DIR', plugin_dir_path( __FILE__ ) );
define( 'SAZSTOCK_URL', plugin_dir_url( __FILE__ ) );
define( 'SAZSTOCK_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Declare HPOS and Checkout Blocks compatibility.
 */
add_action( 'before_woocommerce_init', 'sazstock_declare_hpos_compatibility' );
function sazstock_declare_hpos_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
}

/**
 * Check WooCommerce dependency and initialize plugin.
 */
add_action( 'plugins_loaded', 'sazstock_init_plugin' );
function sazstock_init_plugin() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'sazstock_missing_woocommerce_notice' );
		return;
	}

	require_once SAZSTOCK_DIR . 'includes/class-sazstock-logger.php';
	require_once SAZSTOCK_DIR . 'includes/class-sazstock-telegram.php';
	require_once SAZSTOCK_DIR . 'includes/class-sazstock-core.php';
	require_once SAZSTOCK_DIR . 'includes/class-sazstock-webhook.php';
	require_once SAZSTOCK_DIR . 'includes/class-sazstock-admin.php';

	SazStock_Logger::instance();
	SazStock_Telegram::instance();
	SazStock_Core::instance();
	SazStock_Webhook::instance();
	SazStock_Admin::instance();
}

/**
 * Notice if WooCommerce is not active.
 */
function sazstock_missing_woocommerce_notice() {
	?>
	<div class="notice notice-error">
		<p><?php esc_html_e( 'SazStock requires WooCommerce to be installed and active.', 'sazstock-stock-alerts-for-woocommerce' ); ?></p>
	</div>
	<?php
}

/**
 * Add settings shortcut link to Plugins list.
 */
add_filter( 'plugin_action_links_' . SAZSTOCK_BASENAME, 'sazstock_add_settings_link' );
function sazstock_add_settings_link( $links ) {
	$settings_url = admin_url( 'admin.php?page=sazstock-settings' );
	$settings_link = '<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'sazstock-stock-alerts-for-woocommerce' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
