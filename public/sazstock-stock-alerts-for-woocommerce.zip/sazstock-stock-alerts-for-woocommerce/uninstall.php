<?php
/**
 * Uninstall SazStock.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'sazstock_bot_token' );
delete_option( 'sazstock_chat_id' );
delete_option( 'sazstock_global_threshold' );
delete_option( 'sazstock_webhook_secret' );
delete_option( 'sazstock_webhook_connected' );
