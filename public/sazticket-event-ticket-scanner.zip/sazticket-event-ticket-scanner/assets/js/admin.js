jQuery(document).ready(function($) {
    $('#btn-qqts-tg-test').on('click', function() {
        var $btn = $(this);
        var $res = $('#qqts-tg-test-result');
        $btn.prop('disabled', true).text(sazticketAdmin.sendingText || 'Sending...');
        $res.text('').css('color', '#000');

        $.post(sazticketAdmin.ajaxurl, {
            action: 'qqts_tg_test_message',
            nonce: sazticketAdmin.tgNonce
        }, function(response) {
            $btn.prop('disabled', false).text(sazticketAdmin.sendTestText || 'Send Test Message');
            if (response.success) {
                $res.text(response.data).css('color', 'green');
            } else {
                $res.text('❌ Error: ' + (response.data || 'Check token & chat ID')).css('color', 'red');
            }
        }).fail(function() {
            $btn.prop('disabled', false).text(sazticketAdmin.sendTestText || 'Send Test Message');
            $res.text('❌ Server connection error').css('color', 'red');
        });
    });

    $('.qqts-view-qr-btn').on('click', function() {
        var code = $(this).data('code');
        var guest = $(this).data('guest');
        var type = $(this).data('type');
        var event = $(this).data('event');

        $('#qqts-modal-code').text(code);
        $('#qqts-modal-guest').text(guest);
        $('#qqts-modal-type').text(type);
        $('#qqts-modal-event').text(event);
        
        var qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(code);
        $('#qqts-modal-qr-img').attr('src', qrUrl);

        $('#qqts-qr-modal').css('display', 'flex');
    });

    $('#qqts-close-modal, #qqts-qr-modal').on('click', function(e) {
        if (e.target === this) {
            $('#qqts-qr-modal').hide();
        }
    });

    // Live Real-Time Auto-Polling
    if ($('.qqts-status-cell').length && typeof sazticketAdmin !== 'undefined' && sazticketAdmin.heartbeatNonce) {
        setInterval(function() {
            $.post(sazticketAdmin.ajaxurl, {
                action: 'qqts_get_live_statuses',
                nonce: sazticketAdmin.heartbeatNonce
            }, function(res) {
                if (res.success && res.data) {
                    res.data.forEach(function(item) {
                        var $row = $('tr[data-code="' + item.ticket_code + '"]');
                        if ($row.length) {
                            var $statusCell = $row.find('.qqts-status-cell');
                            var $usedAtCell = $row.find('.qqts-used-at-cell');
                            if (item.status === 'used') {
                                $statusCell.html('<span class="qqts-badge qqts-badge-used">Used</span>');
                                if (item.used_at && $usedAtCell.text().trim() === '—') {
                                    $usedAtCell.text(item.used_at);
                                }
                            }
                        }
                    });
                }
            });
        }, 3000);
    }
});
