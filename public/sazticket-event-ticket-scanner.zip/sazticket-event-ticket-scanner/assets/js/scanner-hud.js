const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playSuccessChime() {
    try {
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
    } catch(e) {}
    if (navigator.vibrate) navigator.vibrate(150);
}

function playAlarmBuzzer() {
    try {
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, audioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(120, audioCtx.currentTime + 0.25);
        osc.frequency.setValueAtTime(320, audioCtx.currentTime + 0.26);
        osc.frequency.linearRampToValueAtTime(100, audioCtx.currentTime + 0.55);
        gain.gain.setValueAtTime(0.5, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.55);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.55);
    } catch(e) {}
    if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 200]);
}

let isProcessing = false;
let lastScannedCode = "";
let lastScannedTime = 0;
let html5QrCode = null;

function showHud(type, title, desc, duration = 3000) {
    const overlay = document.getElementById('hud-overlay');
    const hudIcon = document.getElementById('hud-icon');
    const hudTitle = document.getElementById('hud-title');
    const hudDesc = document.getElementById('hud-desc');
    const laser = document.getElementById('laser');

    overlay.className = 'hud-overlay ' + type;
    hudTitle.innerText = title;
    hudDesc.innerHTML = desc;
    
    if (type === 'valid') hudIcon.innerText = '✅';
    else if (type === 'duplicate') hudIcon.innerText = '🚨';
    else hudIcon.innerText = '⚠️';

    laser.style.display = 'none';

    setTimeout(() => {
        overlay.style.display = 'none';
        overlay.className = 'hud-overlay';
        laser.style.display = 'block';
        isProcessing = false;
    }, duration);
}

async function onScanSuccess(decodedText) {
    const now = Date.now();
    if (isProcessing) return;
    if (decodedText === lastScannedCode && (now - lastScannedTime) < 4000) return;

    isProcessing = true;
    lastScannedCode = decodedText;
    lastScannedTime = now;

    let code = decodedText.trim();
    if (code.includes('qqts_code=')) {
        try {
            const url = new URL(code);
            code = url.searchParams.get('qqts_code') || code;
        } catch(e) {}
    }

    try {
        const response = await fetch(sazticketScanner.restUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': sazticketScanner.restNonce,
                'X-Scanner-Token': sazticketScanner.scannerToken || ''
            },
            body: JSON.stringify({
                ticket_code: code,
                scanner_token: sazticketScanner.scannerToken || ''
            })
        });

        const data = await response.json();

        if (response.ok && (data.status === 'valid' || data.success === true)) {
            playSuccessChime();
            showHud('valid', 'ACCESS GRANTED', `<strong>${data.guest || 'Guest'}</strong><br>${data.type || 'Standard Pass'}<br><span style="font-size:11px;opacity:0.8;">#${data.code}</span>`, 2500);
        } else if (data.status === 'already_used' || data.is_duplicate === true) {
            playAlarmBuzzer();
            showHud('duplicate', 'ALREADY USED!', `<strong>${data.guest || 'Guest'}</strong><br>Scanned at: ${data.used_at || 'Earlier'}<br><span style="color:#fca5a5;">DUPLICATE PASS REJECTED</span>`, 4000);
        } else {
            playAlarmBuzzer();
            showHud('invalid', 'INVALID PASS', data.message || 'Ticket not found in system', 3000);
        }
    } catch (err) {
        showHud('invalid', 'NETWORK ERROR', 'Could not verify ticket. Check internet connection.', 3000);
    }
}

async function requestWakeLock() {
    try {
        if ('wakeLock' in navigator) {
            await navigator.wakeLock.request('screen');
            const ws = document.getElementById('wake-status');
            if (ws) ws.innerText = '🟢 Always-On Active (Screen won't sleep)';
        }
    } catch(err) {}
}

function startScanner() {
    html5QrCode = new Html5Qrcode("reader");
    const config = {
        fps: 20,
        qrbox: function(viewfinderWidth, viewfinderHeight) {
            let minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            return { width: Math.floor(minEdge * 0.75), height: Math.floor(minEdge * 0.75) };
        },
        aspectRatio: 1.0,
        experimentalFeatures: { useBarCodeDetectorIfSupported: true }
    };

    html5QrCode.start(
        { facingMode: "environment" },
        config,
        onScanSuccess,
        () => {}
    ).catch(err => {
        const desc = document.getElementById('hud-desc');
        if (desc) desc.innerText = 'Camera access required. Please allow camera permissions and reload.';
        const overlay = document.getElementById('hud-overlay');
        if (overlay) {
            overlay.className = 'hud-overlay invalid';
            overlay.style.display = 'flex';
        }
    });
}

function restartCameraIfFrozen() {
    if (html5QrCode && !isProcessing) {
        html5QrCode.stop().then(() => startScanner()).catch(() => startScanner());
    }
}

document.addEventListener('DOMContentLoaded', () => {
    startScanner();
    requestWakeLock();
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') requestWakeLock();
    });
});
