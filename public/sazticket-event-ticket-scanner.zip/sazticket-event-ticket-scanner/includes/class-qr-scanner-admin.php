<?php
if (!defined('ABSPATH')) exit;

class QQTS_Admin {
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_init', [__CLASS__, 'handle_manual_actions']);
        add_action('admin_notices', [__CLASS__, 'display_review_notice']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_scripts']);
    }

    public static function display_review_notice() {
        if (!current_user_can('manage_options')) return;
        if (get_option('qqts_review_dismissed')) return;

        global $wpdb;
        $table = $wpdb->prefix . 'qqts_tickets';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $scanned_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}qqts_tickets WHERE status = 'used'");
        if ($scanned_count >= 20) {
            ?>
            <div class="notice notice-success is-dismissible" style="padding: 12px 16px; border-left-color: #46b450;">
                <p style="font-size: 14px; margin: 0 0 8px;">
                    🎉 <strong>SazTicket</strong> has successfully validated <strong><?php echo esc_html($scanned_count); ?> tickets</strong> at your events!
                </p>
                <p style="margin: 0;">
                    If you enjoy using the plugin, please take 30 seconds to support us with a ⭐⭐⭐⭐⭐ review on WordPress.org:
                    <a href="https://wordpress.org/support/plugin/sazticket-event-ticket-scanner/reviews/#new-post" target="_blank" class="button button-primary" style="margin-left: 8px;"><?php esc_html_e('Leave 5-Star Review', 'sazticket-event-ticket-scanner'); ?></a>
                </p>
            </div>
            <?php
        }
    }

        public static function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'quick-qr') === false && strpos($hook, 'sazticket') === false) {
            return;
        }
        wp_enqueue_script('sazticket-admin-js', QQTS_PLUGIN_URL . 'assets/js/admin.js', ['jquery'], SAZTICKET_VERSION, true);
        wp_localize_script('sazticket-admin-js', 'sazticketAdmin', [
            'ajaxurl'        => admin_url('admin-ajax.php'),
            'tgNonce'        => wp_create_nonce('qqts_tg_test_nonce'),
            'heartbeatNonce' => wp_create_nonce('qqts_admin_heartbeat_nonce'),
            'sendingText'    => __('Sending...', 'sazticket-event-ticket-scanner'),
            'sendTestText'   => __('Send Test Message', 'sazticket-event-ticket-scanner'),
        ]);
    }

public static function register_menu() {
        add_menu_page(
            __('QR Tickets', 'sazticket-event-ticket-scanner'),
            __('QR Tickets', 'sazticket-event-ticket-scanner'),
            'manage_options',
            'sazticket-tickets',
            [__CLASS__, 'render_admin_page'],
            'dashicons-tickets-alt',
            30
        );

        add_submenu_page(
            'sazticket-tickets',
            __('Tickets & Scanner', 'sazticket-event-ticket-scanner'),
            __('Tickets & Scanner', 'sazticket-event-ticket-scanner'),
            'manage_options',
            'sazticket-tickets',
            [__CLASS__, 'render_admin_page']
        );

        add_submenu_page(
            'sazticket-tickets',
            __('Telegram Settings', 'sazticket-event-ticket-scanner'),
            __('💬 Telegram Bot', 'sazticket-event-ticket-scanner'),
            'manage_options',
            'sazticket-telegram',
            [__CLASS__, 'render_telegram_page']
        );
    }

    public static function handle_manual_actions() {
        if (!current_user_can('manage_options')) return;

        if (isset($_POST['qqts_create_ticket']) && check_admin_referer('qqts_create_ticket_action')) {
            global $wpdb;
            $table = $wpdb->prefix . 'qqts_tickets';
            $guest_name   = isset($_POST['guest_name']) ? sanitize_text_field(wp_unslash($_POST['guest_name'])) : '';
            $guest_email  = isset($_POST['guest_email']) ? sanitize_email(wp_unslash($_POST['guest_email'])) : '';
            $ticket_type  = isset($_POST['ticket_type']) ? sanitize_text_field(wp_unslash($_POST['ticket_type'])) : 'Standard';
            $ticket_price = isset($_POST['ticket_price']) ? sanitize_text_field(wp_unslash($_POST['ticket_price'])) : '0 EUR';
            $event_name   = isset($_POST['event_name']) ? sanitize_text_field(wp_unslash($_POST['event_name'])) : '';
            $code         = 'TKT-' . strtoupper(wp_generate_password(10, false, false));

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $wpdb->insert($table, [
                'ticket_code' => $code,
                'guest_name'  => $guest_name,
                'guest_email' => $guest_email,
                'ticket_type' => $ticket_type,
                'event_name'  => $event_name,
                'status'      => 'valid'
            ]);

            // Notify Telegram instantly on manual creation
            if (class_exists('QQTS_Telegram')) {
                QQTS_Telegram::notify_manual_ticket_created($guest_name, $guest_email, $event_name, $ticket_type, $ticket_price, $code);
            }

            // Dispatch HTML E-Ticket Pass to Guest Email
            if (class_exists('QQTS_Mailer') && !empty($guest_email)) {
                QQTS_Mailer::send_ticket_email($guest_email, $guest_name, $event_name, $ticket_type, $ticket_price, $code);
            }

            wp_safe_redirect(admin_url('admin.php?page=sazticket-tickets&created=1'));
            exit;
        }
    }

    public static function render_telegram_page() {
        $options = QQTS_Telegram::get_options();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('💬 Telegram Order & Ticket Notifications', 'sazticket-event-ticket-scanner'); ?></h1>
            <p><?php esc_html_e('Automatically sends instant Telegram notifications when tickets are purchased, issued or scanned at the gate.', 'sazticket-event-ticket-scanner'); ?></p>
            
            <form method="post" action="options.php" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-top: 15px;">
                <?php settings_fields('qqts_telegram_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Integration Status', 'sazticket-event-ticket-scanner'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="qqts_telegram_settings[enabled]" value="1" <?php checked('1', isset($options['enabled']) ? $options['enabled'] : '0'); ?> />
                                <strong><?php esc_html_e('Enable Telegram notifications', 'sazticket-event-ticket-scanner'); ?></strong>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Telegram Bot Token', 'sazticket-event-ticket-scanner'); ?></th>
                        <td>
                            <input type="text" name="qqts_telegram_settings[bot_token]" value="<?php echo esc_attr(isset($options['bot_token']) ? $options['bot_token'] : ''); ?>" class="regular-text" placeholder="1234567890:AAH..." />
                            <p class="description"><?php esc_html_e('Create a bot with @BotFather and paste the token here.', 'sazticket-event-ticket-scanner'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Telegram Chat ID / Group ID', 'sazticket-event-ticket-scanner'); ?></th>
                        <td>
                            <input type="text" name="qqts_telegram_settings[chat_id]" value="<?php echo esc_attr(isset($options['chat_id']) ? $options['chat_id'] : ''); ?>" class="regular-text" placeholder="-100... or 1142060901" />
                            <p class="description"><?php esc_html_e('Group or channel ID (e.g. -1001234567890 or 1142060901).', 'sazticket-event-ticket-scanner'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'sazticket-event-ticket-scanner')); ?>
            </form>

            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-top: 20px;">
                <h3><?php esc_html_e('🧪 Test Telegram Connection', 'sazticket-event-ticket-scanner'); ?></h3>
                <p><?php esc_html_e('Click the button below to send a live test notification:', 'sazticket-event-ticket-scanner'); ?></p>
                <button type="button" class="button button-secondary" id="btn-qqts-tg-test"><?php esc_html_e('Send Test Message', 'sazticket-event-ticket-scanner'); ?></button>
                <span id="qqts-tg-test-result" style="margin-left: 15px; font-weight: bold;"></span>
            </div>
        </div>
        <?php
    }

    public static function render_admin_page() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $tickets = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}qqts_tickets ORDER BY id DESC LIMIT 100");
        $scanner_url = home_url('/?sazticket_scanner=1');
        $heartbeat_nonce = wp_create_nonce('qqts_admin_heartbeat_nonce');
        ?>
        <div class="wrap">
            <h1>🎟️ <?php esc_html_e('SazTicket – Ticket Scanner & Management', 'sazticket-event-ticket-scanner'); ?> <span style="font-size: 12px; vertical-align: middle; background: #e0f2fe; color: #0369a1; padding: 3px 8px; border-radius: 12px; margin-left: 10px;">⚡ Live Real-Time Polling Active</span></h1>
            <div style="background: #fff; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2>📱 <?php esc_html_e('Live Door Scanner (For Bouncers & Staff)', 'sazticket-event-ticket-scanner'); ?></h2>
                <p><?php esc_html_e('Open this URL on any smartphone camera (iPhone / Android) to start scanning instantly without app download:', 'sazticket-event-ticket-scanner'); ?></p>
                <p><strong><?php esc_html_e('Scanner URL:', 'sazticket-event-ticket-scanner'); ?></strong> <a href="<?php echo esc_url($scanner_url); ?>" target="_blank" class="button button-primary"><?php echo esc_html($scanner_url); ?></a></p>
                <p><em><?php esc_html_e('Or use shortcode: [sazticket_scanner] on any private page.', 'sazticket-event-ticket-scanner'); ?></em></p>
            </div>

            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 300px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                    <h3>➕ <?php esc_html_e('Create Manual Ticket', 'sazticket-event-ticket-scanner'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('qqts_create_ticket_action'); ?>
                        <p><label><strong><?php esc_html_e('Guest Name:', 'sazticket-event-ticket-scanner'); ?></strong><br><input type="text" name="guest_name" class="widefat" placeholder="e.g. Elon Musk" required></label></p>
                        <p><label><strong><?php esc_html_e('Guest Email:', 'sazticket-event-ticket-scanner'); ?></strong><br><input type="email" name="guest_email" class="widefat" placeholder="elon@x.com"></label></p>
                        <p><label><strong><?php esc_html_e('Event Name:', 'sazticket-event-ticket-scanner'); ?></strong><br><input type="text" name="event_name" class="widefat" value="Global Tech Summit 2026"></label></p>
                        <p style="display: flex; gap: 10px;">
                            <label style="flex: 1;"><strong><?php esc_html_e('Ticket Type:', 'sazticket-event-ticket-scanner'); ?></strong><br>
                                <select name="ticket_type" class="widefat">
                                    <option value="Standard"><?php esc_html_e('Standard Entry', 'sazticket-event-ticket-scanner'); ?></option>
                                    <option value="VIP"><?php esc_html_e('VIP Pass', 'sazticket-event-ticket-scanner'); ?></option>
                                    <option value="Table"><?php esc_html_e('Table Reservation', 'sazticket-event-ticket-scanner'); ?></option>
                                </select>
                            </label>
                            <label style="flex: 1;"><strong><?php esc_html_e('Price / Fee:', 'sazticket-event-ticket-scanner'); ?></strong><br>
                                <input type="text" name="ticket_price" class="widefat" value="50 EUR" placeholder="e.g. 50 EUR">
                            </label>
                        </p>
                        <p style="margin-top: 15px;"><input type="submit" name="qqts_create_ticket" class="button button-primary" value="<?php esc_attr_e('Generate Ticket QR', 'sazticket-event-ticket-scanner'); ?>"></p>
                    </form>
                </div>

                <div style="flex: 2; min-width: 450px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                    <h3>📋 <?php esc_html_e('Recent Tickets & Status', 'sazticket-event-ticket-scanner'); ?></h3>
                    <table class="wp-list-table widefat fixed striped" id="qqts-tickets-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Ticket Pass & QR', 'sazticket-event-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Guest', 'sazticket-event-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Type', 'sazticket-event-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Status', 'sazticket-event-ticket-scanner'); ?></th>
                                <th><?php esc_html_e('Used At', 'sazticket-event-ticket-scanner'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tickets)): ?>
                                <tr><td colspan="5"><?php esc_html_e('No tickets generated yet. Create your first ticket on the left!', 'sazticket-event-ticket-scanner'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($tickets as $t): ?>
                                    <tr data-code="<?php echo esc_attr($t->ticket_code); ?>">
                                        <td>
                                            <strong><code><?php echo esc_html($t->ticket_code); ?></code></strong><br>
                                            <button type="button" class="button button-small qqts-view-qr-btn" style="margin-top: 4px; font-size: 11px;" 
                                                data-code="<?php echo esc_attr($t->ticket_code); ?>" 
                                                data-guest="<?php echo esc_attr($t->guest_name); ?>"
                                                data-type="<?php echo esc_attr($t->ticket_type); ?>"
                                                data-event="<?php echo esc_attr($t->event_name ?: 'VIP Event'); ?>">
                                                🎟️ <?php esc_html_e('Show QR Pass', 'sazticket-event-ticket-scanner'); ?>
                                            </button>
                                        </td>
                                        <td><?php echo esc_html($t->guest_name); ?><br><small><?php echo esc_html($t->guest_email); ?></small></td>
                                        <td><?php echo esc_html($t->ticket_type); ?></td>
                                        <td class="qqts-status-cell">
                                            <?php if ($t->status === 'valid'): ?>
                                                <span style="color: #46b450; font-weight: bold;">🟢 <?php esc_html_e('Valid', 'sazticket-event-ticket-scanner'); ?></span>
                                            <?php else: ?>
                                                <span style="color: #dc3232; font-weight: bold;">🔴 <?php esc_html_e('Used', 'sazticket-event-ticket-scanner'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="qqts-used-at-cell"><?php echo esc_html($t->used_at ?: '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Visual QR Pass Modal -->
        <div id="qqts-qr-modal" style="display:none; position:fixed; z-index:99999; left:0; top:0; width:100%; height:100%; background:rgba(15,23,42,0.75); backdrop-filter:blur(4px); align-items:center; justify-content:center;">
            <div style="background:#fff; border-radius:16px; width:360px; padding:24px; text-align:center; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); position:relative;">
                <button type="button" id="qqts-close-modal" style="position:absolute; right:16px; top:16px; border:none; background:#f1f5f9; width:32px; height:32px; border-radius:50%; font-size:16px; cursor:pointer; font-weight:bold;">✕</button>
                <div style="font-size:12px; font-weight:800; color:#3b82f6; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;" id="qqts-modal-event">VIP EVENT</div>
                <h2 style="margin:0 0 6px; font-size:20px; color:#0f172a;" id="qqts-modal-guest">John Doe</h2>
                <div style="display:inline-block; padding:4px 12px; background:#dbeafe; color:#1e40af; border-radius:20px; font-size:12px; font-weight:bold; margin-bottom:16px;" id="qqts-modal-type">VIP Pass</div>
                
                <!-- Live Scannable Graphic QR Code -->
                <div style="background:#f8fafc; padding:16px; border-radius:12px; border:2px dashed #cbd5e1; display:inline-block; margin-bottom:16px;">
                    <img id="qqts-modal-qr-img" src="" alt="Ticket QR" style="width:180px; height:180px; display:block; margin:0 auto; image-rendering:pixelated;" />
                </div>
                
                <div style="font-family:monospace; font-size:16px; font-weight:800; letter-spacing:2px; color:#1e293b; margin-bottom:16px; background:#f1f5f9; padding:8px 12px; border-radius:6px;" id="qqts-modal-code">TKT-XXXXX</div>
                
                <p style="font-size:12px; color:#64748b; margin:0;">Point camera scanner at this QR code to validate entry.</p>
            </div>
        </div>

        <!-- Admin modal & polling logic enqueued via sazticketAdmin assets/js/admin.js -->
        <?php
    }
}
