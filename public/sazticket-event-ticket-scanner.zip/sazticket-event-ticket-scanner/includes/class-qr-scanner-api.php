<?php
if (!defined('ABSPATH')) exit;

class QQTS_API {
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
        add_action('wp_ajax_qqts_check_in', [__CLASS__, 'ajax_check_in']);
        add_action('wp_ajax_nopriv_qqts_check_in', [__CLASS__, 'ajax_check_in']);
        add_action('wp_ajax_qqts_get_live_statuses', [__CLASS__, 'ajax_get_live_statuses']);
        add_action('template_redirect', [__CLASS__, 'handle_scanner_endpoint']);
        add_shortcode('sazticket_scanner', [__CLASS__, 'render_scanner_shortcode']);
        add_shortcode('quick_qr_scanner', [__CLASS__, 'render_scanner_shortcode']);
    }

    public static function register_rest_routes() {
        register_rest_route('sazticket/v1', '/checkin', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_check_in'],
            'permission_callback' => [__CLASS__, 'validate_scanner_permission'],
        ]);
        register_rest_route('qqts/v1', '/checkin', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_check_in'],
            'permission_callback' => [__CLASS__, 'validate_scanner_permission'],
        ]);
    }

        public static function validate_scanner_permission($request) {
        $nonce = $request->get_header('X-WP-Nonce') ?: $request->get_param('nonce');
        if (!empty($nonce) && wp_verify_nonce($nonce, 'wp_rest')) {
            return true;
        }
        if (!empty($nonce) && wp_verify_nonce($nonce, 'sazticket_scanner_nonce')) {
            return true;
        }
        if (!empty($nonce) && wp_verify_nonce($nonce, 'qqts_scanner_nonce')) {
            return true;
        }
        // Allow logged-in administrators / shop managers
        if (current_user_can('manage_woocommerce') || current_user_can('edit_shop_orders') || current_user_can('manage_options')) {
            return true;
        }
        // Strict check for secret scanner token
        $token = sanitize_text_field($request->get_param('scanner_token') ?: $request->get_header('X-Scanner-Token'));
        $saved_token = get_option('sazticket_scanner_secret_token', get_option('qqts_scanner_secret_token', ''));
        if (!empty($saved_token) && !empty($token) && hash_equals($saved_token, $token)) {
            return true;
        }

        // Explicitly deny unauthenticated access
        return false;
    }

    public static function rest_check_in($request) {
        $code = sanitize_text_field($request->get_param('ticket_code') ?? '');
        $result = self::process_ticket_checkin($code);

        return new WP_REST_Response($result['data'], $result['status_code']);
    }

    public static function ajax_get_live_statuses() {
        check_ajax_referer('qqts_admin_heartbeat_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $results = $wpdb->get_results("SELECT ticket_code, status, used_at FROM {$wpdb->prefix}qqts_tickets ORDER BY id DESC LIMIT 100", ARRAY_A);

        wp_send_json_success($results);
    }

    public static function handle_scanner_endpoint() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $saz_scanner = isset($_GET['sazticket_scanner']) ? sanitize_text_field(wp_unslash($_GET['sazticket_scanner'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $qqts_scanner = isset($_GET['qqts_scanner']) ? sanitize_text_field(wp_unslash($_GET['qqts_scanner'])) : '';

        if ($saz_scanner === '1' || $qqts_scanner === '1') {
            include QQTS_PLUGIN_DIR . 'templates/scanner-hud.php';
            exit;
        }
    }

    public static function render_scanner_shortcode() {
        ob_start();
        include QQTS_PLUGIN_DIR . 'templates/scanner-hud.php';
        return ob_get_clean();
    }

    public static function ajax_check_in() {
        check_ajax_referer('qqts_scanner_nonce', 'nonce');

        $code = isset($_POST['ticket_code']) ? sanitize_text_field(wp_unslash($_POST['ticket_code'])) : '';
        $result = self::process_ticket_checkin($code);

        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['data']);
        }
    }

    /**
     * Unified Atomic Check-In Processor
     * Completely prevents Race Conditions during simultaneous multi-gate scanning
     */
    public static function process_ticket_checkin($code) {
        // Security: IP Rate Limiting (Anti-Brute Force)
        $client_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';
        $transient_key = 'qqts_rate_' . md5($client_ip);
        $attempts = (int) get_transient($transient_key);
        if ($attempts > 30) {
            return [
                'success' => false,
                'status_code' => 429,
                'data' => ['message' => __('Rate limit exceeded. Please wait 5 seconds.', 'sazticket-event-ticket-scanner')]
            ];
        }
        set_transient($transient_key, $attempts + 1, 5);

        if (empty($code)) {
            return [
                'success' => false,
                'status_code' => 400,
                'data' => ['message' => __('Invalid QR code data.', 'sazticket-event-ticket-scanner')]
            ];
        }

        global $wpdb;
        $now = current_time('mysql');

        // ATOMIC CHECK & BURN: Eliminates race conditions between simultaneous gate scanners
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}qqts_tickets SET status = 'used', used_at = %s WHERE ticket_code = %s AND status = 'valid'",
            $now,
            $code
        ));

        if ($updated === 0) {
            // Ticket was either already used, or does not exist in DB
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}qqts_tickets WHERE ticket_code = %s", $code));

            if (!$ticket) {
                return [
                    'success' => false,
                    'status_code' => 404,
                    'data' => [
                        'is_invalid' => true,
                        'message' => __('❌ TICKET NOT FOUND / INVALID QR', 'sazticket-event-ticket-scanner')
                    ]
                ];
            }

            // Ticket exists but is already burnt (Security Duplicate Alert!)
            if (class_exists('QQTS_Telegram')) {
                QQTS_Telegram::notify_gate_alarm($ticket);
            }

            return [
                'success' => false,
                'status_code' => 409,
                'data' => [
                    'is_duplicate' => true,
                    'used_at' => $ticket->used_at,
                    'guest_name' => $ticket->guest_name,
                    'ticket_type' => $ticket->ticket_type,
                    /* translators: %s: date and time when ticket was used */
                    'message' => sprintf(__('⚠️ ALARM: TICKET ALREADY USED on %s', 'sazticket-event-ticket-scanner'), gmdate('M j, H:i', strtotime($ticket->used_at)))
                ]
            ];
        }

        // Successfully checked in! Fetch verified ticket details
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}qqts_tickets WHERE ticket_code = %s", $code));

        // Live Gate Telegram Notification
        if (class_exists('QQTS_Telegram')) {
            QQTS_Telegram::notify_gate_checkin($ticket);
        }

        return [
            'success' => true,
            'status_code' => 200,
            'data' => [
                'status'      => 'valid',
                'code'        => $ticket->ticket_code,
                'guest'       => $ticket->guest_name ?: 'Valued Guest',
                'guest_name'  => $ticket->guest_name ?: 'Valued Guest',
                'type'        => $ticket->ticket_type ?: 'Standard Entry',
                'ticket_type' => $ticket->ticket_type ?: 'Standard Entry',
                'event_name'  => $ticket->event_name ?: 'General Admission',
                'message'     => __('✅ ENTRY APPROVED (ACCESS GRANTED)', 'sazticket-event-ticket-scanner')
            ]
        ];
    }
}
