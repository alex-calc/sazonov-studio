<?php
if (!defined('ABSPATH')) exit;

class QQTS_Telegram {

    private static $option_name = 'qqts_telegram_settings';

    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('wp_ajax_qqts_tg_test_message', [__CLASS__, 'ajax_send_test_message']);

        // --- 1. WP_MAIL INTERCEPTOR (100% Reliable Catch for any Ticket Email) ---
        add_filter('wp_mail', [__CLASS__, 'intercept_ticket_email'], 10, 1);

        // --- 2. DIRECT DATABASE CHECK FOR DP TICKETS TABLE (wp_dp_orders / wp_dp_tickets) ---
        add_action('init', [__CLASS__, 'check_dp_custom_tables'], 20);
        add_action('shutdown', [__CLASS__, 'check_dp_custom_tables'], 20);
        add_action('admin_init', [__CLASS__, 'check_dp_custom_tables'], 20);

        // --- 3. WooCommerce Order Hooks (Asynchronous Action Scheduler Dispatcher) ---
        add_action('qqts_async_dispatch_telegram_order', [__CLASS__, 'handle_wc_order_direct'], 10, 1);
        add_action('woocommerce_order_status_processing', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_order_status_completed', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_payment_complete', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_thankyou', [__CLASS__, 'handle_wc_order'], 10, 1);
        add_action('woocommerce_new_order', [__CLASS__, 'handle_wc_order'], 20, 1);

        // --- 4. DP Tickets & Custom Tickets Action Hooks ---
        add_action('dpt_order_status_completed', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_order_paid', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_order_status_processing', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_after_order_created', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_new_order', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dp_ticket_created', [__CLASS__, 'handle_ticket_created'], 10, 2);
        add_action('dp_order_created', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dp_new_ticket', [__CLASS__, 'handle_dpt_order'], 10, 1);
        add_action('dpt_create_ticket', [__CLASS__, 'handle_dpt_order'], 10, 1);

        // --- 5. WordPress Post Save Fallback for ALL possible Ticket Post Types ---
        $ticket_types = [
            'shop_order', 'dp_ticket', 'dpt_ticket', 'ticket', 
            'dp_order', 'dpt_order', 'event_ticket', 'event_order', 
            'tickets', 'dp_tickets', 'dpt_tickets'
        ];
        foreach ($ticket_types as $ptype) {
            add_action("save_post_{$ptype}", [__CLASS__, 'handle_post_save_order'], 20, 2);
        }
        add_action('save_post', [__CLASS__, 'handle_generic_save_post'], 30, 2);
        add_action('transition_post_status', [__CLASS__, 'handle_status_transition'], 20, 3);
    }

    public static function register_settings() {
        register_setting('qqts_telegram_group', self::$option_name, [
            'type'              => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_settings'],
            'default'           => [],
        ]);
    }

    public static function sanitize_settings($input) {
        $clean = [];
        if (is_array($input)) {
            $clean['enabled']   = !empty($input['enabled']) ? '1' : '0';
            $clean['bot_token'] = isset($input['bot_token']) ? sanitize_text_field(trim($input['bot_token'])) : '';
            $clean['chat_id']   = isset($input['chat_id']) ? sanitize_text_field(trim($input['chat_id'])) : '';
        }
        return $clean;
    }

    public static function get_options() {
        $opts = get_option(self::$option_name, []);
        if (empty($opts['bot_token']) || empty($opts['chat_id'])) {
            $legacy = get_option('vsesvoi_tg_settings', []);
            if (!empty($legacy['bot_token']) && !empty($legacy['chat_id'])) {
                $opts['enabled']   = isset($legacy['enabled']) ? $legacy['enabled'] : '1';
                $opts['bot_token'] = $legacy['bot_token'];
                $opts['chat_id']   = $legacy['chat_id'];
            }
        }

        return wp_parse_args($opts, [
            'enabled'   => '1',
            'bot_token' => '',
            'chat_id'   => ''
        ]);
    }

    public static function detect_city($text) {
        if (empty($text)) return 'Німеччина (Germany)';
        $t = mb_strtolower($text, 'UTF-8');

        if (preg_match('/(nurnberg|nürnberg|нюрнберг|нурнберг)/iu', $t)) {
            return '🇩🇪 Нюрнберг (Nürnberg)';
        }
        if (preg_match('/(stuttgart|штутгарт|стутгарт)/iu', $t)) {
            return '🇩🇪 Штутгарт (Stuttgart)';
        }
        if (preg_match('/(frankfurt|франкфурт)/iu', $t)) {
            return '🇩🇪 Франкфурт (Frankfurt)';
        }
        if (preg_match('/(berlin|берлін|берлин)/iu', $t)) {
            return '🇩🇪 Берлін (Berlin)';
        }
        if (preg_match('/(hamburg|гамбург)/iu', $t)) {
            return '🇩🇪 Гамбург (Hamburg)';
        }
        if (preg_match('/(munich|münchen|мюнхен)/iu', $t)) {
            return '🇩🇪 Мюнхен (München)';
        }
        if (preg_match('/(koln|köln|cologne|кельн|кёльн)/iu', $t)) {
            return '🇩🇪 Кельн (Köln)';
        }
        if (preg_match('/(dortmund|дортмунд)/iu', $t)) {
            return '🇩🇪 Дортмунд (Dortmund)';
        }
        if (preg_match('/(dusseldorf|düsseldorf|дюссельдорф)/iu', $t)) {
            return '🇩🇪 Дюссельдорф (Düsseldorf)';
        }
        if (preg_match('/(hannover|ганновер)/iu', $t)) {
            return '🇩🇪 Ганновер (Hannover)';
        }
        if (preg_match('/(bremen|бремен)/iu', $t)) {
            return '🇩🇪 Бремен (Bremen)';
        }
        if (preg_match('/(leipzig|лейпциг)/iu', $t)) {
            return '🇩🇪 Лейпциг (Leipzig)';
        }
        if (preg_match('/(dresden|дрезден)/iu', $t)) {
            return '🇩🇪 Дрезден (Dresden)';
        }

        // Return first word if uppercase
        $parts = explode(' ', trim($text));
        if (!empty($parts[0])) {
            return '🇩🇪 ' . trim($parts[0]);
        }

        return '🇩🇪 Germany / Global';
    }

    public static function ajax_send_test_message() {
        check_ajax_referer('qqts_tg_test_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions.', 'sazticket-event-ticket-scanner'));
        }

        $options   = self::get_options();
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';

        if (empty($bot_token) || empty($chat_id)) {
            wp_send_json_error(__('Please enter and save Bot Token and Chat ID first!', 'sazticket-event-ticket-scanner'));
        }

        $site_name = get_bloginfo('name');
        $text = "✅ *SazTicket Telegram Integration is Active!*\n\nTest notification from *{$site_name}* delivered successfully.";
        $res = self::send_message($bot_token, $chat_id, $text);

        if ($res['success']) {
            wp_send_json_success(__('Message delivered to Telegram successfully!', 'sazticket-event-ticket-scanner'));
        } else {
            wp_send_json_error($res['error']);
        }
    }

    // --- WP_MAIL INTERCEPTOR ---
    public static function intercept_ticket_email($args) {
        if (!is_array($args)) return $args;

        $subject = isset($args['subject']) ? $args['subject'] : '';
        $message = isset($args['message']) ? $args['message'] : '';
        $to      = isset($args['to']) ? (is_array($args['to']) ? implode(', ', $args['to']) : $args['to']) : '';

        $content = mb_strtolower($subject . ' ' . $message, 'UTF-8');

        // Check if this email is a ticket purchase confirmation
        $keywords = ['билет', 'ticket', 'квиток', 'vse svoi', 'vsesvoi', 'nurnberg', 'stuttgart', 'hamburg', 'berlin', 'köln', 'dortmund', 'frankfurt', 'оплачен', 'замовлення', 'заказ', 'order'];
        $is_ticket = false;
        foreach ($keywords as $kw) {
            if (mb_strpos($content, $kw, 0, 'UTF-8') !== false) {
                $is_ticket = true;
                break;
            }
        }

        if (!$is_ticket) return $args;

        // Anti-duplicate by MD5 of recipient + subject + date hour
        $email_hash = md5($to . $subject . current_time('Y-m-d-H'));
        $sent_cache = get_option('_qqts_sent_emails', []);
        if (in_array($email_hash, $sent_cache)) return $args;

        // Extract Customer Name & Email
        $customer_email = $to;
        $customer_name  = '';
        $event_name     = $subject ?: 'Event Ticket Pass';
        $price          = '';
        $phone          = '';
        $code           = '';

        // Extract using regex from HTML/Plain text
        if (preg_match('/(?:покупатель|покупець|клієнт|клиент|гість|гость|name|customer)[:\s]+([^<\r\n,]+)/iu', $message, $m)) {
            $customer_name = trim(strip_tags($m[1]));
        }
        if (preg_match('/(?:телефон|тел|phone|mobile)[:\s]+([\+\d\s\(\)-]{7,25})/iu', $message, $m)) {
            $phone = trim(strip_tags($m[1]));
        }
        if (preg_match('/(?:сумма|сума|цена|ціна|вартість|total|price)[:\s]+([0-9\.,]+\s*(?:€|eur|грн|uah|\$|usd)?)/iu', $message, $m)) {
            $price = trim(strip_tags($m[1]));
        }
        if (preg_match('/(?:код|билет|ticket|квиток|номер)[:\s#]+([A-Z0-9-]{5,30})/iu', $message, $m)) {
            $code = trim(strip_tags($m[1]));
        }

        if (empty($customer_name)) {
            $customer_name = 'Guest (' . esc_html($customer_email) . ')';
        }

        $options = self::get_options();
        if (!empty($options['enabled']) && $options['enabled'] === '1') {
            $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
            $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';

            if (!empty($bot_token) && !empty($chat_id)) {
                $msg  = "🔔 *New Online Ticket Order!* 💰\n\n";
                $msg .= "🎉 *Event:* " . esc_html($event_name) . "\n";
                $msg .= "👤 *Customer:* " . esc_html($customer_name) . "\n";
                if (!empty($customer_email)) {
                    $msg .= "📧 *Email:* " . esc_html($customer_email) . "\n";
                }
                if (!empty($phone)) {
                    $msg .= "📱 *Phone:* " . esc_html($phone) . "\n";
                }
                if (!empty($price)) {
                    $msg .= "💰 *Total:* " . esc_html($price) . "\n";
                }
                if (!empty($code)) {
                    $msg .= "🔑 *Ticket Code:* `" . esc_html($code) . "`\n";
                }
                $msg .= "⏰ *Order Time:* " . current_time('d.m.Y H:i:s') . "\n\n";
                $msg .= "🔗 [Open Orders in Admin](" . admin_url('admin.php?page=sazticket-tickets') . ")";

                $res = self::send_message($bot_token, $chat_id, $msg);
                if ($res['success']) {
                    $sent_cache[] = $email_hash;
                    if (count($sent_cache) > 200) array_shift($sent_cache);
                    update_option('_qqts_sent_emails', $sent_cache, false);
                }
            }
        }

        return $args;
    }

    // --- DIRECT DATABASE TABLE CHECK FOR DP_ORDERS / DP_TICKETS ---
    public static function check_dp_custom_tables() {
        if (class_exists('Vsesvoi_Telegram_Notifier')) {
            return; // Dedicated Vsesvoi Telegram Notifier handles Vsesvoi orders with zero duplicates!
        }

        global $wpdb;

        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        // Check if dp_orders table exists
        $table_dp_orders = $wpdb->prefix . 'dp_orders';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_dp_orders}'");

        if ($table_exists === $table_dp_orders) {
            $last_checked_id = intval(get_option('_qqts_last_dp_order_id', 0));
            $new_orders = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM `{$table_dp_orders}` WHERE `id` > %d ORDER BY `id` ASC LIMIT 10",
                    $last_checked_id
                ),
                ARRAY_A
            );

            if (!empty($new_orders)) {
                $highest_id = $last_checked_id;
                foreach ($new_orders as $ord) {
                    $ord_id = intval($ord['id']);
                    if ($ord_id > $highest_id) $highest_id = $ord_id;

                    $cust_name  = !empty($ord['customer_name']) ? $ord['customer_name'] : (!empty($ord['name']) ? $ord['name'] : (!empty($ord['client_name']) ? $ord['client_name'] : 'Guest'));
                    $cust_email = !empty($ord['customer_email']) ? $ord['customer_email'] : (!empty($ord['email']) ? $ord['email'] : '');
                    $cust_phone = !empty($ord['customer_phone']) ? $ord['customer_phone'] : (!empty($ord['phone']) ? $ord['phone'] : '');
                    $event_name = !empty($ord['event_title']) ? $ord['event_title'] : (!empty($ord['event_name']) ? $ord['event_name'] : (!empty($ord['event']) ? $ord['event'] : 'Event Pass'));
                    $price      = !empty($ord['total_price']) ? $ord['total_price'] : (!empty($ord['price']) ? $ord['price'] : (!empty($ord['total']) ? $ord['total'] : '0.00 EUR'));
                    $ticket_qty = !empty($ord['ticket_quantity']) ? $ord['ticket_quantity'] : (!empty($ord['quantity']) ? $ord['quantity'] : (!empty($ord['count']) ? $ord['count'] : 1));
                    $code       = !empty($ord['ticket_code']) ? $ord['ticket_code'] : (!empty($ord['code']) ? $ord['code'] : '');

                    $msg  = "🔔 *New Online Ticket Order!* 💰\n\n";
                    $msg .= "🎉 *Event:* " . esc_html($event_name) . "\n";
                    $msg .= "👤 *Customer:* " . esc_html($cust_name) . "\n";
                    if (!empty($cust_email)) {
                        $msg .= "📧 *Email:* " . esc_html($cust_email) . "\n";
                    }
                    if (!empty($cust_phone)) {
                        $msg .= "📱 *Phone:* " . esc_html($cust_phone) . "\n";
                    }
                    $msg .= "🎫 *Quantity:* " . intval($ticket_qty) . " pcs\n";
                    $msg .= "💰 *Total:* " . esc_html($price) . "\n";
                    if (!empty($code)) {
                        $msg .= "🔑 *Ticket Code:* `" . esc_html($code) . "`\n";
                    }
                    $msg .= "🆔 *Order ID:* #{$ord_id}\n\n";
                    $msg .= "🔗 [Open Orders Table](" . admin_url('admin.php?page=sazticket-tickets') . ")";

                    self::send_message($bot_token, $chat_id, $msg);
                }
                update_option('_qqts_last_dp_order_id', $highest_id, false);
            }
        }
    }

    public static function notify_manual_ticket_created($guest_name, $guest_email, $event_name, $ticket_type, $price, $code) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $msg  = "🎫 *New Ticket Created (Admin Generator)*\n\n";
        $msg .= "🎉 *Event:* " . esc_html($event_name ?: 'Main Event') . "\n";
        $msg .= "👤 *Guest:* " . esc_html($guest_name ?: 'Guest') . "\n";
        if (!empty($guest_email)) {
            $msg .= "📧 *Email:* " . esc_html($guest_email) . "\n";
        }
        $msg .= "🏷️ *Type:* " . esc_html($ticket_type ?: 'Standard') . "\n";
        $msg .= "💰 *Price / Fee:* " . esc_html($price ?: '0.00 EUR') . "\n";
        $msg .= "🔑 *Ticket Code:* `" . esc_html($code) . "`\n";
        $msg .= "🟢 *Status:* Ready for Entry";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function notify_gate_checkin($ticket) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $time = current_time('H:i:s (d.m.Y)');

        $msg  = "🎟️ *Gate Entry: Access Granted* ✅\n\n";
        $msg .= "👤 *Guest:* " . esc_html($ticket->guest_name ?: 'Guest') . "\n";
        $msg .= "🎫 *Type:* " . esc_html($ticket->ticket_type ?: 'Standard') . "\n";
        $msg .= "🎉 *Event:* " . esc_html($ticket->event_name ?: 'Main Event') . "\n";
        $msg .= "🔑 *Code:* `" . esc_html($ticket->ticket_code) . "`\n";
        $msg .= "⏰ *Scan Time:* {$time}";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function notify_gate_alarm($ticket) {
        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;
        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $time = current_time('H:i:s');

        $msg  = "🚨 *SECURITY ALARM: Duplicate Ticket Attempt!* ⛔\n\n";
        $msg .= "👤 *Guest on Ticket:* " . esc_html($ticket->guest_name ?: 'Guest') . "\n";
        $msg .= "🔑 *Code:* `" . esc_html($ticket->ticket_code) . "`\n";
        $msg .= "⚠️ *Originally Used:* " . esc_html($ticket->used_at) . "\n";
        $msg .= "⛔ *Attempt Time:* {$time}\n";
        $msg .= "_Staff at the door rejected entry._";

        self::send_message($bot_token, $chat_id, $msg);
    }

    public static function handle_ticket_created($ticket_id, $order_id = 0) {
        $target_id = $order_id ? $order_id : $ticket_id;
        self::handle_wc_order($target_id);
    }

    public static function handle_dpt_order($order_id) {
        self::handle_wc_order($order_id);
    }

    public static function handle_post_save_order($post_id, $post = null) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        self::handle_wc_order($post_id);
    }

    public static function handle_generic_save_post($post_id, $post = null) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        
        $post_type = get_post_type($post_id);
        $valid_types = [
            'shop_order', 'dp_ticket', 'dpt_ticket', 'ticket', 
            'dp_order', 'dpt_order', 'event_ticket', 'event_order', 
            'tickets', 'dp_tickets', 'dpt_tickets'
        ];
        
        if (in_array($post_type, $valid_types)) {
            self::handle_wc_order($post_id);
        }
    }

    public static function handle_status_transition($new_status, $old_status, $post) {
        if (!$post || !isset($post->ID)) return;
        if ($new_status === 'publish' || $new_status === 'processing' || $new_status === 'completed') {
            $post_type = get_post_type($post->ID);
            $valid_types = [
                'shop_order', 'dp_ticket', 'dpt_ticket', 'ticket', 
                'dp_order', 'dpt_order', 'event_ticket', 'event_order', 
                'tickets', 'dp_tickets', 'dpt_tickets'
            ];
            if (in_array($post_type, $valid_types)) {
                self::handle_wc_order($post->ID);
            }
        }
    }

    public static function handle_wc_order($order_id) {
        if (!$order_id) return;

        if (is_object($order_id) && method_exists($order_id, 'get_id')) {
            $order_id = $order_id->get_id();
        }

        // Delegate to Action Scheduler for zero checkout latency if available
        if (function_exists('as_enqueue_async_action') && !doing_action('qqts_async_dispatch_telegram_order')) {
            $already_queued = get_post_meta($order_id, '_qqts_tg_queued', true);
            if ($already_queued !== 'yes') {
                update_post_meta($order_id, '_qqts_tg_queued', 'yes');
                as_enqueue_async_action('qqts_async_dispatch_telegram_order', ['order_id' => $order_id]);
                return;
            }
        }

        self::handle_wc_order_direct($order_id);
    }

    public static function handle_wc_order_direct($order_id) {
        if (!$order_id) return;

        if (is_object($order_id) && method_exists($order_id, 'get_id')) {
            $order_id = $order_id->get_id();
        }

        $options = self::get_options();
        if (empty($options['enabled']) || $options['enabled'] !== '1') return;

        $bot_token = isset($options['bot_token']) ? trim($options['bot_token']) : '';
        $chat_id   = isset($options['chat_id']) ? trim($options['chat_id']) : '';
        if (empty($bot_token) || empty($chat_id)) return;

        $already_sent = get_post_meta($order_id, '_qqts_tg_sent', true);
        if ($already_sent === 'yes') return;

        $event_name     = '';
        $customer_name  = '';
        $customer_email = '';
        $customer_phone = '';
        $tickets_count  = 1;
        $total_amount   = '0.00';
        $currency       = 'EUR';

        // 1. Extract from WooCommerce Order
        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && is_object($order)) {
                $fname = method_exists($order, 'get_billing_first_name') ? $order->get_billing_first_name() : '';
                $lname = method_exists($order, 'get_billing_last_name') ? $order->get_billing_last_name() : '';
                $cname = trim($fname . ' ' . $lname);
                if (!empty($cname)) $customer_name = $cname;

                if (method_exists($order, 'get_billing_email')) $customer_email = $order->get_billing_email();
                if (method_exists($order, 'get_billing_phone')) $customer_phone = $order->get_billing_phone();
                if (method_exists($order, 'get_total')) $total_amount = $order->get_total();
                if (method_exists($order, 'get_currency')) $currency = $order->get_currency() ?: 'EUR';

                if (method_exists($order, 'get_items')) {
                    $items = $order->get_items();
                    $item_names = [];
                    $total_qty = 0;
                    foreach ($items as $item) {
                        if (is_object($item)) {
                            $item_names[] = $item->get_name();
                            $total_qty += method_exists($item, 'get_quantity') ? $item->get_quantity() : 1;
                        }
                    }
                    if (!empty($item_names)) $event_name = implode(', ', $item_names);
                    if ($total_qty > 0) $tickets_count = $total_qty;
                }
            }
        }

        // 2. Extract from Post Meta / Custom Fields (DP Tickets, Stripe, Custom Plugins)
        $meta_event = get_post_meta($order_id, 'dpt_event_title', true) 
                   ?: get_post_meta($order_id, '_event_name', true)
                   ?: get_post_meta($order_id, 'event_title', true)
                   ?: get_post_meta($order_id, 'dpt_ticket_event', true)
                   ?: get_post_meta($order_id, 'event_name', true)
                   ?: get_post_meta($order_id, 'dp_event', true)
                   ?: get_post_meta($order_id, 'event', true)
                   ?: get_post_meta($order_id, 'show_title', true);
        if ($meta_event) $event_name = $meta_event;

        $meta_client = get_post_meta($order_id, 'dpt_customer_name', true)
                    ?: get_post_meta($order_id, '_billing_first_name', true)
                    ?: get_post_meta($order_id, 'billing_first_name', true)
                    ?: get_post_meta($order_id, 'client_name', true)
                    ?: get_post_meta($order_id, 'guest_name', true)
                    ?: get_post_meta($order_id, 'customer_name', true)
                    ?: get_post_meta($order_id, 'dp_client_name', true)
                    ?: get_post_meta($order_id, 'name', true);
        if ($meta_client) $customer_name = $meta_client;

        $meta_email = get_post_meta($order_id, 'dpt_customer_email', true)
                   ?: get_post_meta($order_id, '_billing_email', true)
                   ?: get_post_meta($order_id, 'billing_email', true)
                   ?: get_post_meta($order_id, 'client_email', true)
                   ?: get_post_meta($order_id, 'customer_email', true)
                   ?: get_post_meta($order_id, 'dp_email', true)
                   ?: get_post_meta($order_id, 'email', true);
        if ($meta_email) $customer_email = $meta_email;

        $meta_phone = get_post_meta($order_id, 'dpt_customer_phone', true)
                   ?: get_post_meta($order_id, '_billing_phone', true)
                   ?: get_post_meta($order_id, 'billing_phone', true)
                   ?: get_post_meta($order_id, 'client_phone', true)
                   ?: get_post_meta($order_id, 'customer_phone', true)
                   ?: get_post_meta($order_id, 'dp_phone', true)
                   ?: get_post_meta($order_id, 'phone', true);
        if ($meta_phone) $customer_phone = $meta_phone;

        $meta_total = get_post_meta($order_id, '_order_total', true)
                   ?: get_post_meta($order_id, 'dpt_total_price', true)
                   ?: get_post_meta($order_id, 'price', true)
                   ?: get_post_meta($order_id, 'dp_price', true)
                   ?: get_post_meta($order_id, 'total', true)
                   ?: get_post_meta($order_id, 'amount', true);
        if ($meta_total) $total_amount = $meta_total;

        $meta_qty = get_post_meta($order_id, 'dpt_ticket_quantity', true)
                 ?: get_post_meta($order_id, '_ticket_qty', true)
                 ?: get_post_meta($order_id, 'ticket_quantity', true)
                 ?: get_post_meta($order_id, 'quantity', true)
                 ?: get_post_meta($order_id, 'qty', true);
        if ($meta_qty) $tickets_count = intval($meta_qty);

        if (empty($event_name)) {
            $post_title = get_the_title($order_id);
            if (!empty($post_title)) {
                $event_name = $post_title;
            } else {
                $event_name = 'Event Ticket Pass';
            }
        }

        if (empty($customer_name)) {
            $customer_name = 'Customer';
        }

        $admin_order_url = admin_url("admin.php?page=sazticket-tickets");

        $msg  = "🔔 *New Online Ticket Order!* 💰\n\n";
        $msg .= "🎉 *Event:* " . esc_html($event_name) . "\n";
        $msg .= "👤 *Customer:* " . esc_html($customer_name) . "\n";
        if (!empty($customer_email)) {
            $msg .= "📧 *Email:* " . esc_html($customer_email) . "\n";
        }
        if (!empty($customer_phone)) {
            $msg .= "📱 *Phone:* " . esc_html($customer_phone) . "\n";
        }
        $msg .= "🎫 *Quantity:* " . intval($tickets_count) . " tickets\n";
        $msg .= "💰 *Total:* " . esc_html($total_amount) . " " . esc_html($currency) . "\n";
        $msg .= "🆔 *Order ID:* #{$order_id}\n\n";
        $msg .= "🔗 [Open Orders in Admin]({$admin_order_url})";

        $res = self::send_message($bot_token, $chat_id, $msg);
        if ($res['success']) {
                    if (function_exists('wc_get_order')) {
            $order_obj = wc_get_order($order_id);
            if ($order_obj) {
                $order_obj->update_meta_data('_qqts_tg_sent', 'yes');
                $order_obj->save();
            } else {
                update_post_meta($order_id, '_qqts_tg_sent', 'yes');
            }
        } else {
            update_post_meta($order_id, '_qqts_tg_sent', 'yes');
        }
        }
    }

    public static function send_message($bot_token, $chat_id, $text) {
        $api_url = "https://api.telegram.org/bot{$bot_token}/sendMessage";

        $args = [
            'body' => [
                'chat_id'                  => $chat_id,
                'text'                     => $text,
                'parse_mode'               => 'Markdown',
                'disable_web_page_preview' => true,
            ],
            'timeout'   => 15,
            'sslverify' => true,
        ];

        $response = wp_remote_post($api_url, $args);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && isset($body['ok']) && $body['ok'] === true) {
            return ['success' => true];
        }

        $err = isset($body['description']) ? $body['description'] : "HTTP Error {$code}";
        return ['success' => false, 'error' => $err];
    }
}
