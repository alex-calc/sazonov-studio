=== SazTicket – Event Ticket Check-in & Scanner for WooCommerce ===
Contributors: alexsazonov
Tags: ticket scanner, check in, event check-in, telegram notifications, woocommerce tickets
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Mobile-friendly ticket generator, browser camera check-in scanner, and instant Telegram order notifications for events and WooCommerce.

== Description ==

**SazTicket** turns any smartphone into a door entry ticket scanner for events, concerts, conferences, and parties with real-time Telegram notifications.

### Features

* **Browser-Based Scanner:** Event staff open a secure web link on their smartphone (iOS or Android) and scan tickets directly using the device camera.
* **Instant Telegram Alerts:** Automated notifications sent to your Telegram chat when tickets are created, validated, or when duplicate check-in attempts occur.
* **Duplicate Prevention:** Atomic database state transitions prevent duplicate admissions. If a ticket has already been used, the scanner displays a warning alert with the timestamp of prior admission.
* **Audio & Haptic Feedback:** Audible chime and vibration for valid guest admission; warning buzzer for invalid or duplicate passes.
* **WooCommerce Order Delivery:** Automatically generates electronic entry tickets for completed WooCommerce orders and includes them in customer emails.
* **WooCommerce HPOS Compatible:** Built and declared for High-Performance Order Storage (HPOS).
* **Lightweight:** No heavy third-party PHP frameworks. Minimal overhead on your site.

== External services ==

This plugin integrates with two external services to deliver its core functionality:

1. **QRServer API (api.qrserver.com)**
   * **Purpose:** Renders QR code images displayed on customer ticket notifications and the admin pass view.
   * **Data Transmitted:** Only the unique ticket verification code string is passed via HTTPS GET (no customer personal details, names, or payment information are transmitted).
   * **Terms of Service:** https://goqr.me/tos/
   * **Privacy Policy:** https://goqr.me/privacy-policy/

2. **Telegram Bot API (api.telegram.org)**
   * **Purpose:** Delivers instant administrative alerts for ticket check-ins, duplicate entry attempts, and completed WooCommerce ticket orders.
   * **Data Transmitted:** Order ID, ticket code, attendee name, and event name sent exclusively to the store administrator's private configured Telegram Bot and Chat ID.
   * **Terms of Service:** https://telegram.org/tos
   * **Privacy Policy:** https://telegram.org/privacy

== Installation ==

1. Upload the `sazticket-event-ticket-scanner` folder to `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **QR Tickets** in your admin menu to manage tickets or view admissions.
4. (Optional) Enter your Telegram Bot Token & Chat ID in the Telegram tab to receive real-time notifications.
5. Open the Live Scanner URL (`yoursite.com/?sazticket_scanner=1`) on your mobile phone to begin scanning.

== Frequently Asked Questions ==

= Do staff members need to download a native mobile app? =
No. The scanner works in any modern mobile browser (Safari, Chrome, Firefox) on devices with camera access.

= Does this plugin slow down WooCommerce checkout? =
No. Camera and scanner scripts load strictly on the dedicated scanner screen. Notifications run asynchronously via WooCommerce Action Scheduler when available.

= Is this plugin compatible with WooCommerce HPOS? =
Yes. SazTicket officially declares native compatibility with High-Performance Order Storage (HPOS).

= How does duplicate prevention work? =
When a ticket is verified, its database status switches to 'used' with an atomic timestamp. Subsequent scans of the same ticket trigger an alert indicating previous admission.

== Changelog ==

= 2.1.0 =
* Renamed and rebranded to SazTicket to prevent trademark conflicts.
* Enqueued all scripts and styles using WordPress wp_enqueue_script and wp_enqueue_style.
* Hardened REST API permission checks with scanner token authentication.
* Removed unneeded bundled translation files in compliance with translate.wordpress.org standards.
* Added explicit documentation for external API services (QRServer and Telegram).
* Added uninstall.php cleanup script.
* Updated Author URI to WordPress.org verified profile.

= 2.0.0 =
* Initial release with Action Scheduler dispatcher, HPOS compatibility, and camera scanner HUD.
