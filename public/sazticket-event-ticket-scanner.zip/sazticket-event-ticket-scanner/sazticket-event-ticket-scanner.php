<?php
/**
 * Plugin Name: SazTicket – Event Ticket Check-in & Scanner for WooCommerce
 * Plugin URI: https://wordpress.org/plugins/sazticket-event-ticket-scanner/
 * Description: Mobile-friendly ticket generator, browser camera check-in scanner, and instant Telegram order notifications for events and WooCommerce.
 * Version: 2.1.1
 * Author: Alexander Sazonov
 * Author URI: https://profiles.wordpress.org/alexsazonov/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: sazticket-event-ticket-scanner
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SAZTICKET_VERSION', '2.1.1');
define('QQTS_VERSION', '2.1.1');
define('QQTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QQTS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Declare WooCommerce HPOS compatibility
add_action('before_woocommerce_init', function() {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});

// Exclude live door scanner from cache engines
add_filter('rocket_cache_reject_uri', function($uris) {
    $uris[] = '/(.*)qqts_scanner=(.*)';
    $uris[] = '/(.*)sazticket_scanner=(.*)';
    return $uris;
});

require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-db.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-api.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-admin.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-woocommerce.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-telegram.php';
require_once QQTS_PLUGIN_DIR . 'includes/class-qr-scanner-mailer.php';

register_activation_hook(__FILE__, ['QQTS_DB', 'install']);

add_action('plugins_loaded', 'sazticket_init');
function sazticket_init() {
    QQTS_DB::check_updates();
    QQTS_API::init();
    QQTS_Admin::init();
    QQTS_WooCommerce::init();
    QQTS_Telegram::init();
}

