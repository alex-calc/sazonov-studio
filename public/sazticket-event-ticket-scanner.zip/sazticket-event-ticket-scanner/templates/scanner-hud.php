<?php
if (!defined('ABSPATH')) exit;

$rest_nonce = wp_create_nonce('wp_rest');
$scanner_nonce = wp_create_nonce('sazticket_scanner_nonce');
$rest_url = rest_url('sazticket/v1/checkin');
$scanner_token = get_option('sazticket_scanner_secret_token', get_option('qqts_scanner_secret_token', ''));

// Enqueue styles and scripts properly
wp_enqueue_style('sazticket-scanner-hud', QQTS_PLUGIN_URL . 'assets/css/scanner-hud.css', [], SAZTICKET_VERSION);
wp_enqueue_script('html5-qrcode', QQTS_PLUGIN_URL . 'assets/js/html5-qrcode.min.js', [], '2.3.8', true);
wp_enqueue_script('sazticket-scanner-hud-js', QQTS_PLUGIN_URL . 'assets/js/scanner-hud.js', ['html5-qrcode'], SAZTICKET_VERSION, true);

wp_localize_script('sazticket-scanner-hud-js', 'sazticketScanner', [
    'restUrl'      => esc_url_raw($rest_url),
    'restNonce'    => esc_js($rest_nonce),
    'scannerNonce' => esc_js($scanner_nonce),
    'scannerToken' => esc_js($scanner_token),
]);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php esc_html_e('🎟️ Entry Pass Scanner', 'sazticket-event-ticket-scanner'); ?></title>
    <?php wp_head(); ?>
</head>
<body>
    <div class="scanner-header">
        <h1><?php esc_html_e('🎟️ ENTRY PASS SCANNER', 'sazticket-event-ticket-scanner'); ?></h1>
        <p style="color: #64748b; font-size: 12px; margin-top: 2px;"><?php esc_html_e('Aim camera at visitor ticket QR code', 'sazticket-event-ticket-scanner'); ?></p>
    </div>

    <div class="scanner-container" id="scanner-wrap" onclick="restartCameraIfFrozen()">
        <div class="laser-line" id="laser"></div>
        <div id="reader"></div>
        
        <!-- Live HUD Overlay inside camera container -->
        <div class="hud-overlay" id="hud-overlay">
            <div class="hud-icon" id="hud-icon">✅</div>
            <div class="hud-title" id="hud-title"><?php esc_html_e('ACCESS GRANTED', 'sazticket-event-ticket-scanner'); ?></div>
            <div class="hud-desc" id="hud-desc"></div>
        </div>
    </div>

    <p class="wake-status" id="wake-status"><?php esc_html_e('🟢 Always-On Active (Screen will not sleep)', 'sazticket-event-ticket-scanner'); ?></p>

    <?php wp_footer(); ?>
</body>
</html>
