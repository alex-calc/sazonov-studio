<?php
/**
 * Fired when the plugin is uninstalled.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up plugin options
delete_option('qqts_telegram_bot_token');
delete_option('qqts_telegram_chat_id');
delete_option('qqts_telegram_alerts_enabled');
delete_option('qqts_scanner_secret_token');
delete_option('sazticket_scanner_secret_token');
delete_option('qqts_db_version');
delete_option('qqts_review_dismissed');

// Optional: clean up database tables if desired, but keep tickets by default for financial audit integrity.
